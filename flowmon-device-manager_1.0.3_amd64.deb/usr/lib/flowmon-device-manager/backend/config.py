from __future__ import annotations

import warnings
import os
from pathlib import Path
from urllib.parse import urlsplit

from pydantic import SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Literal

# Look for .env next to this file first, then one level up (project root)
_here = Path(__file__).parent
_env_file = _here / ".env" if (_here / ".env").exists() else _here.parent / ".env"
_env_file = Path(os.environ.get("FDM_CONFIG_FILE", _env_file))


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(_env_file), env_file_encoding="utf-8")

    secret_key: str
    access_token_expire_hours: int = 8
    device_refresh_interval_hours: int = 24
    # How often to sample device performance counters over SSH (0 disables)
    perf_collect_interval_minutes: int = 5
    # How often to re-check the artifact host for new package releases (0 disables)
    community_refresh_interval_hours: int = 12
    community_proxy_url: SecretStr | None = None
    # Verification mode used when a device has certificate checking enabled.
    # "true" | "false" | "/path/to/ca.pem"
    flowmon_verify_ssl: str = "true"
    production: bool = False
    log_level: Literal["INFO", "WARNING", "ERROR", "DEBUG"] = "INFO"
    oidc_enabled: bool = False
    oidc_issuer: str = ""
    oidc_client_id: str = ""
    oidc_client_secret: SecretStr | None = None
    oidc_redirect_uri: str = ""
    oidc_auto_provision: bool = False

    @model_validator(mode="after")
    def validate_oidc(self):
        if not self.oidc_enabled:
            return self
        if not self.production:
            raise ValueError("OIDC requires PRODUCTION=true to secure session cookies")
        if not self.oidc_client_id.strip() or not self.oidc_client_secret or not self.oidc_client_secret.get_secret_value():
            raise ValueError("OIDC requires a client ID and client secret")
        for label, value in (("issuer", self.oidc_issuer), ("redirect URI", self.oidc_redirect_uri)):
            parsed = urlsplit(value)
            if (
                parsed.scheme != "https" or not parsed.hostname or parsed.username
                or parsed.password or parsed.query or parsed.fragment
            ):
                raise ValueError(f"OIDC {label} must be an HTTPS URL without credentials, query, or fragment")
        callback_path = urlsplit(self.oidc_redirect_uri).path
        if (
            not callback_path.endswith("/api/auth/oidc/callback")
            or "//" in callback_path or "\\" in callback_path or "%" in callback_path
            or any(part in (".", "..") for part in callback_path.split("/"))
        ):
            raise ValueError("OIDC redirect URI must end with /api/auth/oidc/callback")
        return self

    @field_validator("community_proxy_url")
    @classmethod
    def validate_community_proxy_url(cls, value: SecretStr | None) -> SecretStr | None:
        if value is None or not value.get_secret_value().strip():
            return None
        url = value.get_secret_value().strip()
        try:
            parsed = urlsplit(url)
            valid = (
                parsed.scheme in ("http", "https")
                and parsed.hostname
                and (parsed.port is None or parsed.port > 0)
                and parsed.path in ("", "/")
                and not parsed.query
                and not parsed.fragment
            )
        except ValueError:
            valid = False
        if not valid:
            raise ValueError("Community proxy must be an HTTP(S) URL with a host and optional port")
        return SecretStr(url)

    @property
    def community_proxy(self) -> str | None:
        return self.community_proxy_url.get_secret_value() if self.community_proxy_url else None

    @staticmethod
    def _parse_ssl_verify_value(value: str, env_name: str) -> bool | str:
        val = value.strip()
        if val.lower() == "true":
            return True
        if val.lower() == "false":
            warnings.warn(
                f"{env_name}=false disables TLS verification. "
                "Do not use in production.",
                stacklevel=1,
            )
            return False
        return val  # treat as path to CA bundle

    @property
    def ssl_verify(self) -> bool | str:
        """Return the value to pass to Flowmon httpx verify=."""
        return self._parse_ssl_verify_value(self.flowmon_verify_ssl, "FLOWMON_VERIFY_SSL")

settings = Settings()
