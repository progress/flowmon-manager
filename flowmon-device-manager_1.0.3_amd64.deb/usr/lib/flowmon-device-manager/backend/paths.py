"""Writable application storage; defaults preserve source deployments."""
import os
from pathlib import Path

DATA_DIR = Path(os.environ.get("FDM_DATA_DIR", Path(__file__).resolve().parent))
