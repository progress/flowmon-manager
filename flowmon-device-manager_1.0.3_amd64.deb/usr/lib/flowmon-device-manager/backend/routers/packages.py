"""Packages router — central repository, community scraping, push to device."""
from __future__ import annotations

import asyncio
import io
import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import httpx
import paramiko
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from config import settings
from database import Device, SshCredential, decrypt_password, get_db
from paths import DATA_DIR
from routers.auth import get_current_admin, get_current_session
from services.community_discovery import (
    ReleaseChannel,
    discover_latest_packages,
    known_versions_from_cache,
)
from services.ssh_utils import open_ssh_connection

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/packages", tags=["packages"])

_CACHE_FILE = DATA_DIR / "community_cache.json"
_REPO_DIR   = DATA_DIR / "packages"
_REPO_DIR.mkdir(exist_ok=True)
_DOWNLOAD_TASKS: Dict[str, Dict[str, Any]] = {}


# ── Helpers ────────────────────────────────────────────────────────────────────

def _pkg_meta(filename: str) -> Dict[str, Any]:
    """Extract component/version from a package filename."""
    name = filename
    version = None
    component = filename

    m = re.match(r'^flowmon-v([\d.]+)\.tar\.gz$', filename, re.IGNORECASE)
    if m:
        version = m.group(1)
        name = "Flowmon OS"
        component = "flowmon"
    else:
        m = re.match(r'^flowmonplug-(\w+(?:-\w+)?)-v([\d.]+)\.tar\.gz$', filename, re.IGNORECASE)
        if m:
            slug = m.group(1).lower()
            version = m.group(2)
            slug_map = {
                "ads": "Flowmon ADS",
                "fpi": "Flowmon FPI",
                "fpi-probe": "Flowmon FPI (Probe)",
                "apm": "Flowmon APM",
                "apm-probe": "Flowmon APM (Probe)",
            }
            name = slug_map.get(slug, f"Flowmon {slug.upper()}")
            component = slug

    path = _REPO_DIR / filename
    size = path.stat().st_size if path.exists() else 0
    added_at = (
        datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat()
        if path.exists() else None
    )

    return {
        "filename": filename,
        "name": name,
        "component": component,
        "version": version,
        "size": size,
        "added_at": added_at,
    }


def _cache_file(channel: ReleaseChannel) -> Path:
    return _CACHE_FILE if channel == "stable" else _CACHE_FILE.with_name("community_cache_beta.json")


def _read_cache(channel: ReleaseChannel = "stable") -> dict:
    path = _cache_file(channel)
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return {"scraped_at": None, "packages": []}


def _write_cache(cache: dict, channel: ReleaseChannel = "stable") -> None:
    path = _cache_file(channel)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(cache, indent=2))
    tmp.replace(path)


async def refresh_community_cache(channel: ReleaseChannel = "stable") -> dict:
    """Re-check the artifact host and store the result.

    Previously discovered versions seed the search so the probe stays cheap and
    a transient failure can never move a component back to an older release.
    """
    cache = _read_cache(channel)
    packages = await discover_latest_packages(known_versions_from_cache(cache), channel=channel)
    verified = any(pkg.get("download_url") for pkg in packages)
    previous = {pkg["slug"]: pkg for pkg in cache.get("packages", [])}
    for index, pkg in enumerate(packages):
        cached = previous.get(pkg["slug"])
        if not pkg.get("download_url") and cached and cached.get("download_url"):
            packages[index] = {
                **cached,
                "error": f"{pkg['error']} Showing the last known version.",
            }
    fresh = {
        "scraped_at": (
            datetime.now(timezone.utc).isoformat()
            if verified or not packages else cache.get("scraped_at")
        ),
        "packages": packages,
    }
    failed = [pkg.get("name", pkg["slug"]) for pkg in packages if pkg.get("error")]
    if failed:
        fresh["error"] = (
            f"Community refresh incomplete for: {', '.join(failed)}. "
            "See component warnings; check network access, COMMUNITY_PROXY_URL and TLS certificates."
        )
    _write_cache(fresh, channel)
    return fresh


# ── Pydantic models ────────────────────────────────────────────────────────────

class DownloadToRepoRequest(BaseModel):
    url: str
    filename: str


class DownloadTaskStartResponse(BaseModel):
    task_id: str


class DownloadTaskStatusResponse(BaseModel):
    task_id: str
    filename: str
    status: str
    downloaded_bytes: int
    total_bytes: Optional[int]
    progress_pct: Optional[float]
    speed_bps: Optional[float]
    eta_seconds: Optional[int]
    error: Optional[str]
    started_at: str
    finished_at: Optional[str]


def _validate_download_request(body: DownloadToRepoRequest) -> None:
    if not (body.filename.endswith(".tar.gz") or body.filename.endswith(".txt")):
        raise HTTPException(status_code=400, detail="Filename must end with .tar.gz or .txt")
    if "/" in body.filename or ".." in body.filename:
        raise HTTPException(status_code=400, detail="Invalid filename")

    host = urlparse(body.url).hostname
    allowed_hosts = {"kemptechnologies.com", "kemp-artifact-packages.s3.amazonaws.com"}
    if host not in allowed_hosts:
        raise HTTPException(status_code=400, detail="URL host not allowed")


async def _download_to_repository_task(task_id: str, url: str, filename: str) -> None:
    task = _DOWNLOAD_TASKS[task_id]
    task["status"] = "running"

    dest = _REPO_DIR / filename
    tmp = _REPO_DIR / f"{filename}.part-{task_id}"
    start = time.monotonic()

    try:
        async with httpx.AsyncClient(
            follow_redirects=True, timeout=300, proxy=settings.community_proxy
        ) as client:
            async with client.stream("GET", url) as resp:
                if resp.status_code != 200:
                    raise HTTPException(status_code=502, detail=f"Download failed: HTTP {resp.status_code}")

                total_header = resp.headers.get("content-length")
                total = int(total_header) if total_header and total_header.isdigit() else None
                task["total_bytes"] = total

                downloaded = 0
                with tmp.open("wb") as out:
                    async for chunk in resp.aiter_bytes():
                        if not chunk:
                            continue
                        out.write(chunk)
                        downloaded += len(chunk)
                        elapsed = max(time.monotonic() - start, 0.001)
                        speed = downloaded / elapsed
                        eta = int((total - downloaded) / speed) if total and speed > 0 and total >= downloaded else None
                        progress = round((downloaded / total) * 100, 1) if total and total > 0 else None
                        task.update(
                            downloaded_bytes=downloaded,
                            speed_bps=round(speed, 1),
                            eta_seconds=eta,
                            progress_pct=progress,
                        )

        tmp.replace(dest)
        task.update(
            status="completed",
            downloaded_bytes=dest.stat().st_size,
            progress_pct=100.0,
            eta_seconds=0,
            finished_at=datetime.now(timezone.utc).isoformat(),
        )
    except HTTPException as exc:
        logger.warning("Package download failed task_id=%s filename=%s status=%s",
                       task_id, filename, exc.status_code)
        task.update(
            status="failed",
            error=exc.detail,
            finished_at=datetime.now(timezone.utc).isoformat(),
        )
        if tmp.exists():
            tmp.unlink(missing_ok=True)
    except httpx.ProxyError:
        logger.warning("Package download proxy failed task_id=%s filename=%s", task_id, filename)
        task.update(
            status="failed",
            error="Proxy connection failed; check COMMUNITY_PROXY_URL and proxy authentication.",
            finished_at=datetime.now(timezone.utc).isoformat(),
        )
        if tmp.exists():
            tmp.unlink(missing_ok=True)
    except httpx.RequestError as exc:
        logger.warning("Package download connection failed task_id=%s filename=%s error_type=%s",
                       task_id, filename, type(exc).__name__)
        task.update(
            status="failed",
            error=f"Download error: {exc}",
            finished_at=datetime.now(timezone.utc).isoformat(),
        )
        if tmp.exists():
            tmp.unlink(missing_ok=True)
    except Exception as exc:
        logger.exception("Package download failed task_id=%s filename=%s", task_id, filename)
        task.update(
            status="failed",
            error=f"Download error: {exc}",
            finished_at=datetime.now(timezone.utc).isoformat(),
        )
        if tmp.exists():
            tmp.unlink(missing_ok=True)


# ── Repository endpoints ───────────────────────────────────────────────────────

@router.get("/repository")
async def list_repository(_session=Depends(get_current_session)) -> List[Dict]:
    """List all packages in the central repository."""
    files = sorted(_REPO_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    return [_pkg_meta(f.name) for f in files if f.is_file() and f.suffix in (".gz", ".txt")]


@router.post("/repository/upload", status_code=201)
async def upload_to_repository(
    file: UploadFile = File(...),
    _session=Depends(get_current_admin),
) -> Dict[str, Any]:
    """Upload a package file to the central repository."""
    filename = file.filename or "package.tar.gz"
    if not (filename.endswith(".tar.gz") or filename.endswith(".txt")):
        raise HTTPException(status_code=400, detail="Only .tar.gz and .txt files are accepted")
    if "/" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    dest = _REPO_DIR / filename
    dest.write_bytes(data)
    return _pkg_meta(filename)


@router.post("/repository/download", status_code=201, response_model=DownloadTaskStartResponse)
async def download_to_repository(
    body: DownloadToRepoRequest,
    _session=Depends(get_current_admin),
) -> DownloadTaskStartResponse:
    """Start background package download into the central repository."""
    _validate_download_request(body)
    if any(t["status"] in {"queued", "running"} for t in _DOWNLOAD_TASKS.values()):
        raise HTTPException(status_code=409, detail="Another download is already running")

    task_id = str(uuid.uuid4())
    _DOWNLOAD_TASKS[task_id] = {
        "task_id": task_id,
        "filename": body.filename,
        "status": "queued",
        "downloaded_bytes": 0,
        "total_bytes": None,
        "progress_pct": 0.0,
        "speed_bps": None,
        "eta_seconds": None,
        "error": None,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "finished_at": None,
    }
    asyncio.create_task(_download_to_repository_task(task_id, body.url, body.filename))
    return DownloadTaskStartResponse(task_id=task_id)


@router.get("/repository/download/{task_id}", response_model=DownloadTaskStatusResponse)
async def get_download_status(
    task_id: str,
    _session=Depends(get_current_session),
) -> DownloadTaskStatusResponse:
    task = _DOWNLOAD_TASKS.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Download task not found")
    return DownloadTaskStatusResponse(**task)


@router.delete("/repository/{filename}", status_code=204)
async def delete_from_repository(
    filename: str,
    _session=Depends(get_current_admin),
):
    """Delete a package from the central repository."""
    if "/" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")
    path = _REPO_DIR / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found in repository")
    path.unlink()


@router.post("/repository/{filename}/push/{device_id}")
async def push_to_device(
    filename: str,
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> Dict[str, Any]:
    """Push a package from the central repository to a device's /data/packages/ via SFTP."""
    if "/" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")

    path = _REPO_DIR / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found in repository")

    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    cred = db.get(SshCredential, device.ssh_credential_id) if device.ssh_credential_id else None
    if not cred:
        raise HTTPException(status_code=400, detail="No SSH credential assigned to this device")

    ssh_client = None
    try:
        ssh_client = open_ssh_connection(device, cred)

        sftp = ssh_client.open_sftp()
        sftp.put(str(path), f"/data/packages/{filename}")
        sftp.close()
    except paramiko.SSHException as exc:
        raise HTTPException(status_code=502, detail=f"SFTP failed: {exc}")
    finally:
        if ssh_client is not None:
            ssh_client.close()

    return {"filename": filename, "size": path.stat().st_size, "device": device.name}


# ── Community downloads ────────────────────────────────────────────────────────

@router.get("/community")
async def get_community_downloads(
    refresh: bool = False,
    channel: ReleaseChannel = "stable",
    _session=Depends(get_current_session),
) -> dict:
    """
    Return the latest community download links.

    Serves the cached result by default; pass ?refresh=true to re-check the
    artifact host immediately. Beta results are discovered on first access.
    """
    cache = _read_cache(channel)
    if refresh or (channel == "beta" and not cache.get("scraped_at")):
        try:
            return await refresh_community_cache(channel)
        except Exception as exc:
            logger.warning("Community refresh failed: %s", exc)
            cache = _read_cache(channel)
            cache["error"] = f"Refresh failed: {exc}"
            return cache
    return cache
