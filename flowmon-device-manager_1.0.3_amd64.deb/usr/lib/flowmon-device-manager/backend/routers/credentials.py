from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import (
    RestCredential, SshCredential,
    encrypt_password, decrypt_password, get_db,
)
from routers.auth import get_current_admin, get_current_session as get_current_user

router = APIRouter(prefix="/api/credentials", tags=["credentials"])

def _audit(db, user, action, **kwargs):
    from routers.audit import write_audit
    write_audit(db, username=user.username, action=action, **kwargs)


# ── Pydantic schemas ──────────────────────────────────────────────────────────

class RestCredentialCreate(BaseModel):
    name: str
    username: str
    password: str


class RestCredentialUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None  # omit to keep existing


class RestCredentialResponse(BaseModel):
    id: str
    name: str
    username: str
    created_at: datetime
    updated_at: datetime


class SshCredentialCreate(BaseModel):
    name: str
    username: str
    port: int = 22
    auth_type: str = "password"   # "password" | "key"
    secret: str                    # password text or PEM private key


class SshCredentialUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    port: Optional[int] = None
    auth_type: Optional[str] = None
    secret: Optional[str] = None  # omit to keep existing


class SshCredentialResponse(BaseModel):
    id: str
    name: str
    username: str
    port: int
    auth_type: str
    created_at: datetime
    updated_at: datetime


# ── REST credential endpoints ─────────────────────────────────────────────────

@router.get("/rest", response_model=list[RestCredentialResponse])
def list_rest(
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    return db.query(RestCredential).order_by(RestCredential.created_at).all()


@router.post("/rest", response_model=RestCredentialResponse, status_code=201)
def create_rest(
    body: RestCredentialCreate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    cred = RestCredential(
        name=body.name,
        username=body.username,
        password_enc=encrypt_password(body.password),
    )
    db.add(cred)
    db.commit()
    db.refresh(cred)
    _audit(db, _user, "CRED_ADD", resource_type="rest_credential", resource_name=body.name)
    return cred


@router.put("/rest/{cred_id}", response_model=RestCredentialResponse)
def update_rest(
    cred_id: str,
    body: RestCredentialUpdate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    cred = db.get(RestCredential, cred_id)
    if not cred:
        raise HTTPException(status_code=404, detail="Credential not found")
    if body.name is not None:
        cred.name = body.name
    if body.username is not None:
        cred.username = body.username
    if body.password is not None:
        cred.password_enc = encrypt_password(body.password)
    cred.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(cred)
    _audit(db, _user, "CRED_UPDATE", resource_type="rest_credential", resource_name=cred.name)
    return cred


@router.delete("/rest/{cred_id}", status_code=204)
def delete_rest(
    cred_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    cred = db.get(RestCredential, cred_id)
    if not cred:
        raise HTTPException(status_code=404, detail="Credential not found")
    _audit(db, _user, "CRED_DELETE", resource_type="rest_credential", resource_name=cred.name)
    db.delete(cred)
    db.commit()


# ── SSH credential endpoints ──────────────────────────────────────────────────

@router.get("/ssh", response_model=list[SshCredentialResponse])
def list_ssh(
    db: Session = Depends(get_db),
    _user=Depends(get_current_user),
):
    return db.query(SshCredential).order_by(SshCredential.created_at).all()


@router.post("/ssh", response_model=SshCredentialResponse, status_code=201)
def create_ssh(
    body: SshCredentialCreate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    if body.auth_type not in ("password", "key"):
        raise HTTPException(status_code=422, detail="auth_type must be 'password' or 'key'")
    cred = SshCredential(
        name=body.name,
        username=body.username,
        port=body.port,
        auth_type=body.auth_type,
        secret_enc=encrypt_password(body.secret),
    )
    db.add(cred)
    db.commit()
    db.refresh(cred)
    _audit(db, _user, "CRED_ADD", resource_type="ssh_credential", resource_name=body.name)
    return cred


@router.put("/ssh/{cred_id}", response_model=SshCredentialResponse)
def update_ssh(
    cred_id: str,
    body: SshCredentialUpdate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    cred = db.get(SshCredential, cred_id)
    if not cred:
        raise HTTPException(status_code=404, detail="Credential not found")
    if body.name is not None:
        cred.name = body.name
    if body.username is not None:
        cred.username = body.username
    if body.port is not None:
        cred.port = body.port
    if body.auth_type is not None:
        if body.auth_type not in ("password", "key"):
            raise HTTPException(status_code=422, detail="auth_type must be 'password' or 'key'")
        cred.auth_type = body.auth_type
    if body.secret is not None:
        cred.secret_enc = encrypt_password(body.secret)
    cred.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(cred)
    _audit(db, _user, "CRED_UPDATE", resource_type="ssh_credential", resource_name=cred.name)
    return cred


@router.delete("/ssh/{cred_id}", status_code=204)
def delete_ssh(
    cred_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    cred = db.get(SshCredential, cred_id)
    if not cred:
        raise HTTPException(status_code=404, detail="Credential not found")
    _audit(db, _user, "CRED_DELETE", resource_type="ssh_credential", resource_name=cred.name)
    db.delete(cred)
    db.commit()
