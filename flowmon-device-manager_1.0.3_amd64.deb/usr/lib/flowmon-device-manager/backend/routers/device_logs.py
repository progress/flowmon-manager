from __future__ import annotations

import asyncio
import io
import posixpath
import stat
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import Device, SshCredential, get_db, decrypt_password
from routers.auth import get_current_session as get_current_user
from database import DeviceSession
from services.device_log_digest import (
    SEVERITIES,
    SEVERITY_RANK,
    LogDigestError,
    collect_device_log_digest,
    group_entries,
)
from services.ssh_utils import open_ssh_connection

router = APIRouter(prefix="/api/logs/device", tags=["device-logs"])

# Log directories available on Flowmon devices
LOG_DIRS = [
    "/var/log/flowmon",
    "/var/log",
]
MAX_LOG_DOWNLOAD_BYTES = 50 * 1024 * 1024


def _is_path_within(path: str, directory: str) -> bool:
    return path == directory or path.startswith(directory.rstrip("/") + "/")


def _normalize_requested_log_path(requested_path: str) -> str:
    if "\x00" in requested_path or not requested_path.startswith("/"):
        raise HTTPException(status_code=403, detail="Access to this path is not allowed")

    normalized = posixpath.normpath(requested_path)
    if not any(_is_path_within(normalized, directory) for directory in LOG_DIRS):
        raise HTTPException(status_code=403, detail="Access to this path is not allowed")
    return normalized


def _resolve_allowed_log_path(sftp, requested_path: str) -> str:
    """Resolve symlinks and traversal before allowing a remote log download."""
    normalized = _normalize_requested_log_path(requested_path)

    try:
        resolved = sftp.normalize(normalized)
        resolved_dirs = [sftp.normalize(directory) for directory in LOG_DIRS]
    except OSError as exc:
        raise HTTPException(status_code=404, detail="Log file not found") from exc

    if not any(_is_path_within(resolved, directory) for directory in resolved_dirs):
        raise HTTPException(status_code=403, detail="Access to this path is not allowed")

    try:
        attrs = sftp.stat(resolved)
    except OSError as exc:
        raise HTTPException(status_code=404, detail="Log file not found") from exc
    if not stat.S_ISREG(attrs.st_mode or 0):
        raise HTTPException(status_code=403, detail="Only regular log files can be downloaded")
    if (attrs.st_size or 0) > MAX_LOG_DOWNLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Log file exceeds the 50 MB download limit")
    return resolved


def _get_ssh_client(device: Device, db: Session):
    """Return a connected Paramiko SSH client for the device."""
    try:
        import paramiko
    except ImportError:
        raise HTTPException(status_code=500, detail="paramiko not installed")

    cred: Optional[SshCredential] = None
    if device.ssh_credential_id:
        cred = db.get(SshCredential, device.ssh_credential_id)
    if not cred:
        raise HTTPException(status_code=400, detail="No SSH credential assigned to this device")

    try:
        client = open_ssh_connection(device, cred)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"SSH connection failed: {exc}")
    return client


# ---------- Pydantic ----------

class LogFile(BaseModel):
    path: str
    name: str
    size: int
    modified: Optional[str]


class LogFilesResponse(BaseModel):
    device_id: str
    files: list[LogFile]


class ImportantLogGroup(BaseModel):
    severity: str
    message: str
    signature: str
    sources: list[str]
    files: list[str]
    count: int
    first_seen: Optional[str]
    last_seen: Optional[str]
    samples: list[str]


class ImportantLogsResponse(BaseModel):
    device_id: str
    collected_at: str
    window_hours: int
    min_severity: str
    groups: list[ImportantLogGroup]
    counts: dict[str, int]
    total_entries: int
    sources: list[str]


# ---------- Endpoints ----------

@router.get("/{device_id}/files", response_model=LogFilesResponse)
async def list_log_files(
    device_id: str,
    _session: DeviceSession = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> LogFilesResponse:
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    client = _get_ssh_client(device, db)
    files: list[LogFile] = []
    try:
        sftp = client.open_sftp()
        for log_dir in LOG_DIRS:
            try:
                entries = sftp.listdir_attr(log_dir)
                for entry in entries:
                    full_path = posixpath.join(log_dir, entry.filename)
                    # Only regular files (not dirs), skip very large files > 50MB
                    if entry.st_size is not None and entry.st_size < 50 * 1024 * 1024:
                        import stat
                        if stat.S_ISREG(entry.st_mode or 0):
                            files.append(LogFile(
                                path=full_path,
                                name=entry.filename,
                                size=entry.st_size or 0,
                                modified=str(entry.st_mtime) if entry.st_mtime else None,
                            ))
            except Exception:
                continue
        sftp.close()
    finally:
        client.close()

    files.sort(key=lambda f: f.modified or "", reverse=True)
    return LogFilesResponse(device_id=device_id, files=files)


@router.get("/{device_id}/file")
async def get_log_file(
    device_id: str,
    path: str = Query(..., description="Full path to the log file on the device"),
    _session: DeviceSession = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> StreamingResponse:
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    normalized_path = _normalize_requested_log_path(path)
    client = _get_ssh_client(device, db)
    sftp = None
    try:
        sftp = client.open_sftp()
        resolved_path = _resolve_allowed_log_path(sftp, normalized_path)
        file_obj = sftp.open(resolved_path, "r")
        content = file_obj.read()
        file_obj.close()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Failed to read file: {exc}")
    finally:
        if sftp:
            sftp.close()
        client.close()

    filename = posixpath.basename(resolved_path)
    return StreamingResponse(
        io.BytesIO(content),
        media_type="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/{device_id}/important", response_model=ImportantLogsResponse)
async def get_important_logs(
    device_id: str,
    hours: int = Query(24, ge=1, le=720, description="How far back to look"),
    severity: str = Query("warning", description="Minimum severity: warning, error or critical"),
    _session: DeviceSession = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> ImportantLogsResponse:
    """Return a grouped digest of warning-and-above entries from the device.

    Collection runs over SSH and takes a few seconds, so it is offloaded to a
    worker thread rather than blocking the event loop.
    """
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    severity = severity.lower()
    if severity not in SEVERITY_RANK:
        raise HTTPException(
            status_code=400,
            detail=f"severity must be one of: {', '.join(SEVERITY_RANK)}",
        )

    cred = db.get(SshCredential, device.ssh_credential_id) if device.ssh_credential_id else None
    if not cred:
        raise HTTPException(status_code=400, detail="No SSH credential assigned to this device")

    try:
        entries = await asyncio.to_thread(
            collect_device_log_digest, device, cred, window_minutes=hours * 60
        )
    except LogDigestError as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    now = datetime.now(timezone.utc)
    since = now - timedelta(hours=hours)
    groups = group_entries(entries, min_severity=severity, since=since)

    counts = {level: 0 for level in SEVERITIES}
    sources: list[str] = []
    total = 0
    for group in groups:
        counts[group.severity] = counts.get(group.severity, 0) + group.count
        total += group.count
        for source in group.sources:
            if source not in sources:
                sources.append(source)

    return ImportantLogsResponse(
        device_id=device_id,
        collected_at=now.isoformat(),
        window_hours=hours,
        min_severity=severity,
        groups=[
            ImportantLogGroup(
                severity=g.severity,
                message=g.message,
                signature=g.signature,
                sources=g.sources,
                files=g.files,
                count=g.count,
                first_seen=g.first_seen.isoformat() if g.first_seen else None,
                last_seen=g.last_seen.isoformat() if g.last_seen else None,
                samples=g.samples,
            )
            for g in groups
        ],
        counts=counts,
        total_entries=total,
        sources=sorted(sources),
    )
