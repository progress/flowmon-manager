from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Query, Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import AuditLog, DeviceSession, get_db
from routers.auth import get_current_admin
from services.app_logging import build_diagnostics

router = APIRouter(prefix="/api/logs", tags=["logs"])


# ---------- Helpers ----------

def write_audit(
    db: Session,
    username: str,
    action: str,
    ip_address: str = "unknown",
    resource_type: Optional[str] = None,
    resource_name: Optional[str] = None,
    details: Optional[dict] = None,
) -> None:
    """Write a single audit log entry. Call this from any router."""
    entry = AuditLog(
        username=username,
        action=action,
        resource_type=resource_type,
        resource_name=resource_name,
        details=json.dumps(details) if details else None,
        ip_address=ip_address,
    )
    db.add(entry)
    db.commit()


# ---------- Pydantic ----------

class AuditLogEntry(BaseModel):
    id: str
    timestamp: datetime
    username: str
    action: str
    resource_type: Optional[str]
    resource_name: Optional[str]
    details: Optional[str]
    ip_address: Optional[str]

    class Config:
        from_attributes = True


class AuditLogPage(BaseModel):
    items: list[AuditLogEntry]
    total: int
    page: int
    page_size: int


# ---------- Endpoints ----------

@router.get("/diagnostics")
def download_diagnostics(
    _session: DeviceSession = Depends(get_current_admin),
) -> Response:
    return Response(
        content=build_diagnostics(),
        media_type="application/zip",
        headers={
            "Content-Disposition": 'attachment; filename="fdm-diagnostics.zip"',
            "Cache-Control": "no-store",
        },
    )

@router.get("/activity", response_model=AuditLogPage)
async def get_activity_log(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    action: Optional[str] = Query(None),
    username: Optional[str] = Query(None),
    _session: DeviceSession = Depends(get_current_admin),
    db: Session = Depends(get_db),
) -> AuditLogPage:
    q = db.query(AuditLog)
    if action:
        q = q.filter(AuditLog.action == action)
    if username:
        q = q.filter(AuditLog.username == username)
    total = q.count()
    items = (
        q.order_by(AuditLog.timestamp.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    return AuditLogPage(items=items, total=total, page=page, page_size=page_size)
