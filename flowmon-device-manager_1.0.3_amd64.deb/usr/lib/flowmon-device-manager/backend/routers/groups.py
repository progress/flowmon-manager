from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import Device, DeviceGroup, get_db
from routers.auth import get_current_admin, get_current_session as get_current_user
from database import DeviceSession

router = APIRouter(prefix="/api/groups", tags=["groups"])


# ---------- Schemas ----------

class GroupCreate(BaseModel):
    name: str
    description: Optional[str] = None


class GroupUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None


class DeviceInGroup(BaseModel):
    id: str
    name: str
    ip_address: str
    status: str


class GroupResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    created_at: str
    devices: List[DeviceInGroup]

    class Config:
        from_attributes = True


def _to_response(group: DeviceGroup, db: Session) -> GroupResponse:
    devices = db.query(Device).filter(Device.group_id == group.id).all()
    return GroupResponse(
        id=group.id,
        name=group.name,
        description=group.description,
        created_at=group.created_at.isoformat() if group.created_at else "",
        devices=[
            DeviceInGroup(id=d.id, name=d.name, ip_address=d.ip_address, status=d.status or "unknown")
            for d in devices
        ],
    )


# ---------- Endpoints ----------

@router.get("", response_model=List[GroupResponse])
def list_groups(
    db: Session = Depends(get_db),
    _user: DeviceSession = Depends(get_current_user),
):
    groups = db.query(DeviceGroup).order_by(DeviceGroup.created_at).all()
    return [_to_response(g, db) for g in groups]


@router.post("", response_model=GroupResponse, status_code=201)
def create_group(
    body: GroupCreate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    group = DeviceGroup(name=body.name, description=body.description)
    db.add(group)
    db.commit()
    db.refresh(group)
    return _to_response(group, db)


@router.put("/{group_id}", response_model=GroupResponse)
def update_group(
    group_id: str,
    body: GroupUpdate,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    group = db.get(DeviceGroup, group_id)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    if body.name is not None:
        group.name = body.name
    if body.description is not None:
        group.description = body.description
    db.commit()
    db.refresh(group)
    return _to_response(group, db)


@router.delete("/{group_id}", status_code=204)
def delete_group(
    group_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    group = db.get(DeviceGroup, group_id)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    # Unassign all devices from this group before deleting
    db.query(Device).filter(Device.group_id == group_id).update({"group_id": None})
    db.delete(group)
    db.commit()


@router.put("/{group_id}/devices/{device_id}", status_code=204)
def add_device_to_group(
    group_id: str,
    device_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    group = db.get(DeviceGroup, group_id)
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    device.group_id = group_id
    db.commit()


@router.delete("/{group_id}/devices/{device_id}", status_code=204)
def remove_device_from_group(
    group_id: str,
    device_id: str,
    db: Session = Depends(get_db),
    _user=Depends(get_current_admin),
):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    if device.group_id != group_id:
        raise HTTPException(status_code=400, detail="Device is not in this group")
    device.group_id = None
    db.commit()
