from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from database import (
    Alert,
    AlertNotification,
    AlertRule,
    AlertSnooze,
    Device,
    DeviceGroup,
    NotificationChannel,
    NotificationSetting,
    get_db,
    get_or_create_alert_rules,
    get_or_create_notification_settings,
)
from routers.auth import get_current_admin, get_current_session
from services.alerting import evaluate_alerts
from services.alerting import build_test_webhook_payload
from services.webhook_security import (
    WebhookTargetValidationError,
    resolve_webhook_tls_verify,
    validate_webhook_target,
)

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


def _audit(db: Session, session, action: str, **kwargs) -> None:
    from routers.audit import write_audit

    write_audit(db, username=session.username, action=action, **kwargs)


class AlertResponse(BaseModel):
    id: str
    alert_type: str
    severity: str
    status: str
    title: str
    description: str
    dedupe_key: str
    device_id: Optional[str]
    device_name: Optional[str]
    first_seen_at: str
    last_seen_at: str
    acknowledged_at: Optional[str]
    resolved_at: Optional[str]
    payload_json: Optional[str]


class AlertSummaryResponse(BaseModel):
    open_total: int
    critical_open_total: int


class AlertListResponse(BaseModel):
    items: List[AlertResponse]
    total: int


class NotificationChannelCreateRequest(BaseModel):
    name: str
    channel_type: str = "webhook"
    target: str
    enabled: bool = True
    message_format: str = "generic"
    verify_ssl: bool = True


class NotificationChannelUpdateRequest(BaseModel):
    name: Optional[str] = None
    target: Optional[str] = None
    enabled: Optional[bool] = None
    message_format: Optional[str] = None
    verify_ssl: Optional[bool] = None


class NotificationChannelResponse(BaseModel):
    id: str
    name: str
    channel_type: str
    target: str
    enabled: bool
    message_format: str
    verify_ssl: bool
    created_at: str
    updated_at: str


class AlertRuleResponse(BaseModel):
    id: str
    alert_type: str
    enabled: bool
    warning_threshold: Optional[int]
    critical_threshold: Optional[int]
    created_at: str
    updated_at: str


class AlertRuleUpdateRequest(BaseModel):
    enabled: Optional[bool] = None
    warning_threshold: Optional[int] = None
    critical_threshold: Optional[int] = None


class NotificationSettingsResponse(BaseModel):
    cooldown_seconds: int
    max_retries: int
    backoff_seconds: int
    muted_until: Optional[str]


class NotificationSettingsUpdateRequest(BaseModel):
    cooldown_seconds: Optional[int] = None
    max_retries: Optional[int] = None
    backoff_seconds: Optional[int] = None
    muted_until: Optional[str] = None


class BulkAlertActionRequest(BaseModel):
    alert_ids: List[str]


class AlertTimelineEvent(BaseModel):
    timestamp: str
    event_type: str
    message: str
    detail: Optional[str] = None


class AlertTimelineResponse(BaseModel):
    alert_id: str
    events: List[AlertTimelineEvent]


class WebhookTestResponse(BaseModel):
    status: str
    http_status: Optional[int]
    detail: Optional[str]


class AlertSnoozeCreateRequest(BaseModel):
    device_id: Optional[str] = None
    group_id: Optional[str] = None
    alert_type: Optional[str] = None
    muted_until: str
    reason: Optional[str] = None


class AlertSnoozeResponse(BaseModel):
    id: str
    device_id: Optional[str]
    device_name: Optional[str]
    group_id: Optional[str]
    group_name: Optional[str]
    alert_type: Optional[str]
    muted_until: str
    reason: Optional[str]
    created_at: str


def _to_alert_response(alert: Alert, device_name: Optional[str]) -> AlertResponse:
    return AlertResponse(
        id=alert.id,
        alert_type=alert.alert_type,
        severity=alert.severity,
        status=alert.status,
        title=alert.title,
        description=alert.description,
        dedupe_key=alert.dedupe_key,
        device_id=alert.device_id,
        device_name=device_name,
        first_seen_at=alert.first_seen_at.isoformat(),
        last_seen_at=alert.last_seen_at.isoformat(),
        acknowledged_at=alert.acknowledged_at.isoformat() if alert.acknowledged_at else None,
        resolved_at=alert.resolved_at.isoformat() if alert.resolved_at else None,
        payload_json=alert.payload_json,
    )


def _to_channel_response(channel: NotificationChannel) -> NotificationChannelResponse:
    return NotificationChannelResponse(
        id=channel.id,
        name=channel.name,
        channel_type=channel.channel_type,
        target=channel.target,
        enabled=bool(channel.enabled),
        message_format=(channel.message_format or "generic"),
        verify_ssl=bool(channel.verify_ssl),
        created_at=channel.created_at.isoformat(),
        updated_at=channel.updated_at.isoformat(),
    )


def _validate_message_format(message_format: str) -> str:
    normalized = message_format.strip().lower()
    allowed = {"generic", "msteams_adaptive_card"}
    if normalized not in allowed:
        raise HTTPException(status_code=422, detail="message_format must be 'generic' or 'msteams_adaptive_card'")
    return normalized


def _to_rule_response(rule: AlertRule) -> AlertRuleResponse:
    return AlertRuleResponse(
        id=rule.id,
        alert_type=rule.alert_type,
        enabled=bool(rule.enabled),
        warning_threshold=rule.warning_threshold,
        critical_threshold=rule.critical_threshold,
        created_at=rule.created_at.isoformat(),
        updated_at=rule.updated_at.isoformat(),
    )


def _to_notification_settings_response(settings_row: NotificationSetting) -> NotificationSettingsResponse:
    return NotificationSettingsResponse(
        cooldown_seconds=int(settings_row.cooldown_seconds),
        max_retries=int(settings_row.max_retries),
        backoff_seconds=int(settings_row.backoff_seconds),
        muted_until=settings_row.muted_until.isoformat() if settings_row.muted_until else None,
    )


def _to_snooze_response(
    snooze: AlertSnooze,
    device_name: Optional[str],
    group_name: Optional[str],
) -> AlertSnoozeResponse:
    return AlertSnoozeResponse(
        id=snooze.id,
        device_id=snooze.device_id,
        device_name=device_name,
        group_id=snooze.group_id,
        group_name=group_name,
        alert_type=snooze.alert_type,
        muted_until=snooze.muted_until.isoformat(),
        reason=snooze.reason,
        created_at=snooze.created_at.isoformat(),
    )


@router.get("/summary", response_model=AlertSummaryResponse)
def get_alert_summary(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertSummaryResponse:
    open_total = db.query(Alert).filter(Alert.status == "open").count()
    critical_open_total = (
        db.query(Alert)
        .filter(Alert.status == "open", Alert.severity == "critical")
        .count()
    )
    return AlertSummaryResponse(open_total=open_total, critical_open_total=critical_open_total)


@router.get("", response_model=AlertListResponse)
async def list_alerts(
    status: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    alert_type: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertListResponse:
    q = db.query(Alert)
    if status:
        q = q.filter(Alert.status == status)
    if severity:
        q = q.filter(Alert.severity == severity)
    if alert_type:
        q = q.filter(Alert.alert_type == alert_type)

    total = q.count()
    items = (
        q.order_by(Alert.last_seen_at.desc(), Alert.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    device_ids = sorted({a.device_id for a in items if a.device_id})
    device_names: Dict[str, str] = {}
    if device_ids:
        for device in db.query(Device).filter(Device.id.in_(device_ids)).all():
            device_names[device.id] = device.name

    return AlertListResponse(
        items=[_to_alert_response(item, device_names.get(item.device_id or "")) for item in items],
        total=total,
    )


@router.post("/evaluate")
async def run_alert_evaluation_now(
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> Dict[str, int]:
    return await evaluate_alerts(db)


@router.post("/{alert_id}/ack", response_model=AlertResponse)
async def acknowledge_alert(
    alert_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertResponse:
    alert = db.get(Alert, alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    if alert.status == "resolved":
        raise HTTPException(status_code=409, detail="Resolved alert cannot be acknowledged")

    alert.status = "acknowledged"
    alert.acknowledged_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(alert)
    device = db.get(Device, alert.device_id) if alert.device_id else None
    _audit(db, _session, "ALERT_ACK", resource_type="alert", resource_name=alert.id)
    return _to_alert_response(alert, device.name if device else None)


@router.post("/{alert_id}/resolve", response_model=AlertResponse)
async def resolve_alert(
    alert_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertResponse:
    alert = db.get(Alert, alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")

    now = datetime.now(timezone.utc)
    alert.status = "resolved"
    alert.resolved_at = now
    alert.last_seen_at = now
    db.commit()
    db.refresh(alert)
    device = db.get(Device, alert.device_id) if alert.device_id else None
    _audit(db, _session, "ALERT_RESOLVE", resource_type="alert", resource_name=alert.id)
    return _to_alert_response(alert, device.name if device else None)


@router.post("/bulk-ack", response_model=AlertListResponse)
async def bulk_acknowledge_alerts(
    request: BulkAlertActionRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertListResponse:
    now = datetime.now(timezone.utc)
    for alert_id in request.alert_ids:
        alert = db.get(Alert, alert_id)
        if not alert or alert.status == "resolved":
            continue
        alert.status = "acknowledged"
        alert.acknowledged_at = now
        alert.last_seen_at = now
    db.commit()

    q = db.query(Alert).filter(Alert.id.in_(request.alert_ids))
    items = q.order_by(Alert.last_seen_at.desc()).all()
    device_ids = sorted({a.device_id for a in items if a.device_id})
    device_names: Dict[str, str] = {}
    if device_ids:
        for d in db.query(Device).filter(Device.id.in_(device_ids)).all():
            device_names[d.id] = d.name

    _audit(
        db,
        _session,
        "ALERT_BULK_ACK",
        resource_type="alert",
        details={"count": len(request.alert_ids)},
    )
    return AlertListResponse(
        items=[_to_alert_response(item, device_names.get(item.device_id or "")) for item in items],
        total=len(items),
    )


@router.post("/bulk-resolve", response_model=AlertListResponse)
async def bulk_resolve_alerts(
    request: BulkAlertActionRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertListResponse:
    now = datetime.now(timezone.utc)
    for alert_id in request.alert_ids:
        alert = db.get(Alert, alert_id)
        if not alert:
            continue
        alert.status = "resolved"
        alert.resolved_at = now
        alert.last_seen_at = now
    db.commit()

    q = db.query(Alert).filter(Alert.id.in_(request.alert_ids))
    items = q.order_by(Alert.last_seen_at.desc()).all()
    device_ids = sorted({a.device_id for a in items if a.device_id})
    device_names: Dict[str, str] = {}
    if device_ids:
        for d in db.query(Device).filter(Device.id.in_(device_ids)).all():
            device_names[d.id] = d.name

    _audit(
        db,
        _session,
        "ALERT_BULK_RESOLVE",
        resource_type="alert",
        details={"count": len(request.alert_ids)},
    )
    return AlertListResponse(
        items=[_to_alert_response(item, device_names.get(item.device_id or "")) for item in items],
        total=len(items),
    )


@router.get("/channels", response_model=List[NotificationChannelResponse])
async def list_notification_channels(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> List[NotificationChannelResponse]:
    channels = db.query(NotificationChannel).order_by(NotificationChannel.created_at).all()
    return [_to_channel_response(c) for c in channels]


@router.post("/channels", response_model=NotificationChannelResponse, status_code=201)
async def create_notification_channel(
    request: NotificationChannelCreateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> NotificationChannelResponse:
    if request.channel_type != "webhook":
        raise HTTPException(status_code=422, detail="Only webhook channels are supported in this phase")
    try:
        safe_target = validate_webhook_target(request.target)
    except WebhookTargetValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    channel = NotificationChannel(
        name=request.name.strip(),
        channel_type=request.channel_type,
        target=safe_target,
        message_format=_validate_message_format(request.message_format),
        verify_ssl=1 if request.verify_ssl else 0,
        enabled=1 if request.enabled else 0,
    )
    db.add(channel)
    db.commit()
    db.refresh(channel)
    _audit(db, _session, "ALERT_CHANNEL_CREATE", resource_type="alert_channel", resource_name=channel.name)
    return _to_channel_response(channel)


@router.put("/channels/{channel_id}", response_model=NotificationChannelResponse)
async def update_notification_channel(
    channel_id: str,
    request: NotificationChannelUpdateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> NotificationChannelResponse:
    channel = db.get(NotificationChannel, channel_id)
    if not channel:
        raise HTTPException(status_code=404, detail="Notification channel not found")

    if request.name is not None:
        channel.name = request.name.strip()
    if request.target is not None:
        try:
            channel.target = validate_webhook_target(request.target)
        except WebhookTargetValidationError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
    if request.enabled is not None:
        channel.enabled = 1 if request.enabled else 0
    if request.message_format is not None:
        channel.message_format = _validate_message_format(request.message_format)
    if request.verify_ssl is not None:
        channel.verify_ssl = 1 if request.verify_ssl else 0

    db.commit()
    db.refresh(channel)
    _audit(db, _session, "ALERT_CHANNEL_UPDATE", resource_type="alert_channel", resource_name=channel.name)
    return _to_channel_response(channel)


@router.delete("/channels/{channel_id}")
async def delete_notification_channel(
    channel_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> Dict[str, str]:
    channel = db.get(NotificationChannel, channel_id)
    if not channel:
        raise HTTPException(status_code=404, detail="Notification channel not found")

    channel_name = channel.name
    db.delete(channel)
    db.commit()
    _audit(db, _session, "ALERT_CHANNEL_DELETE", resource_type="alert_channel", resource_name=channel_name)
    return {"status": "deleted"}


@router.get("/rules", response_model=List[AlertRuleResponse])
async def list_alert_rules(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> List[AlertRuleResponse]:
    rules = get_or_create_alert_rules(db)
    return [_to_rule_response(rule) for rule in rules]


@router.put("/rules/{alert_type}", response_model=AlertRuleResponse)
async def update_alert_rule(
    alert_type: str,
    request: AlertRuleUpdateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> AlertRuleResponse:
    get_or_create_alert_rules(db)
    rule = db.query(AlertRule).filter(AlertRule.alert_type == alert_type).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Alert rule not found")

    if request.enabled is not None:
        rule.enabled = 1 if request.enabled else 0
    if request.warning_threshold is not None:
        if request.warning_threshold < 0:
            raise HTTPException(status_code=422, detail="warning_threshold must be >= 0")
        rule.warning_threshold = request.warning_threshold
    if request.critical_threshold is not None:
        if request.critical_threshold < 0:
            raise HTTPException(status_code=422, detail="critical_threshold must be >= 0")
        rule.critical_threshold = request.critical_threshold
    if (
        rule.warning_threshold is not None
        and rule.critical_threshold is not None
        and rule.critical_threshold > rule.warning_threshold
    ):
        raise HTTPException(
            status_code=422,
            detail="critical_threshold must be <= warning_threshold",
        )

    db.commit()
    db.refresh(rule)
    _audit(db, _session, "ALERT_RULE_UPDATE", resource_type="alert_rule", resource_name=rule.alert_type)
    return _to_rule_response(rule)


@router.get("/notification-settings", response_model=NotificationSettingsResponse)
async def get_notification_settings(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> NotificationSettingsResponse:
    settings_row = get_or_create_notification_settings(db)
    return _to_notification_settings_response(settings_row)


@router.put("/notification-settings", response_model=NotificationSettingsResponse)
async def update_notification_settings(
    request: NotificationSettingsUpdateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> NotificationSettingsResponse:
    settings_row = get_or_create_notification_settings(db)

    if request.cooldown_seconds is not None:
        if request.cooldown_seconds < 0:
            raise HTTPException(status_code=422, detail="cooldown_seconds must be >= 0")
        settings_row.cooldown_seconds = request.cooldown_seconds
    if request.max_retries is not None:
        if request.max_retries < 0:
            raise HTTPException(status_code=422, detail="max_retries must be >= 0")
        settings_row.max_retries = request.max_retries
    if request.backoff_seconds is not None:
        if request.backoff_seconds < 0:
            raise HTTPException(status_code=422, detail="backoff_seconds must be >= 0")
        settings_row.backoff_seconds = request.backoff_seconds
    if request.muted_until is not None:
        if request.muted_until == "":
            settings_row.muted_until = None
        else:
            try:
                parsed = datetime.fromisoformat(request.muted_until.replace("Z", "+00:00"))
                settings_row.muted_until = parsed.astimezone(timezone.utc)
            except Exception as exc:
                raise HTTPException(status_code=422, detail="muted_until must be ISO timestamp or empty string") from exc

    db.commit()
    db.refresh(settings_row)
    _audit(db, _session, "ALERT_NOTIFICATION_SETTINGS_UPDATE", resource_type="alert_settings")
    return _to_notification_settings_response(settings_row)


@router.post("/channels/{channel_id}/test", response_model=WebhookTestResponse)
async def test_notification_channel(
    channel_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> WebhookTestResponse:
    channel = db.get(NotificationChannel, channel_id)
    if not channel:
        raise HTTPException(status_code=404, detail="Notification channel not found")
    if channel.channel_type != "webhook":
        raise HTTPException(status_code=422, detail="Only webhook channels are supported")

    try:
        safe_target = validate_webhook_target(channel.target)
    except WebhookTargetValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    payload = build_test_webhook_payload(channel)

    try:
        async with httpx.AsyncClient(
            timeout=10.0,
            verify=resolve_webhook_tls_verify(channel.verify_ssl),
        ) as client:
            res = await client.post(safe_target, json=payload)
        ok = 200 <= res.status_code < 300
        _audit(db, _session, "ALERT_CHANNEL_TEST", resource_type="alert_channel", resource_name=channel.name)
        return WebhookTestResponse(
            status="sent" if ok else "failed",
            http_status=res.status_code,
            detail=None if ok else f"HTTP {res.status_code}",
        )
    except Exception as exc:
        return WebhookTestResponse(status="failed", http_status=None, detail=str(exc))


@router.get("/{alert_id}/timeline", response_model=AlertTimelineResponse)
async def get_alert_timeline(
    alert_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> AlertTimelineResponse:
    alert = db.get(Alert, alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")

    events: List[AlertTimelineEvent] = [
        AlertTimelineEvent(
            timestamp=alert.first_seen_at.isoformat(),
            event_type="created",
            message="Alert opened",
            detail=alert.description,
        ),
    ]

    if alert.acknowledged_at:
        events.append(
            AlertTimelineEvent(
                timestamp=alert.acknowledged_at.isoformat(),
                event_type="acknowledged",
                message="Alert acknowledged",
            )
        )
    if alert.resolved_at:
        events.append(
            AlertTimelineEvent(
                timestamp=alert.resolved_at.isoformat(),
                event_type="resolved",
                message="Alert resolved",
            )
        )

    deliveries = (
        db.query(AlertNotification)
        .filter(AlertNotification.alert_id == alert.id)
        .order_by(AlertNotification.created_at.asc())
        .all()
    )
    for delivery in deliveries:
        status = delivery.state
        detail = delivery.error_message or (
            f"HTTP {delivery.response_status}" if delivery.response_status is not None else None
        )
        events.append(
            AlertTimelineEvent(
                timestamp=(delivery.sent_at or delivery.created_at).isoformat(),
                event_type="notification",
                message=f"Webhook {status}",
                detail=detail,
            )
        )

    events_sorted = sorted(events, key=lambda e: e.timestamp)
    return AlertTimelineResponse(alert_id=alert.id, events=events_sorted)


@router.get("/snoozes", response_model=List[AlertSnoozeResponse])
async def list_alert_snoozes(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> List[AlertSnoozeResponse]:
    snoozes = db.query(AlertSnooze).order_by(AlertSnooze.muted_until.desc()).all()
    device_map = {d.id: d.name for d in db.query(Device).all()}
    group_map = {g.id: g.name for g in db.query(DeviceGroup).all()}
    return [
        _to_snooze_response(
            s,
            device_map.get(s.device_id) if s.device_id else None,
            group_map.get(s.group_id) if s.group_id else None,
        )
        for s in snoozes
    ]


@router.post("/snoozes", response_model=AlertSnoozeResponse, status_code=201)
async def create_alert_snooze(
    request: AlertSnoozeCreateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> AlertSnoozeResponse:
    if not request.device_id and not request.group_id:
        raise HTTPException(status_code=422, detail="Either device_id or group_id is required")

    try:
        muted_until = datetime.fromisoformat(request.muted_until.replace("Z", "+00:00")).astimezone(timezone.utc)
    except Exception as exc:
        raise HTTPException(status_code=422, detail="muted_until must be ISO timestamp") from exc

    if muted_until <= datetime.now(timezone.utc):
        raise HTTPException(status_code=422, detail="muted_until must be in the future")

    if request.device_id and not db.get(Device, request.device_id):
        raise HTTPException(status_code=404, detail="Device not found")
    if request.group_id and not db.get(DeviceGroup, request.group_id):
        raise HTTPException(status_code=404, detail="Group not found")

    snooze = AlertSnooze(
        device_id=request.device_id,
        group_id=request.group_id,
        alert_type=request.alert_type,
        muted_until=muted_until,
        reason=request.reason,
    )
    db.add(snooze)
    db.commit()
    db.refresh(snooze)
    _audit(db, _session, "ALERT_SNOOZE_CREATE", resource_type="alert_snooze")
    device = db.get(Device, snooze.device_id) if snooze.device_id else None
    group = db.get(DeviceGroup, snooze.group_id) if snooze.group_id else None
    return _to_snooze_response(snooze, device.name if device else None, group.name if group else None)


@router.delete("/snoozes/{snooze_id}")
async def delete_alert_snooze(
    snooze_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> Dict[str, str]:
    snooze = db.get(AlertSnooze, snooze_id)
    if not snooze:
        raise HTTPException(status_code=404, detail="Snooze not found")
    db.delete(snooze)
    db.commit()
    _audit(db, _session, "ALERT_SNOOZE_DELETE", resource_type="alert_snooze", resource_name=snooze_id)
    return {"status": "success"}
