from __future__ import annotations

import difflib
import hashlib
import io
import logging
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import paramiko
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import or_, func
from sqlalchemy.orm import Session

from database import BackupPolicy, Device, DeviceBackup, DeviceGroup, SshCredential, get_db, get_or_create_backup_policy
from routers.auth import get_current_admin, get_current_session
from services.ssh_utils import open_ssh_connection

router = APIRouter(prefix="/api/backups", tags=["backups"])
logger = logging.getLogger(__name__)

BACKUP_DIR = "/etc/flowmon/daily-backup/7days"


class BackupListItem(BaseModel):
    id: str
    device_id: str
    device_name: str
    group_name: Optional[str]
    created_at: str
    previous_backup_id: Optional[str]
    content_hash: str


class BackupContentResponse(BaseModel):
    id: str
    device_id: str
    device_name: str
    created_at: str
    content: str


class BackupDiffResponse(BaseModel):
    backup_id: str
    previous_backup_id: str
    diff: str


class BackupPolicyResponse(BaseModel):
    retention_mode: str  # "days" or "count"
    retention_value: int


class BackupPolicyUpdateRequest(BaseModel):
    retention_mode: str  # "days" or "count"
    retention_value: int


def _get_ssh_client(device: Device, cred: SshCredential) -> paramiko.SSHClient:
    return open_ssh_connection(device, cred)


def _backup_file_paths(client: paramiko.SSHClient) -> List[str]:
    find_latest = (
        f"find {BACKUP_DIR} -maxdepth 1 -type f -name '*.xml' "
        "-printf '%T@|%p\\n' 2>/dev/null | sort -nr || true"
    )
    _, stdout, _ = client.exec_command(find_latest)
    lines = stdout.read().decode("utf-8", errors="replace").strip().splitlines()
    result: List[str] = []
    for line in lines:
        if "|" not in line:
            continue
        path = line.split("|", 1)[1].strip()
        if path:
            result.append(path)
    return result


def _is_complete_xml(text: str) -> bool:
    trimmed = text.strip()
    if not trimmed.startswith("<"):
        return False
    try:
        ET.fromstring(trimmed)
        return True
    except ET.ParseError:
        return False


def _build_backup_content(device: Device, cred: SshCredential) -> str:
    client = _get_ssh_client(device, cred)
    try:
        backup_files = _backup_file_paths(client)
        if not backup_files:
            raise HTTPException(status_code=404, detail="No backup file found on device")
        sftp = client.open_sftp()
        try:
            fallback_text: Optional[str] = None
            for backup_file in backup_files[:10]:
                remote_file = sftp.open(backup_file, "rb")
                raw = remote_file.read()
                remote_file.close()
                text = io.TextIOWrapper(io.BytesIO(raw), encoding="utf-8", errors="replace").read()
                if fallback_text is None:
                    fallback_text = text
                if _is_complete_xml(text):
                    return text
        finally:
            sftp.close()
    finally:
        client.close()

    # If parsing fails for all candidates, return newest content as a fallback.
    if fallback_text is not None:
        return fallback_text
    raise HTTPException(status_code=404, detail="No readable backup file found on device")


def _content_hash(content: str) -> str:
    # Hash the normalized content so that timestamp-only changes do not create new snapshots.
    return hashlib.sha256(_normalized_backup_for_diff(content).encode("utf-8")).hexdigest()


def _local_tag_name(tag: str) -> str:
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


# Elements the device rewrites on its own schedule. They say nothing about the
# configuration, so they are dropped before hashing and diffing — otherwise
# every daily backup looks changed.
_VOLATILE_ELEMENTS = frozenset(
    {"timestamp", "lastactivity", "lastprocessed", "lastignored"}
)

# Elements that form an unordered set rather than an ordered list. The appliance
# exports these in whatever order the database returns, so the order changes
# between backups without anything being reconfigured. They are sorted into a
# canonical order so that a pure reshuffle is not reported as a change.
#
# This is deliberately a narrow allow-list: for genuinely ordered configuration
# (firewall rules, for example) a reordering IS a real change and must still be
# shown.
_UNORDERED_ELEMENTS = frozenset({"fp_rule"})


def _normalized_backup_for_diff(content: str) -> str:
    try:
        root = ET.fromstring(content)
    except ET.ParseError:
        return content

    if _local_tag_name(root.tag).lower() != "inveaosconfig":
        return content

    # Remove timestamp attribute from root (inveaosconfig)
    for attr_name in list(root.attrib.keys()):
        if attr_name.lower() == "timestamp":
            del root.attrib[attr_name]

    def _remove_volatile_elements(element, path=()):
        path = (*path, _local_tag_name(element.tag).lower())
        live_profile = (
            path == ("inveaosconfig", "flowmon", "monitoring-center", "profiles", "profile")
            and any(
                _local_tag_name(child.tag).lower() == "name"
                and (child.text or "").strip() == "live"
                for child in element
            )
        )
        for child in list(element):
            tag = _local_tag_name(child.tag).lower()
            if tag in _VOLATILE_ELEMENTS or (
                live_profile and tag in {"start-date", "end-date"}
            ):
                element.remove(child)
            else:
                _remove_volatile_elements(child, path)

    def _sort_unordered_elements(element):
        for child in element:
            _sort_unordered_elements(child)

        children = list(element)
        by_tag: dict[str, list[int]] = {}
        for index, child in enumerate(children):
            tag = _local_tag_name(child.tag).lower()
            if tag in _UNORDERED_ELEMENTS:
                by_tag.setdefault(tag, []).append(index)

        if not by_tag:
            return

        for indices in by_tag.values():
            if len(indices) < 2:
                continue
            group = [children[i] for i in indices]
            # The trailing whitespace belongs to the position, not the element:
            # the last item in a list carries the parent's closing indentation.
            # Moving it with its element would corrupt the layout and show up as
            # a spurious diff, so tails are reassigned by position.
            tails = [child.tail for child in group]
            group.sort(key=lambda el: ET.tostring(el, encoding="unicode"))
            for child, tail in zip(group, tails):
                child.tail = tail
            for index, child in zip(indices, group):
                children[index] = child

        element[:] = children

    # Volatile elements are removed first so that their values cannot influence
    # the sort order below.
    _remove_volatile_elements(root)
    _sort_unordered_elements(root)

    return ET.tostring(root, encoding="unicode")


def _apply_retention_policy(db: Session) -> None:
    """Delete old backups according to the configured retention policy."""
    from datetime import timedelta

    policy = get_or_create_backup_policy(db)

    if policy.retention_mode == "days":
        # Delete backups older than N days
        cutoff_date = datetime.now(timezone.utc) - timedelta(days=policy.retention_value)
        old_backups = db.query(DeviceBackup).filter(
            func.coalesce(DeviceBackup.last_verified_at, DeviceBackup.created_at) < cutoff_date
        ).all()
        for backup in old_backups:
            db.delete(backup)
    elif policy.retention_mode == "count":
        # Keep only the last N backups per device
        devices = db.query(Device).all()
        for device in devices:
            backups = (
                db.query(DeviceBackup)
                .filter(DeviceBackup.device_id == device.id)
                .order_by(DeviceBackup.created_at.desc())
                .all()
            )
            if len(backups) > policy.retention_value:
                for backup in backups[policy.retention_value:]:
                    db.delete(backup)

    db.commit()


async def run_daily_backups(db: Session) -> Dict[str, int]:
    devices = db.query(Device).order_by(Device.created_at).all()
    created = 0
    unchanged = 0
    failed = 0
    skipped = 0

    for device in devices:
        if not device.ssh_credential_id:
            skipped += 1
            continue
        cred = db.get(SshCredential, device.ssh_credential_id)
        if not cred:
            skipped += 1
            continue
        try:
            try:
                content = _build_backup_content(device, cred)
            except HTTPException as exc:
                logger.warning("Backup failed device_id=%s status=%s", device.id, exc.status_code)
                failed += 1
                continue
            except Exception:
                logger.exception("Backup failed device_id=%s", device.id)
                failed += 1
                continue

            hash_value = _content_hash(content)
            latest = (
                db.query(DeviceBackup)
                .filter(DeviceBackup.device_id == device.id)
                .order_by(DeviceBackup.created_at.desc())
                .first()
            )
            if latest:
                # Recompute the stored backup's hash instead of trusting the stored
                # value. Whenever the normalisation rules change, previously stored
                # hashes were produced by the old rules and would no longer compare
                # equal, so an unchanged configuration would be snapshotted again.
                # Recomputing keeps deduplication correct across such changes, and
                # the healed value is written back so it is only paid once.
                latest_hash = _content_hash(latest.content)
                if latest_hash != latest.content_hash:
                    latest.content_hash = latest_hash
                if latest_hash == hash_value:
                    latest.last_verified_at = datetime.now(timezone.utc)
                    unchanged += 1
                    continue

            db.add(DeviceBackup(device_id=device.id, content_hash=hash_value, content=content,
                                last_verified_at=datetime.now(timezone.utc)))
            created += 1
        finally:
            # Commit per-device: SSH backup collection is slow and holding
            # one write transaction across every device risks starving other
            # writers (e.g. an interactive device refresh) with SQLite
            # "database is locked" errors.
            db.commit()

    # Apply retention policy to cleanup old backups
    _apply_retention_policy(db)
    
    logger.info("Backup run completed devices=%d created=%d unchanged=%d failed=%d skipped=%d",
                len(devices), created, unchanged, failed, skipped)
    return {"devices": len(devices), "created": created, "unchanged": unchanged, "failed": failed, "skipped": skipped}


@router.post("/run")
async def run_backups_now(
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> Dict[str, int]:
    return await run_daily_backups(db)


@router.get("", response_model=List[BackupListItem])
async def list_backups(
    query: str = Query(default="", max_length=200),
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> List[BackupListItem]:
    devices = db.query(Device).all()
    groups = db.query(DeviceGroup).all()
    device_by_id = {d.id: d for d in devices}
    group_name_by_id = {g.id: g.name for g in groups}

    base_q = db.query(DeviceBackup).order_by(DeviceBackup.created_at.desc())
    if query.strip():
        pattern = f"%{query.strip()}%"
        base_q = base_q.outerjoin(Device, DeviceBackup.device_id == Device.id).filter(
            or_(DeviceBackup.content.ilike(pattern), Device.name.ilike(pattern))
        )
    backups = base_q.all()

    per_device_ordered: Dict[str, List[str]] = {}
    for b in backups:
        per_device_ordered.setdefault(b.device_id, []).append(b.id)

    previous_by_id: Dict[str, Optional[str]] = {}
    for ids in per_device_ordered.values():
        for idx, backup_id in enumerate(ids):
            previous_by_id[backup_id] = ids[idx + 1] if idx + 1 < len(ids) else None

    result: List[BackupListItem] = []
    for b in backups:
        device = device_by_id.get(b.device_id)
        group_name = group_name_by_id.get(device.group_id) if device and device.group_id else None
        result.append(
            BackupListItem(
                id=b.id,
                device_id=b.device_id,
                device_name=device.name if device else b.device_id,
                group_name=group_name,
                created_at=b.created_at.isoformat() if b.created_at else "",
                previous_backup_id=previous_by_id.get(b.id),
                content_hash=b.content_hash,
            )
        )
    return result


@router.get("/{backup_id}/content", response_model=BackupContentResponse)
async def get_backup_content(
    backup_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> BackupContentResponse:
    backup = db.get(DeviceBackup, backup_id)
    if not backup:
        raise HTTPException(status_code=404, detail="Backup not found")
    device = db.get(Device, backup.device_id)
    return BackupContentResponse(
        id=backup.id,
        device_id=backup.device_id,
        device_name=device.name if device else backup.device_id,
        created_at=backup.created_at.isoformat() if backup.created_at else "",
        content=backup.content,
    )


@router.get("/{backup_id}/diff", response_model=BackupDiffResponse)
async def get_backup_diff(
    backup_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> BackupDiffResponse:
    backup = db.get(DeviceBackup, backup_id)
    if not backup:
        raise HTTPException(status_code=404, detail="Backup not found")

    previous = (
        db.query(DeviceBackup)
        .filter(
            DeviceBackup.device_id == backup.device_id,
            DeviceBackup.created_at < backup.created_at,
        )
        .order_by(DeviceBackup.created_at.desc())
        .first()
    )
    if not previous:
        raise HTTPException(status_code=404, detail="No previous backup to compare")

    normalized_previous = _normalized_backup_for_diff(previous.content)
    normalized_backup = _normalized_backup_for_diff(backup.content)

    diff = "\n".join(
        difflib.unified_diff(
            normalized_previous.splitlines(),
            normalized_backup.splitlines(),
            fromfile=f"backup-{previous.id}",
            tofile=f"backup-{backup.id}",
            lineterm="",
        )
    )
    return BackupDiffResponse(backup_id=backup.id, previous_backup_id=previous.id, diff=diff)


@router.delete("/{backup_id}", status_code=204)
async def delete_backup(
    backup_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    backup = db.get(DeviceBackup, backup_id)
    if not backup:
        raise HTTPException(status_code=404, detail="Backup not found")
    db.delete(backup)
    db.commit()


@router.get("/policy", response_model=BackupPolicyResponse)
async def get_backup_policy(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> BackupPolicyResponse:
    policy = get_or_create_backup_policy(db)
    return BackupPolicyResponse(
        retention_mode=policy.retention_mode,
        retention_value=policy.retention_value,
    )


@router.put("/policy", response_model=BackupPolicyResponse)
async def update_backup_policy(
    request: BackupPolicyUpdateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> BackupPolicyResponse:
    if request.retention_mode not in ("days", "count"):
        raise HTTPException(
            status_code=400,
            detail="retention_mode must be 'days' or 'count'",
        )
    if request.retention_value < 1:
        raise HTTPException(
            status_code=400,
            detail="retention_value must be at least 1",
        )

    policy = get_or_create_backup_policy(db)
    policy.retention_mode = request.retention_mode
    policy.retention_value = request.retention_value
    db.commit()
    db.refresh(policy)

    return BackupPolicyResponse(
        retention_mode=policy.retention_mode,
        retention_value=policy.retention_value,
    )
