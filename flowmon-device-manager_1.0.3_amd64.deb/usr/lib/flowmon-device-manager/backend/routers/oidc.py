from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlsplit

import httpx
from authlib.integrations.httpx_client import AsyncOAuth2Client
from authlib.oauth2.rfc6749.errors import OAuth2Error
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from joserfc import jwt
from joserfc.errors import JoseError
from joserfc.jwk import KeySet
from joserfc.jwt import JWTClaimsRegistry
from sqlalchemy import delete
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from config import settings
from database import DeviceSession, OidcIdentity, OidcLoginAttempt, User, get_db
from routers.auth import _audit, _check_login_rate_limit, _create_session_jwt, _set_session_cookie

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth/oidc", tags=["auth"])
COOKIE_NAME = "fdm_oidc_browser"
ATTEMPT_LIFETIME = timedelta(minutes=5)


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _enabled() -> None:
    if not settings.oidc_enabled:
        raise HTTPException(status_code=404, detail="SSO is not enabled")


def _frontend_path() -> str:
    prefix = urlsplit(settings.oidc_redirect_uri).path.removesuffix("/api/auth/oidc/callback")
    return prefix.rstrip("/") + "/"


def _endpoint(metadata: dict, key: str) -> str:
    value = metadata.get(key)
    if not isinstance(value, str):
        raise ValueError(f"OIDC metadata is missing {key}")
    url = urlsplit(value)
    if url.scheme != "https" or not url.hostname or url.username or url.password or url.fragment:
        raise ValueError(f"Invalid OIDC {key}")
    return value


async def _metadata() -> dict:
    async with httpx.AsyncClient(timeout=15, trust_env=False, follow_redirects=False) as client:
        response = await client.get(f"{settings.oidc_issuer.rstrip('/')}/.well-known/openid-configuration")
        response.raise_for_status()
        metadata = response.json()
    if not isinstance(metadata, dict) or metadata.get("issuer") != settings.oidc_issuer:
        raise ValueError("OIDC discovery issuer mismatch")
    for key in ("authorization_endpoint", "token_endpoint", "jwks_uri"):
        _endpoint(metadata, key)
    return metadata


async def _exchange(code: str, verifier: str, nonce: str) -> tuple[str, str]:
    metadata = await _metadata()
    methods = metadata.get("token_endpoint_auth_methods_supported", ["client_secret_basic"])
    if not isinstance(methods, list):
        raise ValueError("Invalid OIDC token endpoint authentication methods")
    auth_method = next(
        (method for method in ("client_secret_basic", "client_secret_post") if method in methods),
        None,
    )
    if not auth_method:
        raise ValueError("OIDC provider does not support a confidential client secret")
    async with AsyncOAuth2Client(
        settings.oidc_client_id,
        settings.oidc_client_secret.get_secret_value(),
        token_endpoint_auth_method=auth_method,
        redirect_uri=settings.oidc_redirect_uri,
        trust_env=False,
        timeout=15,
        follow_redirects=False,
    ) as client:
        token = await client.fetch_token(
            _endpoint(metadata, "token_endpoint"), code=code,
            code_verifier=verifier, grant_type="authorization_code",
        )
    id_token = token.get("id_token")
    if not isinstance(id_token, str):
        raise ValueError("OIDC response is missing an ID token")
    async with httpx.AsyncClient(timeout=15, trust_env=False, follow_redirects=False) as client:
        response = await client.get(_endpoint(metadata, "jwks_uri"))
        response.raise_for_status()
        keys = KeySet.import_key_set(response.json())
    verified = jwt.decode(
        id_token, keys,
        algorithms=["RS256", "RS384", "RS512", "PS256", "PS384", "PS512", "ES256", "ES384", "ES512"],
    )
    claims = verified.claims
    JWTClaimsRegistry(
        iss={"essential": True, "value": settings.oidc_issuer},
        aud={"essential": True, "value": settings.oidc_client_id},
        exp={"essential": True},
        iat={"essential": True},
        sub={"essential": True},
        nonce={"essential": True, "value": nonce},
        leeway=60,
    ).validate(claims)
    subject = claims.get("sub")
    audience = claims.get("aud")
    if not isinstance(subject, str) or not subject or len(subject) > 255:
        raise ValueError("Invalid OIDC subject")
    if isinstance(audience, list) and len(audience) > 1 and claims.get("azp") != settings.oidc_client_id:
        raise ValueError("Invalid OIDC authorized party")
    if "azp" in claims and claims["azp"] != settings.oidc_client_id:
        raise ValueError("Invalid OIDC authorized party")
    return settings.oidc_issuer, subject


@router.get("/config")
def oidc_config() -> dict:
    return {"enabled": settings.oidc_enabled}


@router.get("/login")
async def oidc_login(request: Request, db: Session = Depends(get_db)):
    _enabled()
    await _check_login_rate_limit(request.client.host if request.client else "unknown")
    try:
        metadata = await _metadata()
        state = secrets.token_urlsafe(32)
        browser = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        async with AsyncOAuth2Client(
            settings.oidc_client_id, redirect_uri=settings.oidc_redirect_uri,
            scope="openid", code_challenge_method="S256",
        ) as client:
            url, _ = client.create_authorization_url(
                _endpoint(metadata, "authorization_endpoint"), state=state,
                nonce=nonce, code_verifier=verifier,
            )
        now = datetime.now(timezone.utc)
        db.execute(delete(OidcLoginAttempt).where(OidcLoginAttempt.expires_at < now))
        db.add(OidcLoginAttempt(
            state_hash=_digest(state), browser_hash=_digest(browser), nonce=nonce,
            verifier=verifier, expires_at=now + ATTEMPT_LIFETIME,
        ))
        db.commit()
        response = RedirectResponse(url, status_code=302, headers={"Cache-Control": "no-store"})
        response.set_cookie(
            COOKIE_NAME, browser, max_age=int(ATTEMPT_LIFETIME.total_seconds()),
            httponly=True, secure=True, samesite="lax",
            path=urlsplit(settings.oidc_redirect_uri).path,
        )
        return response
    except (httpx.HTTPError, ValueError, KeyError) as exc:
        logger.warning("OIDC login could not start: %s", type(exc).__name__)
        raise HTTPException(status_code=503, detail="SSO provider is unavailable or misconfigured") from None


@router.get("/callback")
async def oidc_callback(request: Request, db: Session = Depends(get_db)):
    _enabled()
    state = request.query_params.get("state", "")
    code = request.query_params.get("code", "")
    browser = request.cookies.get(COOKIE_NAME, "")
    failure_url = _frontend_path().rstrip("/") + "/login?oidc_error=1"
    response = RedirectResponse(failure_url, status_code=303, headers={"Cache-Control": "no-store"})
    response.delete_cookie(COOKIE_NAME, path=urlsplit(settings.oidc_redirect_uri).path, secure=True, httponly=True, samesite="lax")
    if not state or not browser or not code:
        logger.warning("OIDC callback missing state, browser binding, or authorization code")
        return response
    state_hash = _digest(state)
    attempt = db.get(OidcLoginAttempt, state_hash)
    if (
        not attempt or not hmac.compare_digest(attempt.browser_hash, _digest(browser))
        or attempt.expires_at.replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc)
    ):
        logger.warning("OIDC callback state invalid or expired")
        return response
    verifier, nonce = attempt.verifier, attempt.nonce
    consumed = db.execute(
        delete(OidcLoginAttempt).where(
            OidcLoginAttempt.state_hash == state_hash,
            OidcLoginAttempt.browser_hash == _digest(browser),
        )
    ).rowcount
    db.commit()
    if consumed != 1:
        logger.warning("OIDC callback state already consumed")
        return response
    try:
        issuer, subject = await _exchange(code, verifier, nonce)
        identity = db.query(OidcIdentity).filter_by(issuer=issuer, subject=subject).first()
        user = db.get(User, identity.user_id) if identity else None
        if not identity and settings.oidc_auto_provision:
            user = User(
                username=f"sso-{uuid.uuid4().hex}", password_hash="!",
                is_admin=0, disabled=0, must_change_password=0,
            )
            db.add(user)
            db.flush()
            db.add(OidcIdentity(issuer=issuer, subject=subject, user_id=user.id))
        if not user or user.disabled or user.must_change_password:
            logger.warning("OIDC login denied: identity not approved, disabled, or password change required")
            return response
        expires = datetime.now(timezone.utc) + timedelta(hours=settings.access_token_expire_hours)
        session_id = str(uuid.uuid4())
        db.add(DeviceSession(id=session_id, username=user.username, expires_at=expires))
        db.commit()
        response = RedirectResponse(_frontend_path(), status_code=303, headers={"Cache-Control": "no-store"})
        response.delete_cookie(COOKIE_NAME, path=urlsplit(settings.oidc_redirect_uri).path, secure=True, httponly=True, samesite="lax")
        _set_session_cookie(response, _create_session_jwt(session_id, user.username, expires))
        _audit(db, username=user.username, action="LOGIN", ip="oidc")
        return response
    except (httpx.HTTPError, OAuth2Error, JoseError, ValueError, KeyError, IntegrityError) as exc:
        db.rollback()
        logger.warning("OIDC login failed: %s", type(exc).__name__)
        return response
