"""Device performance statistics (perfmon) API."""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import delete
from sqlalchemy.orm import Session

from database import (
    AlertRule,
    Device,
    DevicePerfAlertRule,
    DevicePerfInterfaceSample,
    DevicePerfSample,
    SshCredential,
    engine,
    get_db,
)
from config import settings
from routers.auth import get_current_admin, get_current_session
from services.perf_alerts import (
    ABOVE,
    BELOW,
    DEFAULT_CONSECUTIVE_SAMPLES,
    get_metric,
    resolve_rules,
    serialize_rules,
)
from services.perfmon import (
    PerfCollectionError,
    _interface_index,
    collect_device_perf,
)

router = APIRouter(prefix="/api/devices", tags=["performance"])

logger = logging.getLogger(__name__)


def _audit(db: Session, session, action: str, **kwargs) -> None:
    from routers.audit import write_audit

    write_audit(db, username=session.username, action=action, **kwargs)

# How long samples are kept before the collector prunes them.
RETENTION_DAYS = 30


class PerfSampleResponse(BaseModel):
    collected_at: str
    disk_percent: Optional[float] = None
    disk_inode_percent: Optional[float] = None
    disk_tps: Optional[float] = None
    disk_util: Optional[float] = None
    cpu_user: Optional[float] = None
    cpu_system: Optional[float] = None
    cpu_iowait: Optional[float] = None
    mem_free_percent: Optional[float] = None
    mem_total_bytes: Optional[float] = None
    mem_available_bytes: Optional[float] = None
    fps: Optional[float] = None
    ads_events: Optional[float] = None
    data_lifetime_days: Optional[float] = None
    # Cumulative counter as read from the device, plus the increase since the
    # previous sample (None when there is no previous sample, or when the
    # counter went backwards because the device rebooted).
    udp_buffer_errors: Optional[float] = None
    udp_buffer_errors_delta: Optional[float] = None
    # Probe / exporter metrics
    probe_pkt_per_sec: Optional[float] = None
    probe_bytes_per_sec: Optional[float] = None
    probe_skipped_pkt_per_sec: Optional[float] = None
    # Cumulative interface counters, plus the rates derived from the gap to the
    # previous sample (rates are more useful than raw deltas here because the
    # sampling interval varies between scheduled and on-demand collection).
    iface_rx_packets: Optional[float] = None
    iface_rx_dropped: Optional[float] = None
    iface_rx_errors: Optional[float] = None
    iface_rx_packets_per_sec: Optional[float] = None
    iface_rx_dropped_per_sec: Optional[float] = None
    iface_rx_errors_per_sec: Optional[float] = None


class PerfInterfacePoint(BaseModel):
    collected_at: str
    rx_packets: Optional[float] = None
    rx_dropped: Optional[float] = None
    rx_errors: Optional[float] = None
    rx_packets_per_sec: Optional[float] = None
    rx_dropped_per_sec: Optional[float] = None
    rx_errors_per_sec: Optional[float] = None
    rx_bits_per_sec: Optional[float] = None


class PerfInterfaceSeries(BaseModel):
    """One monitored interface and its history over the requested range."""

    name: str
    kernel_name: Optional[str] = None
    is_monitoring: bool
    speed_mbps: Optional[float] = None
    licensed_speed_mbps: Optional[float] = None
    points: List[PerfInterfacePoint]


class PerfSeriesResponse(BaseModel):
    device_id: str
    device_name: str
    hours: int
    samples: List[PerfSampleResponse]
    interfaces: List[PerfInterfaceSeries] = []


def _to_response(
    s: DevicePerfSample, previous: Optional[DevicePerfSample] = None
) -> PerfSampleResponse:
    seconds = _elapsed_seconds(s, previous)
    return PerfSampleResponse(
        collected_at=s.collected_at.isoformat() if s.collected_at else "",
        disk_percent=s.disk_percent,
        disk_inode_percent=s.disk_inode_percent,
        disk_tps=s.disk_tps,
        disk_util=s.disk_util,
        cpu_user=s.cpu_user,
        cpu_system=s.cpu_system,
        cpu_iowait=s.cpu_iowait,
        mem_free_percent=s.mem_free_percent,
        mem_total_bytes=s.mem_total_bytes,
        mem_available_bytes=s.mem_available_bytes,
        fps=s.fps,
        ads_events=s.ads_events,
        data_lifetime_days=s.data_lifetime_days,
        udp_buffer_errors=s.udp_buffer_errors,
        udp_buffer_errors_delta=_counter_delta(
            s.udp_buffer_errors, previous.udp_buffer_errors if previous else None
        ),
        probe_pkt_per_sec=s.probe_pkt_per_sec,
        probe_bytes_per_sec=s.probe_bytes_per_sec,
        probe_skipped_pkt_per_sec=s.probe_skipped_pkt_per_sec,
        iface_rx_packets=s.iface_rx_packets,
        iface_rx_dropped=None,
        iface_rx_errors=s.iface_rx_errors,
        iface_rx_packets_per_sec=_counter_rate(
            s.iface_rx_packets, previous.iface_rx_packets if previous else None, seconds
        ),
        iface_rx_dropped_per_sec=None,
        iface_rx_errors_per_sec=_counter_rate(
            s.iface_rx_errors, previous.iface_rx_errors if previous else None, seconds
        ),
    )


def _build_interface_series(
    rows: List[DevicePerfInterfaceSample],
) -> List[PerfInterfaceSeries]:
    """Group per-interface rows into one time series per interface.

    Cumulative kernel counters are converted to per-second rates against the
    actual gap between consecutive samples of that same interface.
    """
    by_name: dict[str, List[DevicePerfInterfaceSample]] = {}
    for row in rows:
        by_name.setdefault(row.name, []).append(row)

    series: List[PerfInterfaceSeries] = []
    for name, iface_rows in by_name.items():
        iface_rows.sort(key=lambda r: r.collected_at or datetime.min)
        points: List[PerfInterfacePoint] = []
        for index, row in enumerate(iface_rows):
            previous = iface_rows[index - 1] if index else None
            seconds = _elapsed_seconds(row, previous)
            byte_rate = _counter_rate(
                row.rx_bytes, previous.rx_bytes if previous else None, seconds
            )
            points.append(
                PerfInterfacePoint(
                    collected_at=row.collected_at.isoformat() if row.collected_at else "",
                    rx_packets=row.rx_packets,
                    rx_dropped=None,
                    rx_errors=row.rx_errors,
                    rx_packets_per_sec=_counter_rate(
                        row.rx_packets, previous.rx_packets if previous else None, seconds
                    ),
                    rx_dropped_per_sec=None,
                    rx_errors_per_sec=_counter_rate(
                        row.rx_errors, previous.rx_errors if previous else None, seconds
                    ),
                    rx_bits_per_sec=None if byte_rate is None else round(byte_rate * 8, 2),
                )
            )
        latest = iface_rows[-1]
        series.append(
            PerfInterfaceSeries(
                name=name,
                kernel_name=latest.kernel_name,
                is_monitoring=bool(latest.is_monitoring),
                speed_mbps=latest.speed_mbps,
                licensed_speed_mbps=latest.licensed_speed_mbps,
                points=points,
            )
        )

    series.sort(key=lambda s: (not s.is_monitoring, _interface_index(s.name) or 0, s.name))
    return series


def _counter_delta(current: Optional[float], previous: Optional[float]) -> Optional[float]:
    """Increase of a monotonic counter, or None if it is not derivable.

    A counter that went backwards means the device rebooted, in which case the
    increase is unknown rather than zero.
    """
    if current is None or previous is None or current < previous:
        return None
    return current - previous


def _elapsed_seconds(
    sample: DevicePerfSample, previous: Optional[DevicePerfSample]
) -> Optional[float]:
    if previous is None or sample.collected_at is None or previous.collected_at is None:
        return None
    current_at, previous_at = sample.collected_at, previous.collected_at
    # SQLite hands back naive datetimes; treat those as UTC so the subtraction
    # cannot fail on mixed awareness.
    if (current_at.tzinfo is None) != (previous_at.tzinfo is None):
        current_at = current_at.replace(tzinfo=current_at.tzinfo or timezone.utc)
        previous_at = previous_at.replace(tzinfo=previous_at.tzinfo or timezone.utc)
    seconds = (current_at - previous_at).total_seconds()
    return seconds if seconds > 0 else None


def _counter_rate(
    current: Optional[float], previous: Optional[float], seconds: Optional[float]
) -> Optional[float]:
    """Per-second rate of a monotonic counter between two samples."""
    delta = _counter_delta(current, previous)
    if delta is None or not seconds:
        return None
    return round(delta / seconds, 2)


def _get_ssh_cred(device: Device, db: Session) -> SshCredential:
    if not device.ssh_credential_id:
        raise HTTPException(
            status_code=400,
            detail="This device has no SSH credential assigned. Performance statistics are collected over SSH.",
        )
    cred = db.get(SshCredential, device.ssh_credential_id)
    if not cred:
        raise HTTPException(status_code=422, detail="SSH credential not found — it may have been deleted")
    return cred


def store_sample(db: Session, device: Device, sample) -> DevicePerfSample:
    collected_at = datetime.now(timezone.utc)
    # The primary-key default is only applied on flush, but the child rows need
    # the id now, so it is generated up front.
    sample_id = str(uuid.uuid4())
    row = DevicePerfSample(
        id=sample_id,
        device_id=device.id,
        collected_at=collected_at,
        **sample.as_dict(),
    )
    db.add(row)
    for iface in getattr(sample, "interfaces", []):
        db.add(
            DevicePerfInterfaceSample(
                sample_id=sample_id,
                device_id=device.id,
                collected_at=collected_at,
                name=iface.name,
                kernel_name=iface.kernel_name,
                is_monitoring=1 if iface.is_monitoring else 0,
                speed_mbps=iface.speed_mbps,
                licensed_speed_mbps=iface.licensed_speed_mbps,
                rx_bytes=iface.rx_bytes,
                rx_packets=iface.rx_packets,
                rx_errors=iface.rx_errors,
                rx_dropped=iface.rx_dropped,
            )
        )
    return row


def prune_old_samples(db: Session, retention_days: int = RETENTION_DAYS) -> int:
    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    # SQLite only honours ON DELETE CASCADE when foreign keys are enforced, and
    # a Core delete() bypasses ORM cascades either way, so child rows are
    # removed explicitly.
    db.execute(
        delete(DevicePerfInterfaceSample).where(
            DevicePerfInterfaceSample.collected_at < cutoff
        )
    )
    result = db.execute(
        delete(DevicePerfSample).where(DevicePerfSample.collected_at < cutoff)
    )
    return result.rowcount or 0


@router.get("/{device_id}/perf", response_model=PerfSeriesResponse)
async def get_device_perf(
    device_id: str,
    hours: int = Query(24, ge=1, le=720),
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
):
    """Return collected performance samples for a device."""
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    since = datetime.now(timezone.utc) - timedelta(hours=hours)
    rows = (
        db.query(DevicePerfSample)
        .filter(DevicePerfSample.device_id == device_id)
        .filter(DevicePerfSample.collected_at >= since)
        .order_by(DevicePerfSample.collected_at)
        .all()
    )
    # Pair each sample with its predecessor so cumulative counters can be
    # reported as per-interval increases.
    samples = [
        _to_response(row, rows[idx - 1] if idx else None)
        for idx, row in enumerate(rows)
    ]
    iface_rows = (
        db.query(DevicePerfInterfaceSample)
        .filter(DevicePerfInterfaceSample.device_id == device_id)
        .filter(DevicePerfInterfaceSample.collected_at >= since)
        .order_by(DevicePerfInterfaceSample.collected_at)
        .all()
    )
    return PerfSeriesResponse(
        device_id=device.id,
        device_name=device.name,
        hours=hours,
        samples=samples,
        interfaces=_build_interface_series(iface_rows),
    )


@router.post("/{device_id}/perf/collect", response_model=PerfSampleResponse)
async def collect_device_perf_now(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    """Take an immediate performance sample from the device."""
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    cred = _get_ssh_cred(device, db)

    try:
        sample = await asyncio.to_thread(collect_device_perf, device, cred)
    except PerfCollectionError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    previous = (
        db.query(DevicePerfSample)
        .filter(DevicePerfSample.device_id == device_id)
        .order_by(DevicePerfSample.collected_at.desc())
        .first()
    )
    row = store_sample(db, device, sample)
    db.commit()
    db.refresh(row)
    return _to_response(row, previous)


@router.delete("/{device_id}/perf", status_code=204)
async def clear_device_perf(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    """Delete all stored performance samples for a device."""
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    db.execute(
        delete(DevicePerfInterfaceSample).where(
            DevicePerfInterfaceSample.device_id == device_id
        )
    )
    db.execute(delete(DevicePerfSample).where(DevicePerfSample.device_id == device_id))
    db.commit()


class PerfAlertRuleResponse(BaseModel):
    metric: str
    label: str
    unit: str
    direction: str
    kind: str
    description: str
    probe_only: bool
    enabled: bool
    warning_threshold: Optional[float] = None
    critical_threshold: Optional[float] = None
    consecutive_samples: int
    default_enabled: bool
    default_warning: Optional[float] = None
    default_critical: Optional[float] = None
    is_default: bool


class PerfAlertRulesResponse(BaseModel):
    device_id: str
    device_name: str
    # False when the global `perf_threshold` alert rule is switched off, in
    # which case none of these thresholds are evaluated.
    alerting_enabled: bool
    collect_interval_minutes: int
    rules: List[PerfAlertRuleResponse]


class PerfAlertRuleUpdate(BaseModel):
    metric: str
    enabled: Optional[bool] = None
    warning_threshold: Optional[float] = None
    critical_threshold: Optional[float] = None
    consecutive_samples: Optional[int] = None
    # Explicitly clear a threshold back to the shipped default, which a plain
    # null cannot express because null also means "field not supplied".
    reset_warning: bool = False
    reset_critical: bool = False


class PerfAlertRulesUpdateRequest(BaseModel):
    rules: List[PerfAlertRuleUpdate]


def _perf_alerting_enabled(db: Session) -> bool:
    rule = (
        db.query(AlertRule)
        .filter(AlertRule.alert_type == "perf_threshold")
        .first()
    )
    return bool(rule.enabled) if rule else True


def _perf_rules_payload(db: Session, device: Device) -> PerfAlertRulesResponse:
    overrides = (
        db.query(DevicePerfAlertRule)
        .filter(DevicePerfAlertRule.device_id == device.id)
        .all()
    )
    return PerfAlertRulesResponse(
        device_id=device.id,
        device_name=device.name,
        alerting_enabled=_perf_alerting_enabled(db),
        collect_interval_minutes=settings.perf_collect_interval_minutes,
        rules=[PerfAlertRuleResponse(**r) for r in serialize_rules(resolve_rules(overrides))],
    )


def _validate_thresholds(
    metric_key: str, warning: Optional[float], critical: Optional[float]
) -> None:
    """Reject thresholds that could never fire in the expected order.

    Which of the two must be larger depends on the metric's direction: disk
    usage is critical when *high*, free memory when *low*.
    """
    metric = get_metric(metric_key)
    if metric is None or warning is None or critical is None:
        return
    if metric.direction == BELOW and critical > warning:
        raise HTTPException(
            status_code=422,
            detail=f"{metric.label}: critical threshold must be <= warning threshold",
        )
    if metric.direction == ABOVE and critical < warning:
        raise HTTPException(
            status_code=422,
            detail=f"{metric.label}: critical threshold must be >= warning threshold",
        )


@router.get("/{device_id}/perf/alert-rules", response_model=PerfAlertRulesResponse)
async def get_device_perf_alert_rules(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
):
    """Effective performance alert thresholds for a device."""
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return _perf_rules_payload(db, device)


@router.put("/{device_id}/perf/alert-rules", response_model=PerfAlertRulesResponse)
async def update_device_perf_alert_rules(
    device_id: str,
    request: PerfAlertRulesUpdateRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    """Override performance alert thresholds for a device.

    Only metrics present in the request are touched. An override row is
    written per metric; a row matching the shipped defaults is deleted so the
    device transparently follows any future change to those defaults.
    """
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    existing = {
        row.metric: row
        for row in db.query(DevicePerfAlertRule)
        .filter(DevicePerfAlertRule.device_id == device_id)
        .all()
    }

    for update in request.rules:
        metric = get_metric(update.metric)
        if metric is None:
            raise HTTPException(status_code=422, detail=f"Unknown metric: {update.metric}")

        row = existing.get(update.metric)
        # Start from the metric's current effective values so a partial
        # update doesn't silently reset the fields it omits.
        enabled = bool(row.enabled) if row else metric.enabled
        warning = (row.warning_threshold if row else metric.warning)
        critical = (row.critical_threshold if row else metric.critical)
        consecutive = (row.consecutive_samples if row else DEFAULT_CONSECUTIVE_SAMPLES)

        if update.enabled is not None:
            enabled = update.enabled
        if update.reset_warning:
            warning = metric.warning
        elif update.warning_threshold is not None:
            warning = update.warning_threshold
        if update.reset_critical:
            critical = metric.critical
        elif update.critical_threshold is not None:
            critical = update.critical_threshold
        if update.consecutive_samples is not None:
            if not 1 <= update.consecutive_samples <= 100:
                raise HTTPException(
                    status_code=422,
                    detail="consecutive_samples must be between 1 and 100",
                )
            consecutive = update.consecutive_samples

        for value, name in ((warning, "warning"), (critical, "critical")):
            if value is not None and value < 0:
                raise HTTPException(
                    status_code=422, detail=f"{name}_threshold must be >= 0"
                )
        _validate_thresholds(update.metric, warning, critical)

        is_default = (
            enabled == metric.enabled
            and warning == metric.warning
            and critical == metric.critical
            and consecutive == DEFAULT_CONSECUTIVE_SAMPLES
        )
        if is_default:
            if row is not None:
                db.delete(row)
                existing.pop(update.metric, None)
            continue

        if row is None:
            row = DevicePerfAlertRule(device_id=device_id, metric=update.metric)
            db.add(row)
            existing[update.metric] = row
        row.enabled = 1 if enabled else 0
        row.warning_threshold = warning
        row.critical_threshold = critical
        row.consecutive_samples = consecutive

    db.commit()
    _audit(
        db,
        _session,
        "PERF_ALERT_RULES_UPDATE",
        resource_type="device",
        resource_name=device.name,
        details={"device_id": device.id},
    )
    return _perf_rules_payload(db, device)


async def collect_all_devices_perf(db: Optional[Session] = None) -> tuple[int, int]:
    """Sample every device that has an SSH credential. Returns (attempted, succeeded)."""
    if db is not None:
        return await _collect_all_devices_perf_impl(db)
    with Session(engine) as session:
        return await _collect_all_devices_perf_impl(session)


async def _collect_all_devices_perf_impl(db: Session) -> tuple[int, int]:
    # 1. Read the list of devices and credentials while holding the DB read briefly
    devices_info = []
    for d in db.query(Device).all():
        if d.ssh_credential_id:
            cred = db.get(SshCredential, d.ssh_credential_id)
            if cred:
                devices_info.append((d, cred))

    # 2. Collect SSH samples asynchronously without holding a DB transaction
    collected: list[tuple[str, Any]] = []
    for device, cred in devices_info:
        try:
            sample = await asyncio.to_thread(collect_device_perf, device, cred)
            collected.append((device.id, sample))
        except PerfCollectionError as exc:
            logger.info("Perf collection skipped for %s: %s", device.name, exc)
            continue
        except Exception:
            logger.exception("Unexpected error collecting performance for %s", device.name)
            continue

    # 3. Store the collected samples in DB quickly
    succeeded = 0
    with Session(engine) as session:
        for device_id, sample in collected:
            dev = session.get(Device, device_id)
            if dev:
                store_sample(session, dev, sample)
                succeeded += 1
        prune_old_samples(session)
        session.commit()

    return len(devices_info), succeeded
