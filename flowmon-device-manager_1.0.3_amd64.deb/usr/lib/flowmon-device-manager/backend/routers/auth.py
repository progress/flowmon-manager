from __future__ import annotations

import asyncio
import uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Cookie, Depends, HTTPException, Request, Response, status
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy.orm import Session

from config import settings
from database import DeviceSession, User, get_db, hash_password, purge_expired_sessions, verify_password
from services.app_logging import clear_bootstrap_admin_password

router = APIRouter(prefix="/api/auth", tags=["auth"])

# Lazy import to avoid circular imports
def _audit(db, username, action, ip="unknown", **kwargs):
    from routers.audit import write_audit
    write_audit(db, username=username, action=action, ip_address=ip, **kwargs)

# Simple in-memory rate limiter: max 10 login attempts per IP per minute
_login_attempts: dict[str, list[datetime]] = defaultdict(list)
_RATE_LIMIT = 10
_RATE_WINDOW = timedelta(minutes=1)
_rate_limit_lock = asyncio.Lock()


async def _check_login_rate_limit(client_ip: str) -> None:
    async with _rate_limit_lock:
        now = datetime.now(timezone.utc)
        cutoff = now - _RATE_WINDOW
        recent = [t for t in _login_attempts[client_ip] if t > cutoff]
        if len(recent) >= _RATE_LIMIT:
            raise HTTPException(status_code=429, detail="Too many login attempts. Try again later.")
        recent.append(now)
        _login_attempts[client_ip] = recent

COOKIE_NAME = "fdm_session"
ALGORITHM = "HS256"


# ---------- Pydantic models ----------

class LoginRequest(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    username: str
    is_admin: bool
    must_change_password: bool


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


# ---------- JWT helpers ----------

def _create_session_jwt(session_id: str, username: str, expires_at: datetime) -> str:
    payload = {
        "sub": username,
        "session_id": session_id,
        "exp": expires_at,
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)


def _decode_session_jwt(token: str) -> dict:
    return jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])


# ---------- Cookie helpers ----------

def _set_session_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key=COOKIE_NAME,
        value=token,
        httponly=True,
        samesite="strict",
        secure=settings.production,
        max_age=settings.access_token_expire_hours * 3600,
        path="/",
    )


def _clear_session_cookie(response: Response) -> None:
    response.delete_cookie(key=COOKIE_NAME, path="/")


# ---------- Session dependency ----------

def get_current_session(
    fdm_session: Optional[str] = Cookie(default=None),
    db: Session = Depends(get_db),
) -> DeviceSession:
    session = _get_current_session(fdm_session, db)
    user = db.query(User).filter(User.username == session.username).first()
    if user is None or user.disabled:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    if user.must_change_password:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Password change required",
        )
    return session


def _get_current_session(
    fdm_session: Optional[str],
    db: Session,
) -> DeviceSession:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
    )
    if not fdm_session:
        raise credentials_exception

    try:
        payload = _decode_session_jwt(fdm_session)
        session_id: str = payload.get("session_id")
        if not session_id:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    session = db.get(DeviceSession, session_id)
    if session is None:
        raise credentials_exception
    if session.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        db.delete(session)
        db.commit()
        raise credentials_exception

    return session


def get_current_session_for_password_change(
    fdm_session: Optional[str] = Cookie(default=None),
    db: Session = Depends(get_db),
) -> DeviceSession:
    session = _get_current_session(fdm_session, db)
    user = db.query(User).filter(User.username == session.username).first()
    if user is None or user.disabled:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    return session


def get_current_user(
    session: DeviceSession = Depends(get_current_session),
    db: Session = Depends(get_db),
) -> User:
    """Resolve the full local User row for the current session, rejecting
    disabled/deleted accounts even if their session cookie is still valid."""
    user = db.query(User).filter(User.username == session.username).first()
    if user is None or user.disabled:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    return user


def get_current_user_for_password_change(
    session: DeviceSession = Depends(get_current_session_for_password_change),
    db: Session = Depends(get_db),
) -> User:
    user = db.query(User).filter(User.username == session.username).first()
    if user is None or user.disabled:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    return user


async def get_current_admin(user: User = Depends(get_current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin privileges required")
    return user


def _to_user_response(user: User) -> UserResponse:
    return UserResponse(
        username=user.username,
        is_admin=bool(user.is_admin),
        must_change_password=bool(user.must_change_password),
    )


def _invalidate_sessions(db: Session, username: str) -> None:
    db.query(DeviceSession).filter(DeviceSession.username == username).delete()
    db.commit()


# ---------- Endpoints ----------

@router.post("/login", response_model=UserResponse)
async def login(
    request: Request,
    body: LoginRequest,
    response: Response,
    db: Session = Depends(get_db),
) -> UserResponse:
    client_ip = request.client.host if request.client else "unknown"
    await _check_login_rate_limit(client_ip)

    user = db.query(User).filter(User.username == body.username).first()
    if user is None or user.disabled or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username or password")

    expires_at = datetime.now(timezone.utc) + timedelta(hours=settings.access_token_expire_hours)
    session_id = str(uuid.uuid4())

    db_session = DeviceSession(
        id=session_id,
        username=user.username,
        expires_at=expires_at,
    )
    db.add(db_session)
    purge_expired_sessions(db)
    db.commit()

    jwt_token = _create_session_jwt(session_id, user.username, expires_at)
    _set_session_cookie(response, jwt_token)
    _audit(db, username=user.username, action="LOGIN", ip=client_ip)
    return _to_user_response(user)


@router.get("/me", response_model=UserResponse)
async def me(
    user: User = Depends(get_current_user_for_password_change),
) -> UserResponse:
    return _to_user_response(user)


@router.post("/logout")
async def logout(
    response: Response,
    session: DeviceSession = Depends(get_current_session_for_password_change),
    db: Session = Depends(get_db),
) -> dict:
    db.delete(session)
    db.commit()
    _audit(db, username=session.username, action="LOGOUT")
    _clear_session_cookie(response)
    return {"detail": "Logged out"}


@router.post("/change-password", response_model=UserResponse)
async def change_password(
    body: ChangePasswordRequest,
    response: Response,
    user: User = Depends(get_current_user_for_password_change),
    session: DeviceSession = Depends(get_current_session_for_password_change),
    db: Session = Depends(get_db),
) -> UserResponse:
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Current password is incorrect")
    if len(body.new_password) < 8:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="New password must be at least 8 characters")

    user.password_hash = hash_password(body.new_password)
    user.must_change_password = 0
    db.commit()
    if user.username == "admin":
        clear_bootstrap_admin_password()

    # Invalidate every other session for this user; keep the caller logged in
    # by re-issuing a fresh cookie tied to a new session row.
    db.query(DeviceSession).filter(
        DeviceSession.username == user.username,
        DeviceSession.id != session.id,
    ).delete()
    db.delete(session)
    expires_at = datetime.now(timezone.utc) + timedelta(hours=settings.access_token_expire_hours)
    new_session_id = str(uuid.uuid4())
    db.add(DeviceSession(id=new_session_id, username=user.username, expires_at=expires_at))
    db.commit()

    jwt_token = _create_session_jwt(new_session_id, user.username, expires_at)
    _set_session_cookie(response, jwt_token)
    _audit(db, username=user.username, action="PASSWORD_CHANGE")
    return _to_user_response(user)
