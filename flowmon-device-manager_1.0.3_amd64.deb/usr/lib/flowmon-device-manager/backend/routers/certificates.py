"""Certificate Manager API endpoints.

Handles TLS certificate management across devices:
- CA management (REST API proxy to primary Flowmon device)
- Device certificate operations (SSH-based)
- Bulk certificate upload from ZIP
"""

import io
import json
import logging
import re
import shlex
import subprocess
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from ipaddress import ip_address
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree as ET

import httpx
import paramiko
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID, ExtensionOID
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from config import settings
from database import (
    Device,
    LocalCASecret,
    RestCredential,
    SshCredential,
    decrypt_password,
    encrypt_password,
    get_db,
)
from routers.auth import get_current_admin
from services.device_check import device_base_url
from services.flowmon import FlowmonAuthError, acquire_flowmon_token, resolve_ssl_verify
from services.ssh_utils import open_ssh_connection

router = APIRouter(
    prefix="/api/certificates",
    tags=["certificates"],
    dependencies=[Depends(get_current_admin)],
)
logger = logging.getLogger(__name__)

# ========== Helper Functions for SAN Handling ==========


def _is_localhost(value: str) -> bool:
    """Check if value is localhost variant."""
    localhost_patterns = ["localhost", "localhost.localdomain", "127.0.0.1", "::1"]
    return value.lower() in localhost_patterns


def _build_san_string(device: Device) -> str:
    """Build SAN string from device IP and hostname.

    Returns: "IP:10.100.24.52,DNS:flowmon-collector-01"
    Excludes: localhost, localhost.localdomain, 127.0.0.1, ::1
    """
    san_parts = []

    # Add management IP if valid
    if device.ip_address and not _is_localhost(device.ip_address):
        san_parts.append(f"IP:{device.ip_address}")

    # Add hostname if valid
    if device.device_hostname and not _is_localhost(device.device_hostname):
        san_parts.append(f"DNS:{device.device_hostname}")

    if not san_parts:
        raise ValueError(
            f"Device {device.name}: no valid SAN entries (IP={device.ip_address}, "
            f"hostname={device.device_hostname})"
        )

    return ",".join(san_parts)


def _sanitize_name_component(value: str, field_name: str, allow_spaces: bool = False) -> str:
    """Allow only a conservative set of characters for certificate name fields."""
    trimmed = value.strip()
    if not trimmed:
        raise ValueError(f"{field_name} is required")
    if len(trimmed) > 255:
        raise ValueError(f"{field_name} is too long")
    pattern = r"[A-Za-z0-9._ -]+" if allow_spaces else r"[A-Za-z0-9._-]+"
    if not re.fullmatch(pattern, trimmed):
        allowed_chars = "letters, digits, dot, underscore, hyphen"
        if allow_spaces:
            allowed_chars += ", space"
        raise ValueError(f"{field_name} contains unsupported characters; allowed: {allowed_chars}")
    return trimmed


def _validate_san_string(san_string: str) -> str:
    """Validate SAN entries used for OpenSSL command generation."""
    entries = [entry.strip() for entry in san_string.split(",") if entry.strip()]
    if not entries:
        raise ValueError("SAN is required")

    normalized_entries: List[str] = []
    for entry in entries:
        if ":" not in entry:
            raise ValueError(f"Invalid SAN entry '{entry}'")
        san_type, raw_value = entry.split(":", 1)
        san_value = raw_value.strip()

        if san_type == "IP":
            try:
                normalized_entries.append(f"IP:{ip_address(san_value)}")
            except ValueError as exc:
                raise ValueError(f"Invalid SAN IP entry '{entry}'") from exc
        elif san_type == "DNS":
            normalized_entries.append(f"DNS:{_sanitize_name_component(san_value, 'SAN DNS value')}")
        else:
            raise ValueError(f"Unsupported SAN entry type '{san_type}'")

    return ",".join(normalized_entries)


def _extract_cert_info(cert_pem: str) -> Dict[str, Any]:
    """Parse certificate PEM and extract metadata.

    Returns dict with: issuer, subject, notBefore, notAfter, fingerprint, SAN list, is_self_signed
    """
    try:
        cert = x509.load_pem_x509_certificate(cert_pem.encode(), default_backend())

        # Extract subject and issuer
        subject = {}
        issuer = {}
        for attr in cert.subject:
            key = attr.oid._name
            subject[key] = attr.value

        for attr in cert.issuer:
            key = attr.oid._name
            issuer[key] = attr.value

        # Check if self-signed
        is_self_signed = subject == issuer

        # Extract SAN
        san_entries = []
        try:
            san_ext = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
            for name in san_ext.value:
                if isinstance(name, x509.IPAddress):
                    san_entries.append(str(name.value))
                elif isinstance(name, x509.DNSName):
                    san_entries.append(name.value)
        except x509.ExtensionNotFound:
            pass

        # Calculate fingerprint (SHA256)
        fingerprint = cert.fingerprint(hashes.SHA256()).hex()

        return {
            "subject": subject,
            "issuer": issuer,
            "notBefore": cert.not_valid_before_utc.isoformat(),
            "notAfter": cert.not_valid_after_utc.isoformat(),
            "fingerprint": fingerprint,
            "san_entries": san_entries,
            "is_self_signed": is_self_signed,
            "public_key_algorithm": cert.public_key().__class__.__name__,
            "signature_algorithm": cert.signature_algorithm_oid._name,
        }
    except Exception as e:
        logger.error(f"Failed to extract cert info: {e}")
        raise ValueError(f"Invalid certificate PEM: {str(e)}")


def _validate_cert_key_pair(cert_pem: str, key_pem: str) -> bool:
    """Verify that private key matches certificate."""
    try:
        cert = x509.load_pem_x509_certificate(cert_pem.encode(), default_backend())
        key = serialization.load_pem_private_key(key_pem.encode(), password=None, backend=default_backend())

        # For RSA keys, compare public key numbers
        cert_public_key = cert.public_key()
        if isinstance(key, rsa.RSAPrivateKey):
            cert_numbers = cert_public_key.public_numbers()
            key_numbers = key.public_key().public_numbers()
            return cert_numbers.e == key_numbers.e and cert_numbers.n == key_numbers.n

        return True
    except Exception as e:
        logger.error(f"Failed to validate cert/key pair: {e}")
        return False


def _validate_cert_san(cert_pem: str) -> Dict[str, Any]:
    """Validate certificate SAN.

    Returns: {
        'valid': bool,
        'san_entries': [str, ...],
        'has_localhost': bool,
        'error': str (if invalid)
    }
    """
    try:
        cert_info = _extract_cert_info(cert_pem)
        san_entries = cert_info.get("san_entries", [])

        # Check for localhost variants
        has_localhost = any(_is_localhost(entry) for entry in san_entries)

        if has_localhost:
            return {
                "valid": False,
                "san_entries": san_entries,
                "has_localhost": True,
                "error": f"Certificate contains localhost variant(s): {[e for e in san_entries if _is_localhost(e)]}",
            }

        if not san_entries:
            return {
                "valid": False,
                "san_entries": san_entries,
                "has_localhost": False,
                "error": "Certificate has no Subject Alternative Names (SAN)",
            }

        return {
            "valid": True,
            "san_entries": san_entries,
            "has_localhost": False,
            "error": None,
        }
    except Exception as e:
        return {
            "valid": False,
            "san_entries": [],
            "has_localhost": False,
            "error": f"Failed to validate SAN: {str(e)}",
        }


def _extract_bulk_zip(zip_file_bytes: bytes) -> Dict[str, Any]:
    """Extract and validate bulk ZIP structure.

    ZIP structure:
    certificates.zip
    ├── device-certs/
    │   ├── dev-001/
    │   │   ├── server.crt
    │   │   ├── server.key
    │   └── dev-002/
    │       ├── server.crt
    │       └── server.key

    Returns: {
        'device_certs': [
            {
                'device_id': str,
                'crt': str (PEM),
                'key': str (PEM)
            },
            ...
        ],
        'errors': [str, ...]
    }
    """
    result = {"device_certs": [], "errors": []}

    try:
        with zipfile.ZipFile(io.BytesIO(zip_file_bytes)) as zf:
            file_list = zf.namelist()

            # Group files by device_id
            devices: Dict[str, Dict[str, str]] = {}
            for file_path in file_list:
                # Skip directories and non-cert files
                if file_path.endswith("/"):
                    continue

                # Expected path: device-certs/<device_id>/<filename>
                parts = file_path.split("/")
                if len(parts) < 3 or parts[0] != "device-certs":
                    continue

                device_id = parts[1]
                filename = parts[2]

                if device_id not in devices:
                    devices[device_id] = {}

                # Read file content
                try:
                    content = zf.read(file_path).decode("utf-8")
                    if filename == "server.crt":
                        devices[device_id]["crt"] = content
                    elif filename == "server.key":
                        devices[device_id]["key"] = content
                except Exception as e:
                    result["errors"].append(f"Failed to read {file_path}: {str(e)}")

            # Validate and add to result
            for device_id, files in devices.items():
                if "crt" not in files or "key" not in files:
                    result["errors"].append(f"Device {device_id}: missing certificate or private key")
                    continue

                crt = files["crt"]
                key = files["key"]

                # Validate cert/key pair
                if not _validate_cert_key_pair(crt, key):
                    result["errors"].append(f"Device {device_id}: certificate and private key do not match")
                    continue

                # Validate SAN
                san_validation = _validate_cert_san(crt)
                if not san_validation["valid"]:
                    result["errors"].append(f"Device {device_id}: {san_validation['error']}")
                    continue

                result["device_certs"].append(
                    {"device_id": device_id, "crt": crt, "key": key, "san_entries": san_validation["san_entries"]}
                )

    except zipfile.BadZipFile as e:
        result["errors"].append(f"Invalid ZIP file: {str(e)}")
    except Exception as e:
        result["errors"].append(f"Unexpected error processing ZIP: {str(e)}")

    return result


# ========== Flowmon REST Helpers (CA Management) ==========


def _get_primary_device_rest_context(db: Session) -> Tuple[Device, str, str, str]:
    """Return (device, base_url, username, password) for CA management REST calls."""
    devices = db.query(Device).order_by(Device.created_at).all()
    rest_capable = [
        d
        for d in devices
        if d.rest_credential_id or (d.rest_username and d.rest_password_enc)
    ]
    if not rest_capable:
        raise HTTPException(status_code=422, detail="No device with REST credentials is configured")

    primary = next((d for d in rest_capable if (d.status or "").lower() == "online"), rest_capable[0])

    if primary.rest_credential_id:
        cred = db.query(RestCredential).filter(RestCredential.id == primary.rest_credential_id).first()
        if not cred:
            raise HTTPException(status_code=422, detail="Primary device REST credential was not found")
        username = cred.username
        password = decrypt_password(cred.password_enc)
    else:
        username = primary.rest_username
        password = decrypt_password(primary.rest_password_enc) if primary.rest_password_enc else ""

    base_url = device_base_url(primary.ip_address, primary.https_port)
    return primary, base_url, username, password


def _flowmon_error_detail(response: httpx.Response) -> str:
    """Extract user-facing error detail from Flowmon REST error response."""
    try:
        body = response.json()
    except ValueError:
        text = response.text.strip()
        return text or f"Flowmon API returned HTTP {response.status_code}"

    if isinstance(body, dict):
        direct = body.get("detail") or body.get("message") or body.get("error") or body.get("error_description")
        if isinstance(direct, str) and direct.strip():
            return direct.strip()

        validations = body.get("validationResults")
        if isinstance(validations, list) and validations:
            validation_messages = []
            for item in validations:
                if isinstance(item, dict):
                    field = item.get("field")
                    message = item.get("message")
                    if field and message:
                        validation_messages.append(f"{field}: {message}")
                    elif message:
                        validation_messages.append(str(message))
            if validation_messages:
                return "; ".join(validation_messages)

    if isinstance(body, list) and body:
        return json.dumps(body)
    return f"Flowmon API returned HTTP {response.status_code}"


async def _call_primary_tls_api(
    db: Session,
    method: str,
    path: str = "",
    data: Optional[Dict[str, Any]] = None,
    files: Optional[Dict[str, Tuple[str, bytes, str]]] = None,
) -> Any:
    """Call /rest/fcc/reusable-settings-tls/* on the selected primary device."""
    _device, base_url, username, password = _get_primary_device_rest_context(db)
    verify = bool(_device.verify_ssl)
    try:
        token_data = await acquire_flowmon_token(base_url, username, password, verify)
    except FlowmonAuthError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot authenticate to primary device: {exc}") from exc

    endpoint = f"{base_url}/rest/fcc/reusable-settings-tls/"
    if path:
        endpoint = f"{endpoint}{path.lstrip('/')}"

    headers = {"Authorization": f"bearer {token_data['access_token']}"}
    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(verify), timeout=30.0) as client:
            if method.upper() in {"POST", "PUT"}:
                response = await client.request(
                    method.upper(),
                    endpoint,
                    headers=headers,
                    data=data,
                    files=files,
                )
            else:
                response = await client.request(method.upper(), endpoint, headers=headers)
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        raise HTTPException(status_code=502, detail=f"Primary device API call failed: {exc}") from exc

    if response.status_code == 204:
        return []
    if response.status_code // 100 != 2:
        raise HTTPException(status_code=502, detail=_flowmon_error_detail(response))

    try:
        return response.json()
    except ValueError:
        return {"status": "success"}


def _normalize_ca_item(item: Dict[str, Any], has_private_key: bool = False) -> Dict[str, Any]:
    """Return a stable CA item shape for the frontend from Flowmon TlsItem."""
    parsed = item.get("parsedCertificate") if isinstance(item.get("parsedCertificate"), dict) else {}
    subject = parsed.get("subject") if isinstance(parsed.get("subject"), dict) else {}
    issuer = parsed.get("issuer") if isinstance(parsed.get("issuer"), dict) else {}
    pairs = (
        item.get("certificatePairs")
        if isinstance(item.get("certificatePairs"), list)
        else (item.get("pairs") if isinstance(item.get("pairs"), list) else [])
    )
    usage = item.get("usage")
    usage_count = item.get("usageCount")
    if usage_count is None and isinstance(usage, list):
        usage_count = len(usage)

    return {
        "id": item.get("id"),
        "name": item.get("name"),
        "description": item.get("description"),
        "original_filename": item.get("originalFilename") or item.get("caFilename") or parsed.get("originalFilename"),
        "subject": subject,
        "issuer": issuer,
        "subject_cn": subject.get("cn"),
        "issuer_cn": issuer.get("cn"),
        "not_before": parsed.get("validFrom"),
        "not_after": parsed.get("validTo"),
        "is_self_signed": parsed.get("isSelfSigned"),
        "expiration": parsed.get("expirationStatus"),
        "usage": usage,
        "usage_count": usage_count,
        "pair_count": len(pairs),
        "certificate_pairs": pairs,
        "has_private_key": has_private_key,
        "raw": item,
    }


def _extract_ca_pem_from_item(value: Any) -> Optional[str]:
    """Find PEM certificate content in nested Flowmon CA payload."""
    pem_begin = "-----BEGIN CERTIFICATE-----"
    pem_end = "-----END CERTIFICATE-----"

    if isinstance(value, str):
        start = value.find(pem_begin)
        end = value.find(pem_end)
        if start != -1 and end != -1 and end >= start:
            end += len(pem_end)
            return value[start:end].strip() + "\n"
        return None

    if isinstance(value, dict):
        for nested in value.values():
            found = _extract_ca_pem_from_item(nested)
            if found:
                return found
        return None

    if isinstance(value, list):
        for nested in value:
            found = _extract_ca_pem_from_item(nested)
            if found:
                return found
        return None

    return None


def _generate_local_ca_material(
    common_name: str,
    organization: Optional[str],
    country: Optional[str],
    days_valid: int,
) -> Tuple[str, str]:
    """Generate a local self-signed CA certificate and key in PEM format."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    subject_attrs = []
    if country:
        subject_attrs.append(x509.NameAttribute(NameOID.COUNTRY_NAME, country.upper()))
    if organization:
        subject_attrs.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, organization))
    subject_attrs.append(x509.NameAttribute(NameOID.COMMON_NAME, common_name))

    subject = x509.Name(subject_attrs)
    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + timedelta(days=days_valid))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=False,
                content_commitment=False,
                key_encipherment=False,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=True,
                crl_sign=True,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(key.public_key()), critical=False)
        .sign(private_key=key, algorithm=hashes.SHA256())
    )

    cert_pem = cert.public_bytes(serialization.Encoding.PEM).decode()
    key_pem = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode()
    return cert_pem, key_pem


def _load_local_ca_secret(db: Session, ca_id: str) -> LocalCASecret:
    ca_secret = db.query(LocalCASecret).filter(LocalCASecret.ca_id == ca_id).first()
    if not ca_secret:
        raise HTTPException(
            status_code=422,
            detail="Selected CA does not have a stored private key. Use 'Create Local CA' first.",
        )
    return ca_secret


def _sign_csr_with_local_ca(csr_pem: str, ca_cert_pem: str, ca_key_pem: str, days_valid: int) -> str:
    """Sign CSR using local CA material and return PEM certificate."""
    if days_valid < 30 or days_valid > 3650:
        raise ValueError("days_valid must be between 30 and 3650")

    csr = x509.load_pem_x509_csr(csr_pem.encode(), default_backend())
    ca_cert = x509.load_pem_x509_certificate(ca_cert_pem.encode(), default_backend())
    ca_key = serialization.load_pem_private_key(ca_key_pem.encode(), password=None, backend=default_backend())

    now = datetime.now(timezone.utc)
    builder = (
        x509.CertificateBuilder()
        .subject_name(csr.subject)
        .issuer_name(ca_cert.subject)
        .public_key(csr.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + timedelta(days=days_valid))
    )

    for extension in csr.extensions:
        builder = builder.add_extension(extension.value, extension.critical)

    leaf_cert = builder.sign(private_key=ca_key, algorithm=hashes.SHA256())
    return leaf_cert.public_bytes(serialization.Encoding.PEM).decode()


# ========== SSH Helper Functions ==========


def _ssh_generate_csr(device: Device, db: Session, san_string: str, hostname: str) -> str:
    """Generate CSR on device via SSH with SAN, return CSR content."""
    ssh_client = None
    csr_path = f"/tmp/server-{uuid.uuid4().hex}.csr"
    try:
        if not device.ssh_credential_id:
            raise ValueError("Device has no SSH credential configured")
        
        ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
        if not ssh_cred:
            raise ValueError("SSH credential not found")
        
        ssh_client = open_ssh_connection(device, ssh_cred)

        safe_hostname = _sanitize_name_component(hostname, "Hostname", allow_spaces=True)
        safe_san_string = _validate_san_string(san_string)
        subject_value = f"/CN={safe_hostname}"
        san_extension = f"subjectAltName={safe_san_string}"

        # Generate CSR with SAN
        cmd = (
            f"openssl req -new -key /etc/httpd/conf/ssl.key/server.key "
            f"-out {shlex.quote(csr_path)} "
            f"-subj {shlex.quote(subject_value)} "
            f"-addext {shlex.quote(san_extension)} >/dev/null 2>&1"
        )

        stdin, stdout, stderr = ssh_client.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()

        if exit_code != 0:
            error = stderr.read().decode()
            raise RuntimeError(f"CSR generation failed: {error}")

        # Read CSR
        read_cmd = f"cat {shlex.quote(csr_path)}"
        stdin, stdout, stderr = ssh_client.exec_command(read_cmd)
        csr_content = stdout.read().decode()

        return csr_content
    except Exception as e:
        logger.error(f"Failed to generate CSR on device {device.name}: {e}")
        raise
    finally:
        if ssh_client is not None:
            try:
                ssh_client.exec_command(f"rm -f {shlex.quote(csr_path)}")
            except Exception as cleanup_error:
                logger.warning(f"Failed to clean CSR temp file on device {device.name}: {cleanup_error}")
            ssh_client.close()


def _ssh_deploy_cert(device: Device, db: Session, cert_pem: str, key_pem: str) -> None:
    """Deploy cert + key to device via SSH, restart httpd."""
    try:
        if not device.ssh_credential_id:
            raise ValueError("Device has no SSH credential configured")
        
        ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
        if not ssh_cred:
            raise ValueError("SSH credential not found")
        
        ssh_client = open_ssh_connection(device, ssh_cred)
        sftp = ssh_client.open_sftp()

        # Backup existing cert and key
        now_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

        try:
            sftp.stat("/etc/httpd/conf/ssl.crt/server.crt")
            sftp.rename(f"/etc/httpd/conf/ssl.crt/server.crt", 
                       f"/etc/httpd/conf/ssl.crt/server.crt.backup.{now_str}")
        except IOError:
            pass  # File doesn't exist

        try:
            sftp.stat("/etc/httpd/conf/ssl.key/server.key")
            sftp.rename(f"/etc/httpd/conf/ssl.key/server.key", 
                       f"/etc/httpd/conf/ssl.key/server.key.backup.{now_str}")
        except IOError:
            pass

        # Deploy new cert and key
        sftp.putfo(io.BytesIO(cert_pem.encode()), "/etc/httpd/conf/ssl.crt/server.crt")
        sftp.putfo(io.BytesIO(key_pem.encode()), "/etc/httpd/conf/ssl.key/server.key")

        # Set proper permissions
        sftp.chmod("/etc/httpd/conf/ssl.crt/server.crt", 0o644)
        sftp.chmod("/etc/httpd/conf/ssl.key/server.key", 0o600)

        sftp.close()

        # Reload httpd so TLS material is picked up without tearing down active client connections.
        stdin, stdout, stderr = ssh_client.exec_command("sudo -n systemctl reload httpd")
        exit_code = stdout.channel.recv_exit_status()

        if exit_code != 0:
            error = stderr.read().decode()
            raise RuntimeError(f"httpd reload failed: {error}")
        
        ssh_client.close()

    except Exception as e:
        logger.error(f"Failed to deploy cert on device {device.name}: {e}")
        raise


def _ssh_deploy_cert_only(device: Device, db: Session, cert_pem: str) -> None:
    """Deploy only certificate to device (preserve current private key) and reload httpd."""
    try:
        if not device.ssh_credential_id:
            raise ValueError("Device has no SSH credential configured")

        ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
        if not ssh_cred:
            raise ValueError("SSH credential not found")

        ssh_client = open_ssh_connection(device, ssh_cred)
        sftp = ssh_client.open_sftp()

        now_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        try:
            sftp.stat("/etc/httpd/conf/ssl.crt/server.crt")
            sftp.rename(
                "/etc/httpd/conf/ssl.crt/server.crt",
                f"/etc/httpd/conf/ssl.crt/server.crt.backup.{now_str}",
            )
        except IOError:
            pass

        sftp.putfo(io.BytesIO(cert_pem.encode()), "/etc/httpd/conf/ssl.crt/server.crt")
        sftp.chmod("/etc/httpd/conf/ssl.crt/server.crt", 0o640)
        sftp.close()

        stdin, stdout, stderr = ssh_client.exec_command("sudo -n systemctl reload httpd")
        exit_code = stdout.channel.recv_exit_status()
        if exit_code != 0:
            error = stderr.read().decode()
            raise RuntimeError(f"httpd reload failed: {error}")

        ssh_client.close()
    except Exception as e:
        logger.error(f"Failed to deploy cert-only on device {device.name}: {e}")
        raise


class UseCARequest(BaseModel):
    ca_id: str
    validity_days: int = 365


# ========== REST API Endpoints ==========


@router.get("/cas")
async def list_certificate_authorities(db: Session = Depends(get_db)) -> List[Dict[str, Any]]:
    """List CA definitions from primary device reusable TLS settings."""
    result = await _call_primary_tls_api(db, "GET")
    if not isinstance(result, list):
        return []
    secret_ids = {
        row.ca_id for row in db.query(LocalCASecret.ca_id).all()
    }
    normalized: List[Dict[str, Any]] = []
    for item in result:
        if isinstance(item, dict):
            normalized.append(_normalize_ca_item(item, has_private_key=item.get("id") in secret_ids))
    return normalized


@router.get("/cas/{ca_id}/details")
async def get_certificate_authority_details(ca_id: str, db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Fetch one CA definition including parsed certificate metadata."""
    result = await _call_primary_tls_api(db, "GET", path=ca_id)
    if not isinstance(result, dict):
        raise HTTPException(status_code=502, detail="Primary device returned invalid CA details response")
    has_private_key = db.query(LocalCASecret).filter(LocalCASecret.ca_id == ca_id).first() is not None
    return _normalize_ca_item(result, has_private_key=has_private_key)


@router.get("/cas/{ca_id}/download")
async def download_certificate_authority(ca_id: str, db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Download CA certificate PEM for one CA definition."""
    ca_details = await _call_primary_tls_api(db, "GET", path=ca_id)
    if not isinstance(ca_details, dict):
        raise HTTPException(status_code=502, detail="Primary device returned invalid CA details response")

    cert_pem = _extract_ca_pem_from_item(ca_details)
    if cert_pem is None:
        local_secret = db.query(LocalCASecret).filter(LocalCASecret.ca_id == ca_id).first()
        if local_secret and local_secret.cert_pem.strip():
            cert_pem = local_secret.cert_pem.strip() + "\n"

    if cert_pem is None:
        raise HTTPException(status_code=404, detail="CA certificate content is not available for download")

    ca_name = (ca_details.get("name") or "ca").strip()
    safe_name = re.sub(r"[^a-zA-Z0-9_.-]+", "-", ca_name).strip("-") or "ca"
    return {
        "filename": f"{safe_name}.crt",
        "content": cert_pem,
        "ca_id": ca_id,
        "ca_name": ca_name,
    }


@router.post("/cas")
async def create_certificate_authority(
    name: str = Form(...),
    description: str = Form(""),
    ca_file: UploadFile = File(...),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """Create a reusable CA definition by uploading CA certificate file."""
    file_content = await ca_file.read()
    if not file_content:
        raise HTTPException(status_code=400, detail="Uploaded CA certificate file is empty")

    entity = {"name": name, "description": description}
    payload = {"entity": json.dumps(entity)}
    files = {
        "entity.tlsCaFile": (
            ca_file.filename or "ca.crt",
            file_content,
            ca_file.content_type or "application/x-pem-file",
        )
    }
    result = await _call_primary_tls_api(db, "POST", data=payload, files=files)
    if not isinstance(result, dict):
        raise HTTPException(status_code=502, detail="Primary device returned invalid CA create response")
    return _normalize_ca_item(result, has_private_key=False)


@router.post("/cas/create-local")
async def create_local_certificate_authority(
    name: str = Form(...),
    description: str = Form(""),
    common_name: str = Form(...),
    organization: Optional[str] = Form(None),
    country: Optional[str] = Form(None),
    days_valid: int = Form(3650),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """Generate a local CA certificate/key pair, upload CA cert to Flowmon, return both PEM files."""
    trimmed_name = name.strip()
    trimmed_cn = common_name.strip()
    if not trimmed_name:
        raise HTTPException(status_code=400, detail="CA name is required")
    if not trimmed_cn:
        raise HTTPException(status_code=400, detail="Common Name is required")
    if days_valid < 30 or days_valid > 3650:
        raise HTTPException(status_code=400, detail="days_valid must be between 30 and 3650")

    normalized_country = country.strip().upper() if country and country.strip() else None
    if normalized_country and len(normalized_country) != 2:
        raise HTTPException(status_code=400, detail="Country must be a 2-letter code (e.g. CZ)")
    normalized_org = organization.strip() if organization and organization.strip() else None

    cert_pem, key_pem = _generate_local_ca_material(
        common_name=trimmed_cn,
        organization=normalized_org,
        country=normalized_country,
        days_valid=days_valid,
    )

    payload = {"entity": json.dumps({"name": trimmed_name, "description": description})}
    files = {
        "entity.tlsCaFile": (
            f"{trimmed_name.replace(' ', '_').lower()}-ca.crt",
            cert_pem.encode(),
            "application/x-pem-file",
        )
    }
    result = await _call_primary_tls_api(db, "POST", data=payload, files=files)
    if not isinstance(result, dict):
        raise HTTPException(status_code=502, detail="Primary device returned invalid CA create response")

    created_ca_id = result.get("id")
    if not created_ca_id:
        raise HTTPException(status_code=502, detail="Primary device response did not include CA id")

    existing_secret = db.query(LocalCASecret).filter(LocalCASecret.ca_id == created_ca_id).first()
    if existing_secret:
        existing_secret.ca_name = trimmed_name
        existing_secret.private_key_enc = encrypt_password(key_pem)
        existing_secret.cert_pem = cert_pem
    else:
        db.add(
            LocalCASecret(
                ca_id=created_ca_id,
                ca_name=trimmed_name,
                private_key_enc=encrypt_password(key_pem),
                cert_pem=cert_pem,
            )
        )
    db.commit()

    safe_base = re.sub(r"[^a-zA-Z0-9_.-]+", "-", trimmed_name).strip("-") or "local-ca"
    return {
        "ca": _normalize_ca_item(result, has_private_key=True),
        "generated_cert_pem": cert_pem,
        "generated_key_pem": key_pem,
        "cert_filename": f"{safe_base}.crt",
        "key_filename": f"{safe_base}.key",
        "message": f"Local CA '{trimmed_name}' generated and uploaded.",
    }


@router.put("/cas/{ca_id}")
async def update_certificate_authority(
    ca_id: str,
    name: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    ca_file: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """Update CA metadata and optionally upload a replacement CA certificate file."""
    if name is None and description is None and ca_file is None:
        raise HTTPException(status_code=400, detail="At least one field (name, description, ca_file) is required")

    entity: Dict[str, Any] = {"id": ca_id}
    if name is not None:
        entity["name"] = name
    if description is not None:
        entity["description"] = description

    payload = {"entity": json.dumps(entity)}
    replaced_ca_file = ca_file is not None
    files: Optional[Dict[str, Tuple[str, bytes, str]]] = None
    if ca_file is not None:
        file_content = await ca_file.read()
        if not file_content:
            raise HTTPException(status_code=400, detail="Uploaded CA certificate file is empty")
        files = {
            "entity.tlsCaFile": (
                ca_file.filename or "ca.crt",
                file_content,
                ca_file.content_type or "application/x-pem-file",
            )
        }

    result = await _call_primary_tls_api(db, "PUT", data=payload, files=files)
    if not isinstance(result, dict):
        raise HTTPException(status_code=502, detail="Primary device returned invalid CA update response")

    if replaced_ca_file:
        db.query(LocalCASecret).filter(LocalCASecret.ca_id == ca_id).delete()
        db.commit()

    has_private_key = db.query(LocalCASecret).filter(LocalCASecret.ca_id == ca_id).first() is not None
    return _normalize_ca_item(result, has_private_key=has_private_key)


@router.delete("/cas/{ca_id}")
async def delete_certificate_authority(ca_id: str, db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Delete CA from primary device reusable TLS settings."""
    await _call_primary_tls_api(db, "DELETE", path=ca_id)
    db.query(LocalCASecret).filter(LocalCASecret.ca_id == ca_id).delete()
    db.commit()
    return {"status": "success", "message": "CA deleted", "id": ca_id}


@router.get("/devices")
async def list_device_certificates(db: Session = Depends(get_db)) -> List[Dict[str, Any]]:
    """List all managed devices with current certificate info."""
    devices = db.query(Device).all()
    result = []

    for device in devices:
        try:
            if not device.ssh_credential_id:
                result.append(
                    {
                        "device_id": device.id,
                        "device_name": device.name,
                        "management_ip": device.ip_address,
                        "hostname": device.device_hostname,
                        "cert_info": None,
                        "error": "No SSH credential configured",
                        "status": "error",
                    }
                )
                continue
            
            ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
            if not ssh_cred:
                result.append(
                    {
                        "device_id": device.id,
                        "device_name": device.name,
                        "management_ip": device.ip_address,
                        "hostname": device.device_hostname,
                        "cert_info": None,
                        "error": "SSH credential not found",
                        "status": "error",
                    }
                )
                continue
            
            ssh_client = open_ssh_connection(device, ssh_cred)
            sftp = ssh_client.open_sftp()

            # Read current certificate
            cert_file = sftp.file("/etc/httpd/conf/ssl.crt/server.crt")
            cert_pem = cert_file.read().decode()
            cert_file.close()
            sftp.close()
            ssh_client.close()

            cert_info = _extract_cert_info(cert_pem)

            result.append(
                {
                    "device_id": device.id,
                    "device_name": device.name,
                    "management_ip": device.ip_address,
                    "hostname": device.device_hostname,
                    "cert_info": cert_info,
                    "status": "success",
                }
            )
        except Exception as e:
            logger.warning(f"Failed to fetch cert for device {device.name}: {e}")
            result.append(
                {
                    "device_id": device.id,
                    "device_name": device.name,
                    "management_ip": device.ip_address,
                    "hostname": device.device_hostname,
                    "cert_info": None,
                    "error": str(e),
                    "status": "error",
                }
            )

    return result


@router.get("/devices/{device_id}/cert")
async def get_device_certificate(device_id: str, db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Fetch current certificate details for specific device."""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    try:
        if not device.ssh_credential_id:
            raise ValueError("Device has no SSH credential configured")
        
        ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
        if not ssh_cred:
            raise ValueError("SSH credential not found")
        
        ssh_client = open_ssh_connection(device, ssh_cred)
        sftp = ssh_client.open_sftp()

        cert_file = sftp.file("/etc/httpd/conf/ssl.crt/server.crt")
        cert_pem = cert_file.read().decode()
        cert_file.close()
        sftp.close()
        ssh_client.close()

        cert_info = _extract_cert_info(cert_pem)

        return {
            "device_id": device.id,
            "device_name": device.name,
            "management_ip": device.ip_address,
            "hostname": device.device_hostname,
            "cert_pem": cert_pem,
            "cert_info": cert_info,
            "status": "success",
        }
    except Exception as e:
        logger.error(f"Failed to fetch cert for device {device.name}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch certificate: {str(e)}")


@router.post("/devices/{device_id}/generate-self-signed")
async def generate_self_signed_cert(device_id: str, db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Regenerate self-signed certificate on device."""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    try:
        if not device.ssh_credential_id:
            raise ValueError("Device has no SSH credential configured")
        
        ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
        if not ssh_cred:
            raise ValueError("SSH credential not found")
        
        # Build SAN string
        san_string = _build_san_string(device)
        hostname = device.device_hostname or device.name

        # SSH to device and generate self-signed cert
        ssh_client = open_ssh_connection(device, ssh_cred)

        # Backup existing cert and key
        now_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        ssh_client.exec_command(
            f"cp /etc/httpd/conf/ssl.crt/server.crt /etc/httpd/conf/ssl.crt/server.crt.backup.{now_str}"
        )
        ssh_client.exec_command(
            f"cp /etc/httpd/conf/ssl.key/server.key /etc/httpd/conf/ssl.key/server.key.backup.{now_str}"
        )

        # Generate new self-signed cert
        cmd = (
            f"openssl req -x509 -newkey rsa:2048 -nodes "
            f"-keyout /etc/httpd/conf/ssl.key/server.key "
            f"-out /etc/httpd/conf/ssl.crt/server.crt "
            f"-days 365 -subj '/CN={hostname}' "
            f"-addext 'subjectAltName={san_string}' >/dev/null 2>&1"
        )

        stdin, stdout, stderr = ssh_client.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()

        if exit_code != 0:
            error = stderr.read().decode()
            raise RuntimeError(f"Self-signed cert generation failed: {error}")

        # Set proper permissions
        ssh_client.exec_command("chmod 640 /etc/httpd/conf/ssl.crt/server.crt")
        ssh_client.exec_command("chmod 640 /etc/httpd/conf/ssl.key/server.key")

        # Reload httpd so TLS material is picked up without tearing down active client connections.
        stdin, stdout, stderr = ssh_client.exec_command("sudo -n systemctl reload httpd")
        exit_code = stdout.channel.recv_exit_status()

        if exit_code != 0:
            error = stderr.read().decode()
            raise RuntimeError(f"httpd reload failed: {error}")

        # Read new cert and return info
        sftp = ssh_client.open_sftp()
        cert_file = sftp.file("/etc/httpd/conf/ssl.crt/server.crt")
        cert_pem = cert_file.read().decode()
        cert_file.close()
        sftp.close()
        ssh_client.close()

        cert_info = _extract_cert_info(cert_pem)

        return {
            "device_id": device.id,
            "device_name": device.name,
            "cert_info": cert_info,
            "status": "success",
            "message": f"Self-signed certificate regenerated with SAN: {san_string}",
        }
    except Exception as e:
        logger.error(f"Failed to generate self-signed cert for device {device.name}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate certificate: {str(e)}")


@router.post("/devices/{device_id}/use-ca-certificate")
async def use_ca_certificate(device_id: str, body: UseCARequest, db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Generate CSR on device, sign it with stored local CA key, and deploy signed cert."""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    try:
        ca_secret = _load_local_ca_secret(db, body.ca_id)
        ca_key_pem = decrypt_password(ca_secret.private_key_enc)

        san_string = _build_san_string(device)
        hostname = device.device_hostname or device.name
        csr_pem = _ssh_generate_csr(device, db, san_string=san_string, hostname=hostname)
        signed_cert_pem = _sign_csr_with_local_ca(
            csr_pem=csr_pem,
            ca_cert_pem=ca_secret.cert_pem,
            ca_key_pem=ca_key_pem,
            days_valid=body.validity_days,
        )

        san_validation = _validate_cert_san(signed_cert_pem)
        if not san_validation["valid"]:
            raise ValueError(f"Generated certificate validation failed: {san_validation['error']}")

        _ssh_deploy_cert_only(device, db, signed_cert_pem)
        cert_info = _extract_cert_info(signed_cert_pem)

        return {
            "device_id": device.id,
            "device_name": device.name,
            "ca_id": body.ca_id,
            "cert_info": cert_info,
            "status": "success",
            "message": f"Certificate signed with CA '{ca_secret.ca_name}' and deployed successfully.",
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to deploy CA-signed certificate for device {device.name}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to deploy CA-signed certificate: {str(e)}")


@router.post("/devices/{device_id}/upload-custom")
async def upload_custom_cert(
    device_id: str, certificate_file: UploadFile = File(...), private_key_file: UploadFile = File(...),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """Upload custom certificate and private key to device."""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    try:
        # Read uploaded files
        cert_content = (await certificate_file.read()).decode()
        key_content = (await private_key_file.read()).decode()

        # Validate cert and key match
        if not _validate_cert_key_pair(cert_content, key_content):
            raise ValueError("Certificate and private key do not match")

        # Validate SAN
        san_validation = _validate_cert_san(cert_content)
        if not san_validation["valid"]:
            raise ValueError(f"Invalid certificate: {san_validation['error']}")

        # Deploy to device
        _ssh_deploy_cert(device, db, cert_content, key_content)

        cert_info = _extract_cert_info(cert_content)

        return {
            "device_id": device.id,
            "device_name": device.name,
            "cert_info": cert_info,
            "status": "success",
            "message": "Custom certificate uploaded and deployed successfully",
        }
    except Exception as e:
        logger.error(f"Failed to upload custom cert for device {device.name}: {e}")
        raise HTTPException(status_code=400, detail=f"Upload failed: {str(e)}")


@router.post("/devices/bulk-upload")
async def bulk_upload_certificates(zip_file: UploadFile = File(...), db: Session = Depends(get_db)) -> Dict[str, Any]:
    """Upload bulk certificates from ZIP archive."""
    try:
        # Read ZIP file
        zip_content = await zip_file.read()

        # Extract and validate
        result = _extract_bulk_zip(zip_content)

        if result["errors"] and not result["device_certs"]:
            raise HTTPException(
                status_code=400,
                detail={
                    "message": "No valid certificates found in ZIP",
                    "errors": result["errors"],
                },
            )

        # Deploy certificates to devices
        successful = []
        failed = []

        for cert_entry in result["device_certs"]:
            device_id = cert_entry["device_id"]
            try:
                device = db.query(Device).filter(Device.id == device_id).first()
                if not device:
                    failed.append(
                        {
                            "device_id": device_id,
                            "error": "Device not found in manager",
                        }
                    )
                    continue

                # Deploy cert
                _ssh_deploy_cert(device, db, cert_entry["crt"], cert_entry["key"])

                # Extract cert info
                cert_info = _extract_cert_info(cert_entry["crt"])

                successful.append(
                    {
                        "device_id": device_id,
                        "device_name": device.name,
                        "san_entries": cert_entry["san_entries"],
                        "cert_info": cert_info,
                    }
                )
            except Exception as e:
                logger.error(f"Failed to deploy cert to device {device_id}: {e}")
                failed.append(
                    {
                        "device_id": device_id,
                        "error": str(e),
                    }
                )

        # Include extraction errors in response
        all_errors = result["errors"]
        if failed:
            all_errors.extend([f"Device {f['device_id']}: {f['error']}" for f in failed])

        return {
            "status": "completed",
            "successful": successful,
            "failed": failed,
            "validation_errors": result["errors"],
            "total_requested": len(result["device_certs"]),
            "total_successful": len(successful),
            "total_failed": len(failed),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to process bulk upload: {e}")
        raise HTTPException(status_code=400, detail=f"Bulk upload failed: {str(e)}")


@router.get("/devices/{device_id}/download")
async def download_device_certificate(device_id: str, db: Session = Depends(get_db)):
    """Download current certificate from device."""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    try:
        if not device.ssh_credential_id:
            raise ValueError("Device has no SSH credential configured")
        
        ssh_cred = db.query(SshCredential).filter(SshCredential.id == device.ssh_credential_id).first()
        if not ssh_cred:
            raise ValueError("SSH credential not found")
        
        ssh_client = open_ssh_connection(device, ssh_cred)
        sftp = ssh_client.open_sftp()

        cert_file = sftp.file("/etc/httpd/conf/ssl.crt/server.crt")
        cert_pem = cert_file.read()
        cert_file.close()
        sftp.close()
        ssh_client.close()

        return {
            "filename": f"{device.name}-server.crt",
            "content": cert_pem.decode(),
            "device_id": device.id,
            "device_name": device.name,
        }
    except Exception as e:
        logger.error(f"Failed to download cert for device {device.name}: {e}")
        raise HTTPException(status_code=500, detail=f"Download failed: {str(e)}")
