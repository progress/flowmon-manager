from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, field_validator
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from config import settings
from database import DeviceSession, OidcIdentity, User, get_db, hash_password
from routers.auth import get_current_admin, get_current_user

router = APIRouter(prefix="/api/users", tags=["users"])


def _audit(db, username, action, **kwargs):
    from routers.audit import write_audit
    write_audit(db, username=username, action=action, **kwargs)


def _invalidate_sessions(db: Session, username: str) -> None:
    db.query(DeviceSession).filter(DeviceSession.username == username).delete()


def _count_active_admins(db: Session, exclude_id: Optional[str] = None) -> int:
    q = db.query(User).filter(User.is_admin == 1, User.disabled == 0)
    if exclude_id:
        q = q.filter(User.id != exclude_id)
    return q.count()


# ---------- Pydantic schemas ----------

class UserCreate(BaseModel):
    username: str
    password: str
    is_admin: bool = False

    @field_validator("username")
    @classmethod
    def _username_not_blank(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Username is required")
        return v

    @field_validator("password")
    @classmethod
    def _password_min_length(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class UserUpdate(BaseModel):
    is_admin: Optional[bool] = None
    disabled: Optional[bool] = None


class ResetPasswordRequest(BaseModel):
    new_password: str

    @field_validator("new_password")
    @classmethod
    def _password_min_length(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class OidcLinkRequest(BaseModel):
    subject: str

    @field_validator("subject")
    @classmethod
    def _subject_valid(cls, value: str) -> str:
        if not value or len(value) > 255 or value != value.strip():
            raise ValueError("OIDC subject must be 1–255 characters without surrounding whitespace")
        return value


class UserAdminResponse(BaseModel):
    id: str
    username: str
    is_admin: bool
    disabled: bool
    must_change_password: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


def _to_response(user: User) -> UserAdminResponse:
    return UserAdminResponse(
        id=user.id,
        username=user.username,
        is_admin=bool(user.is_admin),
        disabled=bool(user.disabled),
        must_change_password=bool(user.must_change_password),
        created_at=user.created_at,
        updated_at=user.updated_at,
    )


# ---------- Endpoints (admin only) ----------

@router.get("", response_model=list[UserAdminResponse])
def list_users(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_admin),
):
    return [_to_response(u) for u in db.query(User).order_by(User.created_at).all()]


@router.post("", response_model=UserAdminResponse, status_code=201)
def create_user(
    body: UserCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    if db.query(User).filter(User.username == body.username).first():
        raise HTTPException(status_code=409, detail="Username already exists")

    user = User(
        username=body.username,
        password_hash=hash_password(body.password),
        is_admin=1 if body.is_admin else 0,
        disabled=0,
        must_change_password=1,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    _audit(db, admin.username, "USER_ADD", resource_type="user", resource_name=user.username)
    return _to_response(user)


@router.put("/{user_id}", response_model=UserAdminResponse)
def update_user(
    user_id: str,
    body: UserUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    demoting_admin = body.is_admin is False and user.is_admin == 1
    disabling = body.disabled is True and user.disabled == 0
    if (demoting_admin or disabling) and user.id == admin.id:
        raise HTTPException(status_code=400, detail="You cannot remove your own admin access or disable yourself")
    if (demoting_admin or disabling) and _count_active_admins(db, exclude_id=user.id) == 0:
        raise HTTPException(status_code=400, detail="At least one enabled admin account is required")

    if body.is_admin is not None:
        user.is_admin = 1 if body.is_admin else 0
    if body.disabled is not None:
        user.disabled = 1 if body.disabled else 0
        if user.disabled:
            _invalidate_sessions(db, user.username)
    user.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(user)
    _audit(db, admin.username, "USER_UPDATE", resource_type="user", resource_name=user.username)
    return _to_response(user)


@router.post("/{user_id}/reset-password", response_model=UserAdminResponse)
def reset_password(
    user_id: str,
    body: ResetPasswordRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.id == admin.id:
        raise HTTPException(
            status_code=400,
            detail="Use Change Password to change your own password",
        )

    user.password_hash = hash_password(body.new_password)
    user.must_change_password = 1
    user.updated_at = datetime.now(timezone.utc)
    _invalidate_sessions(db, user.username)
    db.commit()
    db.refresh(user)
    _audit(db, admin.username, "USER_PASSWORD_RESET", resource_type="user", resource_name=user.username)
    return _to_response(user)


@router.delete("/{user_id}", status_code=204)
def delete_user(
    user_id: str,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.id == admin.id:
        raise HTTPException(status_code=400, detail="You cannot delete your own account")
    if user.is_admin and user.disabled == 0 and _count_active_admins(db, exclude_id=user.id) == 0:
        raise HTTPException(status_code=400, detail="At least one enabled admin account is required")

    _invalidate_sessions(db, user.username)
    db.query(OidcIdentity).filter(OidcIdentity.user_id == user.id).delete()
    _audit(db, admin.username, "USER_DELETE", resource_type="user", resource_name=user.username)
    db.delete(user)
    db.commit()


@router.put("/{user_id}/oidc", status_code=204)
def link_oidc_identity(
    user_id: str,
    body: OidcLinkRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    if not settings.oidc_enabled:
        raise HTTPException(status_code=400, detail="SSO is not enabled")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    existing = db.query(OidcIdentity).filter_by(issuer=settings.oidc_issuer, subject=body.subject).first()
    if existing:
        if existing.user_id == user.id:
            return
        raise HTTPException(status_code=409, detail="OIDC identity is already linked to another user")
    db.add(OidcIdentity(issuer=settings.oidc_issuer, subject=body.subject, user_id=user.id))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="OIDC identity is already linked") from None
    _audit(db, admin.username, "USER_OIDC_LINK", resource_type="user", resource_name=user.username)


@router.delete("/{user_id}/oidc/{identity_id}", status_code=204)
def unlink_oidc_identity(
    user_id: str,
    identity_id: str,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    user = db.get(User, user_id)
    identity = db.get(OidcIdentity, identity_id)
    if not user or not identity or identity.user_id != user_id:
        raise HTTPException(status_code=404, detail="OIDC identity not found")
    db.delete(identity)
    _invalidate_sessions(db, user.username)
    db.commit()
    _audit(db, admin.username, "USER_OIDC_UNLINK", resource_type="user", resource_name=user.username)


@router.get("/{user_id}/oidc")
def list_oidc_identities(
    user_id: str,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_admin),
):
    if not db.get(User, user_id):
        raise HTTPException(status_code=404, detail="User not found")
    return [
        {"id": identity.id, "issuer": identity.issuer, "subject": identity.subject}
        for identity in db.query(OidcIdentity).filter_by(user_id=user_id).all()
    ]


@router.get("/me/profile", response_model=UserAdminResponse)
def my_profile(
    user: User = Depends(get_current_user),
):
    return _to_response(user)
