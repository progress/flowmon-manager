from __future__ import annotations

import base64
import json
import re
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from config import settings
from paths import DATA_DIR
from database import Device, RestCredential, decrypt_password, get_db
from routers.auth import get_current_admin, get_current_session
from services.device_check import device_base_url
from services.flowmon import FlowmonAuthError, acquire_flowmon_token, resolve_ssl_verify

router = APIRouter(prefix="/api/license-packs", tags=["license-packs"])

_PACK_DIR = DATA_DIR / "license_packs"
_PACK_DIR.mkdir(exist_ok=True)

_LICENSE_OVERVIEW = "licenses_overview.txt"


def _audit(db, session, action, **kwargs):
    from routers.audit import write_audit

    write_audit(db, username=session.username, action=action, **kwargs)


def _safe_name(name: str) -> str:
    safe = Path(name).name
    if not safe or safe != name or "/" in name or "\\" in name or safe in {".", ".."}:
        raise HTTPException(status_code=400, detail="Invalid filename")
    return safe


def _normalize(value: Optional[str]) -> str:
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def _family_key(value: Optional[str]) -> str:
    normalized = _normalize(value)
    normalized = re.sub(r"(development|demo|trial)$", "", normalized)
    normalized = re.sub(r"\d+(?:va|v|gb|mb)?$", "", normalized)
    return normalized


def _parse_date_range(value: str) -> Dict[str, Optional[str]]:
    match = re.match(r"^\(([^-]+)-([^)]+)\)$", value.strip())
    if not match:
        return {"from": None, "to": None}
    return {"from": match.group(1).strip(), "to": match.group(2).strip()}


def _parse_license_text(filename: str, text: str, overview_hwid: Optional[str]) -> Dict[str, Any]:
    comments = [line[1:].strip() for line in text.splitlines() if line.startswith("#")]
    nonempty = [line for line in comments if line]

    product_name = None
    product_number = None
    hwid = overview_hwid
    fingerprint = None
    hw_type = None

    if nonempty:
        m = re.match(r"^(?P<name>[^;]+);\s*HWID(?:\s+)?(?P<hwid>[^;]+);\s*fingerprint:(?P<fp>\S+)", nonempty[0])
        if m:
            product_name = m.group("name").strip()
            hwid = m.group("hwid").strip()
            fingerprint = m.group("fp").strip()

    for line in nonempty[:6]:
        m = re.match(r"^(?P<name>.+?)\((?P<code>[A-Z0-9-]{5,})\)$", line)
        if m and not product_number:
            product_name = product_name or m.group("name").strip()
            product_number = m.group("code").strip()
            break

    for line in nonempty:
        m = re.match(r"^HW-ID:\s*(?P<hwid>[^ ]+)\s+HW-Type:\s*(?P<type>\S+)", line, re.IGNORECASE)
        if m:
            hwid = m.group("hwid").strip()
            hw_type = m.group("type").strip()
            break

    section_header = re.compile(r"^(?P<name>.+?)\s*\((?P<code>[A-Z0-9-]+)\)$")
    date_line = re.compile(r"^(?P<label>[A-Za-z0-9_ /+-]+)\s*\((?P<from>\d{2}/\d{2}/\d{4})\s*-\s*(?P<to>\d{2}/\d{2}/\d{4})\)$")
    sections: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None
    for line in nonempty[1:]:
        header = section_header.match(line)
        if header and header.group("code").isalpha() and len(header.group("code")) <= 8 and not line.startswith("HW-") and not line.startswith("Drive:"):
            if current:
                sections.append(current)
            current = {
                "name": header.group("name").strip(),
                "code": header.group("code").strip(),
                "license_type": None,
                "license_from": None,
                "license_to": None,
                "support_type": None,
                "support_from": None,
                "support_to": None,
                "notes": [],
            }
            continue

        if not current:
            continue

        dates = date_line.match(line)
        if dates:
            range_data = _parse_date_range(f"({dates.group('from')} - {dates.group('to')})")
            if current["license_type"] is None:
                current["license_type"] = dates.group("label").strip()
                current["license_from"] = range_data["from"]
                current["license_to"] = range_data["to"]
                continue
            if current["support_type"] is None:
                current["support_type"] = dates.group("label").strip()
                current["support_from"] = range_data["from"]
                current["support_to"] = range_data["to"]
                continue

        current["notes"].append(line)

    if current:
        sections.append(current)

    return {
        "filename": filename,
        "product_name": product_name,
        "product_number": product_number,
        "hardware_id": hwid,
        "hw_type": hw_type,
        "fingerprint": fingerprint,
        "is_trial": (hwid or "").strip().lower() == "trial",
        "sections": sections,
        "raw_preview": "\n".join(comments[:20]),
    }


def _parse_overview(text: str) -> Dict[str, str]:
    mapping: Dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        filename, _, rest = line.partition(":")
        match = re.search(r"HWID:\s*(.+)$", rest)
        if match:
            mapping[filename.strip()] = match.group(1).strip()
    return mapping


def _manifest_path(pack_id: str) -> Path:
    return _PACK_DIR / f"{pack_id}.json"


def _zip_path(pack_id: str) -> Path:
    return _PACK_DIR / f"{pack_id}.zip"


def _load_manifest(pack_id: str) -> Dict[str, Any]:
    path = _manifest_path(pack_id)
    if not path.exists():
        raise HTTPException(status_code=404, detail="License pack not found")
    return json.loads(path.read_text())


async def _device_license_snapshot(device: Device, db: Session) -> Optional[Dict[str, Any]]:
    cred = db.get(RestCredential, device.rest_credential_id) if device.rest_credential_id else None
    if not cred:
        return None

    base = device_base_url(device.ip_address, device.https_port)
    try:
        token_data = await acquire_flowmon_token(
            base,
            cred.username,
            decrypt_password(cred.password_enc),
            bool(device.verify_ssl),
        )
    except FlowmonAuthError:
        return None

    headers = {"Authorization": f"bearer {token_data['access_token']}"}
    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(bool(device.verify_ssl)), timeout=15.0) as client:
            res = await client.get(f"{base}/rest/fcc/license", headers=headers)
    except (httpx.ConnectError, httpx.TimeoutException):
        return None

    if res.status_code != 200:
        return None

    data = res.json()
    dev = data.get("device", {}) if isinstance(data, dict) else {}
    return {
        "device_id": device.id,
        "device_name": device.name,
        "ip_address": device.ip_address,
        "hardware_id": (data.get("hwId") if isinstance(data, dict) else None) or dev.get("hwId"),
        "product_name": dev.get("productName"),
        "product_number": dev.get("productNumber"),
        "license_id": dev.get("licenseId"),
    }


async def _device_snapshots(db: Session) -> List[Dict[str, Any]]:
    devices = db.query(Device).order_by(Device.created_at).all()
    snapshots: List[Dict[str, Any]] = []
    for device in devices:
        snap = await _device_license_snapshot(device, db)
        if snap:
            snapshots.append(snap)
    return snapshots


def _decorate_pack(manifest: Dict[str, Any], snapshots: List[Dict[str, Any]]) -> Dict[str, Any]:
    licenses = []
    for item in manifest.get("licenses", []):
        hwid = (item.get("hardware_id") or "").strip()
        product_number = item.get("product_number")
        product_name = item.get("product_name")
        trial = bool(item.get("is_trial"))
        matches = []
        for snap in snapshots:
            snap_hwid = (snap.get("hardware_id") or "").strip()
            if trial:
                target = _family_key(product_name or product_number)
                snap_target = _family_key(snap.get("product_name") or snap.get("product_number"))
                if target and target == snap_target:
                    matches.append(snap)
            elif hwid and snap_hwid.lower() == hwid.lower():
                matches.append(snap)
        licenses.append({**item, "matching_devices": matches})
    return {**manifest, "licenses": licenses}


async def _push_license_bytes(device: Device, filename: str, data: bytes, db: Session) -> Dict[str, Any]:
    cred = db.get(RestCredential, device.rest_credential_id) if device.rest_credential_id else None
    if not cred:
        raise HTTPException(status_code=400, detail="No REST credential assigned to this device")

    base = device_base_url(device.ip_address, device.https_port)
    try:
        token_data = await acquire_flowmon_token(
            base,
            cred.username,
            decrypt_password(cred.password_enc),
            bool(device.verify_ssl),
        )
        token = token_data["access_token"]
    except FlowmonAuthError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot authenticate to device: {exc}") from exc

    payload = {"entity": {"content": base64.b64encode(data).decode("ascii")}}
    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(bool(device.verify_ssl)), timeout=30.0) as client:
            response = await client.put(
                f"{base}/rest/fcc/license",
                headers={"Authorization": f"bearer {token}"},
                json=payload,
            )
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        raise HTTPException(status_code=502, detail=f"License upload failed: {exc}") from exc

    if response.status_code // 100 != 2:
        detail = None
        try:
            body = response.json()
            if isinstance(body, dict):
                detail = body.get("detail") or body.get("message") or body.get("error") or body.get("error_description")
        except ValueError:
            pass
        detail = (detail or response.text.strip() or f"License upload failed with HTTP {response.status_code}").strip()
        raise HTTPException(status_code=502, detail=detail)

    return {
        "device_id": device.id,
        "device_name": device.name,
        "filename": filename,
        "status": "pushed",
    }


class LicensePackUploadResponse(BaseModel):
    pack_id: str
    filename: str
    uploaded_at: str
    licenses: List[Dict[str, Any]]
    overview_text: str


class LicensePackPushRequest(BaseModel):
    device_ids: List[str]


class LicensePackPushResult(BaseModel):
    device_id: str
    device_name: str
    filename: str
    status: str
    error: Optional[str] = None


@router.post("/upload", response_model=LicensePackUploadResponse)
async def upload_license_pack(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    filename = _safe_name(file.filename or "licenses.zip")
    if not filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="License pack must be a .zip file")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded license pack is empty")

    pack_id = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S") + "-" + filename.rsplit(".", 1)[0].replace(" ", "-")
    zip_file = _zip_path(pack_id)
    manifest_file = _manifest_path(pack_id)
    zip_file.write_bytes(data)

    with zipfile.ZipFile(zip_file) as zf:
        names = zf.namelist()
        overview_name = next((n for n in names if Path(n).name == _LICENSE_OVERVIEW), None)
        overview_text = zf.read(overview_name).decode("utf-8", errors="replace") if overview_name else ""
        overview_map = _parse_overview(overview_text)

        licenses = []
        for name in names:
            safe_name = Path(name).name
            if safe_name == _LICENSE_OVERVIEW or not safe_name.lower().endswith(".key"):
                continue
            text = zf.read(name).decode("utf-8", errors="replace")
            parsed = _parse_license_text(safe_name, text, overview_map.get(safe_name))
            licenses.append(parsed)

    manifest = {
        "pack_id": pack_id,
        "filename": filename,
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
        "overview_text": overview_text,
        "licenses": licenses,
    }
    manifest_file.write_text(json.dumps(manifest, indent=2))
    _audit(db, _session, "LICENSE_PACK_UPLOAD", resource_type="license-pack", resource_name=filename, details={"pack_id": pack_id})
    return LicensePackUploadResponse(**manifest)


@router.get("/{pack_id}")
async def get_license_pack(
    pack_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> Dict[str, Any]:
    manifest = _load_manifest(pack_id)
    snapshots = await _device_snapshots(db)
    return _decorate_pack(manifest, snapshots)


@router.post("/{pack_id}/licenses/{filename}/push", response_model=List[LicensePackPushResult])
async def push_license_pack(
    pack_id: str,
    filename: str,
    body: LicensePackPushRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> List[LicensePackPushResult]:
    manifest = _load_manifest(pack_id)
    filename = _safe_name(filename)
    if not body.device_ids:
        raise HTTPException(status_code=400, detail="No devices selected")

    zip_file = _zip_path(pack_id)
    if not zip_file.exists():
        raise HTTPException(status_code=404, detail="License pack archive not found")

    with zipfile.ZipFile(zip_file) as zf:
        results: List[LicensePackPushResult] = []
        try:
            data = zf.read(filename)
        except KeyError:
            raise HTTPException(status_code=404, detail=f"License file not found in pack: {filename}")

        for device_id in body.device_ids:
            device = db.get(Device, device_id)
            if not device:
                results.append(LicensePackPushResult(device_id=device_id, device_name=device_id, filename=filename, status="failed", error="Device not found"))
                continue
            try:
                pushed = await _push_license_bytes(device, filename, data, db)
                results.append(LicensePackPushResult(**pushed))
            except HTTPException as exc:
                results.append(LicensePackPushResult(device_id=device.id, device_name=device.name, filename=filename, status="failed", error=str(exc.detail)))

    _audit(db, _session, "LICENSE_PACK_PUSH", resource_type="license-pack", resource_name=manifest["filename"], details={"pack_id": pack_id, "device_ids": body.device_ids})
    return results
