from __future__ import annotations

import asyncio
import base64
import logging
import re
import shlex
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import quote

import httpx
import paramiko
from fastapi import APIRouter, Depends, File, HTTPException, Response, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from database import Device, DeviceGroup, RestCredential, SshCredential, decrypt_password, engine, get_db
from config import settings
from routers.auth import get_current_admin, get_current_session
from services.device_check import check_device, device_base_url, normalize_device_payload
from services.flowmon import FlowmonAuthError, acquire_flowmon_token, resolve_ssl_verify
from services.flow_exports import parse_exporters, serialize_exports
from services.ssh_utils import effective_ssh_port, open_ssh_connection
from services.package_installs import package_install_history, remember_package_installs
from services.support_bundle import (
    SupportBundleConflict,
    get_task as get_bundle_task,
    run_bundle_generation,
    start_bundle_task,
    sweep_stale_tasks,
)
from services.device_provisioning import (
    ProvisioningError,
    get_manager_public_key,
    provision_device,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/devices", tags=["devices"])

_OS_PACKAGE_NAMES = ("flowmon os", "flowmon", "flowmon probe", "flowmon collector")
_DETAIL_CONCURRENCY = 4
_DETAIL_QUEUE_TIMEOUT = 30.0
_DETAIL_REST_TIMEOUT = 45.0
_DETAIL_SSH_TIMEOUT = 45.0
_detail_semaphore = asyncio.Semaphore(_DETAIL_CONCURRENCY)


def _compare_package_versions(installed: str, target: str) -> int | None:
    versions = [version.strip().rstrip(".") for version in (installed, target)]
    if not all(re.fullmatch(r"\d+(?:\.\d+)*", version) for version in versions):
        return None
    left, right = [tuple(int(part) for part in version.split(".")) for version in versions]
    length = max(len(left), len(right))
    left += (0,) * (length - len(left))
    right += (0,) * (length - len(right))
    return (left > right) - (left < right)


def _audit(db, session, action, **kwargs):
    from routers.audit import write_audit
    write_audit(db, username=session.username, action=action, **kwargs)


def _base_url(ip_address: str, https_port: Optional[int]) -> str:
    """Build the device's REST API base URL, honoring an optional HTTPS port
    override for devices sitting behind a reverse proxy on a non-standard
    port."""
    return device_base_url(ip_address, https_port)


def _get_ssh_client(device: Device, db: Session) -> paramiko.SSHClient:
    cred: Optional[SshCredential] = None
    if device.ssh_credential_id:
        cred = db.get(SshCredential, device.ssh_credential_id)
    if not cred:
        raise HTTPException(status_code=400, detail="No SSH credential assigned to this device")

    try:
        return open_ssh_connection(device, cred)
    except Exception as exc:
        logger.warning("SSH connection failed device_id=%s port=%s error_type=%s",
                       device.id, effective_ssh_port(device, cred), type(exc).__name__)
        raise HTTPException(status_code=502, detail=f"SSH connection failed: {exc}")


def _ssh_read(device: Device, db: Session, command: str) -> str:
    client = _get_ssh_client(device, db)
    try:
        _, stdout, _ = client.exec_command(command)
        return stdout.read().decode("utf-8", errors="replace").strip()
    finally:
        client.close()


def _package_update_status(
    device: Device, db: Session | None, client: paramiko.SSHClient | None = None,
    timeout: float | None = None,
) -> Dict[str, Any]:
    command = (
        "{ tail -n 20 /var/log/pkg_install.log 2>/dev/null || true; "
        "echo '---PGREP---'; "
        "pgrep -af '[/](data/components/apps/bin|usr/sbin|sbin)/update-device.sh' 2>/dev/null || true; }"
    )
    if client is None:
        if db is None:
            raise ValueError("A database session is required when no SSH client is supplied")
        combined = _ssh_read(device, db, command)
    else:
        _, stdout, _ = client.exec_command(command, timeout=timeout)
        combined = stdout.read().decode("utf-8", errors="replace").strip()
    pgrep_sep = "---PGREP---"
    if pgrep_sep in combined:
        log_part, pgrep_part = combined.split(pgrep_sep, 1)
    else:
        log_part, pgrep_part = combined, ""
    lines = [line.strip() for line in log_part.splitlines() if line.strip()]
    last_line = lines[-1] if lines else None
    # Use [/]/... pattern so pgrep does not match this checker command itself.
    running = bool(pgrep_part.strip())

    if running:
        return {"status": "running", "message": last_line or "Update in progress", "package_file": None}

    if last_line and "Installation Finished:" in last_line:
        match = re.search(r"Installation Finished:\s*(.*?)\s*\*+$", last_line)
        message = match.group(1).strip() if match else last_line.replace("*", "").strip()
        return {"status": "completed", "message": message, "package_file": None}

    if last_line and re.search(r"\b(error|failed|failure)\b", last_line, re.IGNORECASE):
        return {"status": "failed", "message": last_line, "package_file": None}

    return {"status": "idle", "message": None, "package_file": None}


def _to_number(value: Any) -> Optional[float]:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        match = re.search(r"-?\d+(?:\.\d+)?", value.replace(",", "."))
        if match:
            try:
                return float(match.group(0))
            except ValueError:
                return None
    return None


def _disk_usage_entry(disk_usage: Any, category: str) -> Optional[Dict[str, Any]]:
    wanted = category.strip().lower()

    if isinstance(disk_usage, list):
        for entry in disk_usage:
            if not isinstance(entry, dict):
                continue
            for key in ("category", "name", "label", "type"):
                if str(entry.get(key, "")).strip().lower() == wanted:
                    return entry
        return None

    if isinstance(disk_usage, dict):
        for key in ("items", "entries", "data", "values"):
            nested = disk_usage.get(key)
            if isinstance(nested, (list, dict)):
                found = _disk_usage_entry(nested, category)
                if found:
                    return found

        for key in ("category", "name", "label", "type"):
            if str(disk_usage.get(key, "")).strip().lower() == wanted:
                return disk_usage

        for key, value in disk_usage.items():
            if str(key).strip().lower() != wanted:
                continue
            if isinstance(value, dict):
                return value
            number = _to_number(value)
            if number is not None:
                return {"size": number}

    return None


def _disk_usage_size_raw(entry: Optional[Dict[str, Any]]) -> Optional[float]:
    if not entry:
        return None
    for key in ("size", "value", "sizeBytes", "bytes", "sizeMb", "sizeMB", "mb", "MB"):
        if key in entry:
            size = _to_number(entry.get(key))
            if size is not None and size >= 0:
                return size
    return None


def _disk_usage_unit(entry: Optional[Dict[str, Any]]) -> Optional[str]:
    if not entry:
        return None
    for unit_key in ("unit", "units", "sizeUnit"):
        unit_value = entry.get(unit_key)
        if isinstance(unit_value, str) and unit_value.strip():
            return unit_value.strip().lower()
    if "sizeBytes" in entry or "bytes" in entry:
        return "bytes"
    if "sizeMb" in entry or "sizeMB" in entry or "mb" in entry or "MB" in entry:
        return "mb"
    return None


def _size_to_bytes(size: Optional[float], unit: Optional[str]) -> Optional[float]:
    if size is None:
        return None
    normalized = (unit or "").strip().lower()
    if normalized in {"b", "byte", "bytes"}:
        return size
    if normalized in {"mb", "mib", "megabyte", "megabytes"}:
        return size * 1_000_000
    # Heuristic fallback when API omits units: bytes are usually very large, MB relatively small.
    return size if size > 100_000_000 else size * 1_000_000


def _system_disk_to_gb(raw_value: Any) -> Optional[float]:
    size = _to_number(raw_value)
    if size is None:
        return None
    # Flowmon can expose these fields either in MB-like units (small values such as ~15000)
    # or as raw bytes (large values such as ~15182331995). Normalize to GB display.
    if size >= 1_000_000:
        return round(size / (1024 ** 3), 1)
    return round(size / 1024, 1)


def _bytes_to_gb(size_bytes: Optional[float]) -> Optional[float]:
    return round(size_bytes / 1_000_000_000, 1) if size_bytes is not None else None


def _device_type_from_license(dev_info: Dict[str, Any]) -> Optional[str]:
    direct = dev_info.get("deviceType")
    if isinstance(direct, str) and direct.strip():
        normalized = direct.strip().lower()
        if "collector" in normalized:
            return "Collector"
        if "probe" in normalized:
            return "Probe"

    for key in ("productName", "productNumber", "licenseId"):
        value = dev_info.get(key)
        if not isinstance(value, str):
            continue
        lowered = value.lower()
        if "collector" in lowered:
            return "Collector"
        if "probe" in lowered:
            return "Probe"
    return None


# ---------- Schemas ----------

class DeviceCreate(BaseModel):
    name: str
    ip_address: str
    rest_credential_id: str
    ssh_credential_id: Optional[str] = None
    verify_ssl: bool = False
    # Per-device overrides — None means "use the SSH credential's port / 443".
    ssh_port: Optional[int] = None
    https_port: Optional[int] = None


class DeviceProvisionRequest(BaseModel):
    """Body for the SSH device-provisioning wizard (POST /wizard)."""
    name: str
    ip_address: str
    ssh_username: str = "flowmon"
    ssh_password: str
    ssh_port: int = 22
    verify_ssl: bool = False
    https_port: Optional[int] = None


class ManagerPublicKeyResponse(BaseModel):
    public_key: str


class DeviceResponse(BaseModel):
    id: str
    name: str
    ip_address: str
    rest_credential_id: Optional[str]
    rest_credential_name: Optional[str]
    ssh_credential_id: Optional[str]
    ssh_credential_name: Optional[str]
    group_id: Optional[str]
    group_name: Optional[str]
    status: str
    status_message: Optional[str] = None
    verify_ssl: bool = False
    ssh_port: Optional[int] = None
    https_port: Optional[int] = None
    os_version: Optional[str]
    device_hostname: Optional[str]
    license_expiry: Optional[str]
    support_expiry: Optional[str]
    license_permanent: Optional[bool] = None
    last_seen: Optional[str]
    created_at: str
    updates_available: bool


def _to_response(
    d: Device,
    db: Session,
    *,
    rest_cred: Optional[RestCredential] = None,
    ssh_cred: Optional[SshCredential] = None,
    group: Optional[DeviceGroup] = None,
    updates_available: bool = False,
) -> DeviceResponse:
    if rest_cred is None and d.rest_credential_id:
        rest_cred = db.get(RestCredential, d.rest_credential_id)
    if ssh_cred is None and d.ssh_credential_id:
        ssh_cred = db.get(SshCredential, d.ssh_credential_id)
    if group is None and d.group_id:
        group = db.get(DeviceGroup, d.group_id)

    return DeviceResponse(
        id=d.id,
        name=d.name,
        ip_address=d.ip_address,
        rest_credential_id=d.rest_credential_id,
        rest_credential_name=rest_cred.name if rest_cred else None,
        ssh_credential_id=d.ssh_credential_id,
        ssh_credential_name=ssh_cred.name if ssh_cred else None,
        group_id=d.group_id,
        group_name=group.name if group else None,
        status=d.status or "unknown",
        status_message=d.status_message,
        verify_ssl=bool(d.verify_ssl),
        ssh_port=d.ssh_port,
        https_port=d.https_port,
        os_version=d.os_version,
        device_hostname=d.device_hostname,
        license_expiry=d.license_expiry.isoformat() if d.license_expiry else None,
        support_expiry=d.support_expiry.isoformat() if d.support_expiry else None,
        license_permanent=d.license_permanent,
        last_seen=d.last_seen.isoformat() if d.last_seen else None,
        created_at=d.created_at.isoformat() if d.created_at else "",
        updates_available=updates_available,
    )


def _get_rest_creds(device: Device, db: Session) -> tuple[str, str]:
    """Return (username, password) for the device, preferring credential ref."""
    if device.rest_credential_id:
        cred = db.get(RestCredential, device.rest_credential_id)
        if not cred:
            raise HTTPException(status_code=422, detail="REST credential not found — it may have been deleted")
        return cred.username, decrypt_password(cred.password_enc)
    # Fallback for legacy inline credentials
    if device.rest_username and device.rest_password_enc:
        return device.rest_username, decrypt_password(device.rest_password_enc)
    raise HTTPException(status_code=422, detail="Device has no REST credentials configured")


class DeviceUpdate(BaseModel):
    name: Optional[str] = None
    ip_address: Optional[str] = None
    rest_credential_id: Optional[str] = None
    ssh_credential_id: Optional[str] = None
    group_id: Optional[str] = None  # set to "" to unassign
    verify_ssl: Optional[bool] = None
    # Per-device port overrides. 0 clears the override back to the default
    # (the SSH credential's port / 443); omit the field entirely to leave
    # the current value unchanged.
    ssh_port: Optional[int] = None
    https_port: Optional[int] = None


class LicenseUploadResponse(BaseModel):
    filename: str
    installed_path: str
    device_name: str


async def _refresh_device_state(device: Device, db: Session) -> None:
    username, password = _get_rest_creds(device, db)
    device_url = _base_url(device.ip_address, device.https_port)
    info = await check_device(device_url, username, password, bool(device.verify_ssl))
    logger.log(logging.INFO if info.status == "online" else logging.WARNING,
               "Device refresh completed device_id=%s status=%s reason=%s",
               device.id, info.status, info.error or "-")

    device.status = info.status
    device.status_message = info.error
    device.os_version = info.os_version or device.os_version
    device.device_hostname = info.device_hostname or device.device_hostname
    if info.license_expiry:
        device.license_expiry = info.license_expiry
    if info.support_expiry:
        device.support_expiry = info.support_expiry
    if info.license_permanent is not None:
        device.license_permanent = info.license_permanent
    if info.status == "online":
        device.last_seen = info.checked_at


async def refresh_all_devices_status(db: Session) -> tuple[int, int]:
    devices = db.query(Device).all()
    refreshed = 0
    for device in devices:
        try:
            await _refresh_device_state(device, db)
            refreshed += 1
        except Exception as exc:
            logger.warning("Device refresh failed for %s: %s", device.name, exc)
        finally:
            # Commit after every device instead of one long-lived write
            # transaction across the whole loop. Each device check involves a
            # slow network round-trip; holding the write lock across all
            # devices (especially a slow/unreachable one) starves other
            # requests (e.g. an interactive "Refresh" click) with
            # "database is locked" errors under SQLite.
            db.commit()
    return len(devices), refreshed


# ---------- Endpoints ----------

@router.get("", response_model=List[DeviceResponse])
async def list_devices(
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
):
    devices = db.query(Device).order_by(Device.created_at).all()
    if not devices:
        return []

    # Batch load credentials and groups in memory to avoid N+1 queries
    rest_cred_ids = {d.rest_credential_id for d in devices if d.rest_credential_id}
    ssh_cred_ids = {d.ssh_credential_id for d in devices if d.ssh_credential_id}
    group_ids = {d.group_id for d in devices if d.group_id}

    rest_creds = {c.id: c for c in db.query(RestCredential).filter(RestCredential.id.in_(rest_cred_ids)).all()} if rest_cred_ids else {}
    ssh_creds = {c.id: c for c in db.query(SshCredential).filter(SshCredential.id.in_(ssh_cred_ids)).all()} if ssh_cred_ids else {}
    groups = {g.id: g for g in db.query(DeviceGroup).filter(DeviceGroup.id.in_(group_ids)).all()} if group_ids else {}

    return [
        _to_response(
            d,
            db,
            rest_cred=rest_creds.get(d.rest_credential_id),
            ssh_cred=ssh_creds.get(d.ssh_credential_id),
            group=groups.get(d.group_id),
            updates_available=False,
        )
        for d in devices
    ]


@router.get("/{device_id}", response_model=DeviceResponse)
async def get_device(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return _to_response(device, db)


@router.post("", response_model=DeviceResponse, status_code=201)
async def add_device(
    body: DeviceCreate,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    rest_cred = db.get(RestCredential, body.rest_credential_id)
    if not rest_cred:
        raise HTTPException(status_code=422, detail="REST credential not found")

    device_url = _base_url(body.ip_address, body.https_port)
    password = decrypt_password(rest_cred.password_enc)
    info = await check_device(device_url, rest_cred.username, password, body.verify_ssl)

    new_device = Device(
        name=body.name,
        ip_address=body.ip_address,
        rest_credential_id=body.rest_credential_id,
        ssh_credential_id=body.ssh_credential_id,
        verify_ssl=1 if body.verify_ssl else 0,
        ssh_port=body.ssh_port,
        https_port=body.https_port,
        status=info.status,
        status_message=info.error,
        os_version=info.os_version,
        device_hostname=info.device_hostname,
        license_expiry=info.license_expiry,
        support_expiry=info.support_expiry,
        license_permanent=info.license_permanent,
        last_seen=info.checked_at if info.status == "online" else None,
    )
    db.add(new_device)
    db.commit()
    db.refresh(new_device)
    _audit(db, _session, "DEVICE_ADD", resource_type="device", resource_name=body.name,
           details={"ip_address": body.ip_address})
    return _to_response(new_device, db)


@router.get("/wizard/public-key", response_model=ManagerPublicKeyResponse)
async def get_wizard_public_key(
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    """Return the device-manager's SSH public key, generating the manager's
    keypair on first use. Useful to display/copy before running the wizard."""
    return ManagerPublicKeyResponse(public_key=get_manager_public_key(db))


@router.post("/wizard", response_model=DeviceResponse, status_code=201)
async def add_device_via_wizard(
    body: DeviceProvisionRequest,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    """Add a device by bootstrapping it over SSH instead of requiring the
    admin to hand-create credential sets first.

    Connects once with the given ``flowmon`` SSH credentials (never
    stored), installs the manager's SSH public key, and creates a local
    ``fm-user`` REST/CLI account on the device. The resulting SSH/REST
    credential sets are reused for every device provisioned this way.
    """
    def _do_audit(action: str, **kwargs: Any) -> None:
        _audit(db, _session, action, **kwargs)

    try:
        ssh_cred, rest_cred = await asyncio.to_thread(
            provision_device,
            db=db,
            ip_address=body.ip_address,
            ssh_port=body.ssh_port,
            bootstrap_username=body.ssh_username,
            bootstrap_password=body.ssh_password,
            audit=_do_audit,
        )
    except ProvisioningError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    device_url = _base_url(body.ip_address, body.https_port)
    password = decrypt_password(rest_cred.password_enc)
    info = await check_device(device_url, rest_cred.username, password, body.verify_ssl)

    new_device = Device(
        name=body.name,
        ip_address=body.ip_address,
        rest_credential_id=rest_cred.id,
        ssh_credential_id=ssh_cred.id,
        verify_ssl=1 if body.verify_ssl else 0,
        # Always store the port used for this run on the device itself —
        # the SSH credential can be shared across devices that each expose
        # SSH on a different port, so its own `port` field must not be
        # treated as authoritative for every device that reuses it.
        ssh_port=body.ssh_port,
        https_port=body.https_port,
        status=info.status,
        status_message=info.error,
        os_version=info.os_version,
        device_hostname=info.device_hostname,
        license_expiry=info.license_expiry,
        support_expiry=info.support_expiry,
        license_permanent=info.license_permanent,
        last_seen=info.checked_at if info.status == "online" else None,
    )
    db.add(new_device)
    db.commit()
    db.refresh(new_device)
    _audit(db, _session, "DEVICE_ADD", resource_type="device", resource_name=body.name,
           details={"ip_address": body.ip_address, "method": "ssh_wizard"})
    return _to_response(new_device, db)


@router.put("/{device_id}", response_model=DeviceResponse)
async def update_device(
    device_id: str,
    body: DeviceUpdate,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    if body.name is not None:
        device.name = body.name
    if body.ip_address is not None:
        device.ip_address = body.ip_address
    if body.rest_credential_id is not None:
        if not db.get(RestCredential, body.rest_credential_id):
            raise HTTPException(status_code=422, detail="REST credential not found")
        device.rest_credential_id = body.rest_credential_id
    if body.ssh_credential_id is not None:
        device.ssh_credential_id = body.ssh_credential_id or None
    if body.group_id is not None:
        device.group_id = body.group_id or None
    if body.verify_ssl is not None:
        device.verify_ssl = 1 if body.verify_ssl else 0
    if body.ssh_port is not None:
        device.ssh_port = body.ssh_port or None
    if body.https_port is not None:
        device.https_port = body.https_port or None
    db.commit()
    db.refresh(device)
    return _to_response(device, db)


@router.post("/{device_id}/license/upload", response_model=LicenseUploadResponse)
async def upload_device_license(
    device_id: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    if not device.rest_credential_id:
        raise HTTPException(status_code=400, detail="No REST credential assigned to this device")

    rest_cred = db.get(RestCredential, device.rest_credential_id)
    if not rest_cred:
        raise HTTPException(status_code=422, detail="REST credential not found — it may have been deleted")

    original_name = file.filename or ""
    filename = Path(original_name).name
    if not filename or filename in {".", ".."} or filename != original_name or "/" in original_name or "\\" in original_name:
        raise HTTPException(status_code=400, detail="Invalid license filename")

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded license file is empty")

    try:
        base = _base_url(device.ip_address, device.https_port)
        token_data = await acquire_flowmon_token(
            base, rest_cred.username, decrypt_password(rest_cred.password_enc), bool(device.verify_ssl)
        )
        token = token_data["access_token"]
    except FlowmonAuthError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot authenticate to device: {exc}") from exc

    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(bool(device.verify_ssl)), timeout=30.0) as client:
            content = base64.b64encode(data).decode("ascii").strip()
            payload = {
                "entity": {
                    "content": content,
                }
            }

            response = await client.put(
                f"{base}/rest/fcc/license",
                headers={"Authorization": f"bearer {token}"},
                json=payload,
            )
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        raise HTTPException(status_code=502, detail=f"License upload failed: {exc}") from exc

    if response.status_code // 100 != 2:
        detail = None
        try:
            body = response.json()
            if isinstance(body, dict):
                detail = (
                    body.get("detail")
                    or body.get("message")
                    or body.get("error")
                    or body.get("error_description")
                )
                entity = body.get("entity")
                if not detail and isinstance(entity, dict):
                    detail = entity.get("detail") or entity.get("message") or entity.get("error")
        except ValueError:
            pass
        detail = (detail or response.text.strip() or f"License upload failed with HTTP {response.status_code}").strip()
        raise HTTPException(status_code=502, detail=detail)

    try:
        await _refresh_device_state(device, db)
        db.commit()
        db.refresh(device)
    except HTTPException:
        db.commit()

    _audit(
        db,
        _session,
        "DEVICE_LICENSE_UPLOAD",
        resource_type="device",
        resource_name=device.name,
        details={"filename": filename, "installed_path": "/rest/fcc/license"},
    )
    return LicenseUploadResponse(filename=filename, installed_path="/rest/fcc/license", device_name=device.name)


@router.post("/{device_id}/refresh", response_model=DeviceResponse)
async def refresh_device(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    await _refresh_device_state(device, db)
    db.commit()
    db.refresh(device)
    return _to_response(device, db)


def _empty_device_live() -> Dict[str, Any]:
    return {
        key: None for key in (
            "cpu_info", "cpu_load", "cpu_load_raw", "memory_usage_pct",
            "memory_used_mb", "memory_total_mb", "system_disk_usage_pct",
            "system_disk_used_gb", "system_disk_total_gb", "data_disk_usage_pct",
            "data_disk_total_gb", "data_disk_free_gb", "days_running",
            "smart_status", "raid_status",
        )
    }


async def _get_device_rest_detail(device: Device, username: str, password: str) -> Dict[str, Any]:
    base = _base_url(device.ip_address, device.https_port)

    import httpx
    from config import settings
    from services.flowmon import FlowmonAuthError, acquire_flowmon_token

    verify = bool(device.verify_ssl)
    try:
        token_data = await acquire_flowmon_token(base, username, password, verify)
        token = token_data["access_token"]
    except FlowmonAuthError as exc:
        raise HTTPException(status_code=502, detail=f"Cannot authenticate to device: {exc}")

    headers = {"Authorization": f"bearer {token}"}
    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(verify), timeout=15.0) as client:
            device_res = await client.get(f"{base}/rest/fcc/device", headers=headers)
            license_res = await client.get(f"{base}/rest/fcc/license", headers=headers)
            iface_res = await client.get(f"{base}/rest/fcc/interfaces", headers=headers)
            version_res = await client.get(f"{base}/rest/version", headers=headers)
            # Flow export configuration is probe-only; a collector answers 404
            # here, which is handled below rather than failing the request.
            exporters_res = await client.get(f"{base}/rest/fcc/exporters/", headers=headers)
            exporter_status_res = await client.get(
                f"{base}/rest/fcc/exporters/status/", headers=headers
            )
    except httpx.RequestError as exc:
        logger.warning("Device detail REST failed device_id=%s error_type=%s", device.id, type(exc).__name__)
        raise HTTPException(status_code=502, detail=f"Device communication failed ({type(exc).__name__})") from exc

    live: Dict[str, Any] = _empty_device_live()
    if device_res.status_code == 200:
        d = normalize_device_payload(device_res.json())
        system_disk_used_mb = d.get("sysdiskUsageMb")
        system_disk_total_mb = d.get("sysdiskTotalMb")
        data_disk_total = _disk_usage_entry(d.get("diskUsage"), "Total")
        data_disk_free = _disk_usage_entry(d.get("diskUsage"), "Free")
        data_disk_total_bytes = _size_to_bytes(_disk_usage_size_raw(data_disk_total), _disk_usage_unit(data_disk_total))
        data_disk_free_bytes = _size_to_bytes(_disk_usage_size_raw(data_disk_free), _disk_usage_unit(data_disk_free))
        live = {
            "cpu_info": d.get("cpuInfo"),
            "cpu_load": d.get("cpuLoadAvgPerc"),
            "cpu_load_raw": d.get("cpuLoad"),
            "memory_usage_pct": d.get("memory"),
            "memory_used_mb": round(d.get("memoryUsageMb", 0) / 1024, 1) if d.get("memoryUsageMb") else None,
            "memory_total_mb": round(d.get("memoryTotalMb", 0) / 1024, 1) if d.get("memoryTotalMb") else None,
            "system_disk_usage_pct": d.get("sysdiskUsage"),
            "system_disk_used_gb": _system_disk_to_gb(system_disk_used_mb),
            "system_disk_total_gb": _system_disk_to_gb(system_disk_total_mb),
            "data_disk_usage_pct": round(((data_disk_total_bytes - data_disk_free_bytes) / data_disk_total_bytes) * 100, 1)
            if data_disk_total_bytes is not None and data_disk_free_bytes is not None and data_disk_total_bytes > 0
            else None,
            "data_disk_total_gb": _bytes_to_gb(data_disk_total_bytes),
            "data_disk_free_gb": _bytes_to_gb(data_disk_free_bytes),
            "days_running": d.get("daysRunning"),
            "smart_status": d.get("smartStatus"),
            "raid_status": d.get("raidStatus"),
        }

    license_data: Dict[str, Any] = {"functions": []}
    license_device_type: Optional[str] = None
    if license_res.status_code == 200:
        ld = license_res.json()
        dev_info = ld.get("device", {})
        license_device_type = _device_type_from_license(dev_info)
        functions = ld.get("function", [])
        parsed_functions = []
        for f in functions:
            parsed_functions.append({
                "code": f.get("code"),
                "name": f.get("name"),
                "version": f.get("version"),
                "license_type": f.get("licenseType"),
                "license_from": f.get("licenseFrom"),
                "license_to": f.get("licenseTo"),
                "license_validity": f.get("licenseValidity"),
                "support_type": f.get("supportType"),
                "support_from": f.get("supportFrom"),
                "support_to": f.get("supportTo"),
                "support_validity": f.get("supportValidity"),
            })
        # hwId at root level is the actual device hardware ID
        hardware_id = ld.get("hwId") or dev_info.get("hwId")
        license_data = {
            "product_name": dev_info.get("productName"),
            "product_number": dev_info.get("productNumber"),
            "license_id": dev_info.get("licenseId"),
            "hardware_id": hardware_id,
            "temporary_license": dev_info.get("temporaryLicense"),
            "development_license": dev_info.get("developmentLicense"),
            "functions": parsed_functions,
        }

    interfaces = []
    if iface_res.status_code == 200:
        for iface in iface_res.json():
            interfaces.append({
                "id": iface.get("id"),
                "type": iface.get("type"),
                "ip": iface.get("ip"),
                "mac": iface.get("mac"),
                "speed": iface.get("speed"),
                "link_detected": iface.get("linkDetected"),
                "rx_bytes": iface.get("rxBytes"),
                "tx_bytes": iface.get("txBytes"),
                "mtu": iface.get("mtu"),
            })

    os_version = None
    if version_res.status_code == 200:
        os_version = version_res.json().get("version")

    # Where each monitoring interface sends its flow data. Absent on
    # collector-only devices, which have no exporters.
    flow_exports: list[Dict[str, Any]] = []
    if exporters_res.status_code == 200:
        try:
            status_body = (
                exporter_status_res.json() if exporter_status_res.status_code == 200 else None
            )
            flow_exports = serialize_exports(
                parse_exporters(exporters_res.json(), status_body)
            )
        except ValueError:
            logger.warning("Invalid exporter JSON device_id=%s", device.id)
            # Malformed JSON from the device must not sink the whole page.
            flow_exports = []

    return {
        "live": live,
        "license": license_data,
        "interfaces": interfaces,
        "flow_exports": flow_exports,
        "os_version": os_version,
        "device_type": license_device_type,
    }


def _get_device_ssh_detail(device: Device, ssh_cred_obj: SshCredential | None) -> Dict[str, Any]:
    package_update = {"status": "idle", "message": None, "package_file": None}

    # Fetch package info + available updates via SSH if credentials are available
    packages: list[Dict[str, Any]] = []
    available_updates: list[Dict[str, Any]] = []
    package_files: list[str] = []
    install_log: str | None = None
    platform: str | None = None
    ssh_error: str | None = None

    if ssh_cred_obj:
        deadline = time.monotonic() + _DETAIL_SSH_TIMEOUT

        def remaining() -> float:
            seconds = deadline - time.monotonic()
            if seconds <= 0:
                raise TimeoutError("Device SSH detail timed out")
            return min(seconds, 10.0)

        try:
            client = open_ssh_connection(device, ssh_cred_obj)
            watchdog: threading.Timer | None = None
            try:
                remaining()
                watchdog = threading.Timer(max(0, deadline - time.monotonic()), client.close)
                watchdog.daemon = True
                watchdog.start()
                package_update = _package_update_status(device, None, client, timeout=remaining())

                def _read(cmd: str) -> str:
                    _, stdout, _ = client.exec_command(cmd, timeout=remaining())
                    return stdout.read().decode().strip()

                pkg_raw = _read("cat /etc/flowmon/pkg_versions.txt 2>/dev/null || true")
                platform = _read("cat /etc/flowmon/platform 2>/dev/null || true") or None
                _, log_stdout, log_stderr = client.exec_command(
                    "if [ -f /var/log/pkg_install.log ]; then tail -n 10000 /var/log/pkg_install.log; fi",
                    timeout=remaining(),
                )
                log_content = log_stdout.read().decode("utf-8", errors="replace")
                log_error = log_stderr.read().decode("utf-8", errors="replace").strip()
                while not log_stdout.channel.exit_status_ready():
                    time.sleep(min(0.1, remaining()))
                if log_stdout.channel.recv_exit_status() != 0:
                    raise RuntimeError(f"Cannot read package install log: {log_error}")
                install_log = log_content

                # Parse installed packages into a lookup dict  name → version
                installed: Dict[str, str] = {}
                for line in pkg_raw.splitlines():
                    line = line.strip()
                    if ";" in line:
                        n, _, v = line.partition(";")
                        n, v = n.strip(), v.strip()
                        installed[n] = v
                        packages.append({"name": n, "version": v})

                # Scan /data/packages/ for downloaded update packages.
                # Naming convention:
                #   {component}-v{version}.tar.gz        — the update package
                #   {n}_{component}-v{version}-README.txt — release notes
                pkg_files_raw = _read("ls /data/packages/ 2>/dev/null || true")
                pkg_files = [f.strip() for f in pkg_files_raw.splitlines() if f.strip()]
                package_files = [f for f in pkg_files if f.endswith(".tar.gz")]

                def _match_installed(component: str) -> tuple[str | None, str | None]:
                    """Map a package filename component to an installed package name+version."""
                    c = component.lower()
                    # "flowmon" (no suffix) = the OS itself
                    if c == "flowmon":
                        for name, ver in installed.items():
                            if name.strip().lower() in _OS_PACKAGE_NAMES:
                                return name, ver
                    # "flowmonplug-{plugin}" = a plugin; match by plugin slug
                    if c.startswith("flowmonplug-"):
                        plugin = c[len("flowmonplug-"):]  # e.g. "ads", "fpi", "apm"
                        for name, ver in installed.items():
                            # "Flowmon ADS" contains "ads", "Flowmon FPI" contains "fpi"
                            if plugin in name.lower().replace(" ", ""):
                                return name, ver
                    # Fallback: substring match both ways
                    for name, ver in installed.items():
                        norm = name.lower().replace(" ", "-")
                        if c == norm or c in norm or norm in c:
                            return name, ver
                    return None, None

                # Build map: key "{component}-v{version}" → {pkg_file, readme_file, readme_content}
                update_map: Dict[str, Dict[str, Any]] = {}

                for fname in pkg_files:
                    # Match update package: component-v1.2.3.tar.gz
                    m = re.match(r'^(.+?)-v([\d.]+)\.tar\.gz$', fname, re.IGNORECASE)
                    if m:
                        key = f"{m.group(1)}-v{m.group(2)}"
                        entry = update_map.setdefault(key, {"component": m.group(1), "version": m.group(2)})
                        entry["pkg_file"] = fname
                        continue

                    # Match README: 123_component-v1.2.3-README.txt
                    m = re.match(r'^\d+_(.+?)-v([\d.]+)-README\.txt$', fname, re.IGNORECASE)
                    if m:
                        key = f"{m.group(1)}-v{m.group(2)}"
                        entry = update_map.setdefault(key, {"component": m.group(1), "version": m.group(2)})
                        entry["readme_file"] = fname
                        # shlex.quote prevents command injection via a crafted filename
                        entry["release_notes"] = _read(
                            f"cat /data/packages/{shlex.quote(fname)} 2>/dev/null || true"
                        ) or None

                # Match against installed packages using the precise mapping function
                for key, entry in update_map.items():
                    matched_name, matched_installed_version = _match_installed(entry["component"])
                    comparison = (
                        _compare_package_versions(matched_installed_version, entry["version"])
                        if matched_installed_version is not None else None
                    )
                    is_update = (
                        matched_installed_version is not None
                        and (comparison < 0 if comparison is not None else matched_installed_version != entry["version"])
                    )
                    available_updates.append({
                        "file": entry.get("pkg_file", entry.get("readme_file", key)),
                        "component": entry["component"],
                        "name": matched_name or entry["component"],
                        "version": entry["version"],
                        "installed_version": matched_installed_version,
                        "is_update": is_update,
                        "release_notes": entry.get("release_notes"),
                    })
            finally:
                if watchdog is not None:
                    watchdog.cancel()
                client.close()
        except Exception as exc:
            ssh_error = f"Cannot read device SSH details: {exc}"
            logger.warning("Device detail SSH failed device_id=%s error_type=%s",
                           device.id, type(exc).__name__)

    return {
        "packages": packages,
        "available_updates": available_updates,
        "package_files": package_files,
        "package_update": package_update,
        "install_log": install_log,
        "ssh_error": ssh_error,
        "platform": platform,
    }


def _prepare_device_detail(device_id: str, db: Session) -> tuple[Device, SshCredential | None, str, str, Dict[str, Any]]:
    try:
        device = db.get(Device, device_id)
        if not device:
            raise HTTPException(status_code=404, detail="Device not found")
        username, password = _get_rest_creds(device, db)
        rest_cred = db.get(RestCredential, device.rest_credential_id) if device.rest_credential_id else None
        ssh_cred = db.get(SshCredential, device.ssh_credential_id) if device.ssh_credential_id else None
        group = db.get(DeviceGroup, device.group_id) if device.group_id else None
        metadata = {
            "id": device.id, "name": device.name, "ip_address": device.ip_address,
            "status": device.status or "unknown", "os_version": device.os_version,
            "device_hostname": device.device_hostname,
            "rest_credential_name": rest_cred.name if rest_cred else None,
            "ssh_credential_name": ssh_cred.name if ssh_cred else None,
            "group_name": group.name if group else None,
            "license_expiry": device.license_expiry.isoformat() if device.license_expiry else None,
            "support_expiry": device.support_expiry.isoformat() if device.support_expiry else None,
            "last_seen": device.last_seen.isoformat() if device.last_seen else None,
            "created_at": device.created_at.isoformat() if device.created_at else None,
        }
        return device, ssh_cred, username, password, metadata
    finally:
        db.close()


def _finish_device_ssh_detail(device_id: str, ssh_detail: Dict[str, Any]) -> None:
    with Session(engine) as db:
        install_log = ssh_detail.pop("install_log")
        if install_log is not None:
            remember_package_installs(db, device_id, install_log)
        ssh_detail["package_installs"] = package_install_history(db, device_id)


async def _limit_device_detail():
    try:
        await asyncio.wait_for(_detail_semaphore.acquire(), timeout=_DETAIL_QUEUE_TIMEOUT)
    except asyncio.TimeoutError as exc:
        logger.warning("Device detail queue full")
        raise HTTPException(status_code=503, detail="Device details are busy; please retry") from exc
    try:
        yield
    finally:
        _detail_semaphore.release()


@router.get("/{device_id}/detail", dependencies=[Depends(_limit_device_detail)])
async def get_device_detail(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_session),
) -> Dict[str, Any]:
    """Fetch REST details and SSH update status, including during maintenance."""
    device, ssh_cred, username, password, metadata = await run_in_threadpool(_prepare_device_detail, device_id, db)
    ssh_task = asyncio.create_task(run_in_threadpool(_get_device_ssh_detail, device, ssh_cred))
    try:
        ssh_detail = await asyncio.shield(ssh_task)
    except asyncio.CancelledError:
        # A running SSH thread cannot be cancelled; keep its admission slot until it exits.
        await asyncio.shield(ssh_task)
        raise
    await run_in_threadpool(_finish_device_ssh_detail, device_id, ssh_detail)
    rest_error: str | None = None
    try:
        try:
            rest_detail = await asyncio.wait_for(
                _get_device_rest_detail(device, username, password), timeout=_DETAIL_REST_TIMEOUT
            )
        except asyncio.TimeoutError as exc:
            logger.warning("Device detail REST timed out device_id=%s", device_id)
            raise HTTPException(status_code=502, detail="Device detail REST request timed out") from exc
    except HTTPException as exc:
        if exc.status_code != 502 or ssh_detail["package_update"]["status"] != "running":
            raise
        rest_error = str(exc.detail)
        logger.info("REST unavailable during package update device_id=%s", device.id)
        rest_detail = {
            "live": _empty_device_live(), "license": {"functions": []},
            "interfaces": [], "flow_exports": [],
            "os_version": None, "device_type": None,
        }

    return {
        "device": {
            **metadata,
            "os_version": rest_detail["os_version"] or metadata["os_version"],
            "device_type": rest_detail["device_type"],
            "platform": ssh_detail["platform"],
        },
        "live": rest_detail["live"],
        "license": rest_detail["license"],
        "interfaces": rest_detail["interfaces"],
        "flow_exports": rest_detail["flow_exports"],
        "packages": ssh_detail["packages"],
        "available_updates": ssh_detail["available_updates"],
        "package_files": ssh_detail["package_files"],
        "package_update": ssh_detail["package_update"],
        "rest_error": rest_error,
        "package_installs": ssh_detail["package_installs"],
        "ssh_error": ssh_detail["ssh_error"],
    }


class PackageInstallResponse(BaseModel):
    device_id: str
    package_file: str
    status: str
    message: str


@router.post("/{device_id}/packages/{package_file}/install", response_model=PackageInstallResponse, status_code=202)
async def install_package_update(
    device_id: str,
    package_file: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> PackageInstallResponse:
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")

    if "/" in package_file or ".." in package_file:
        raise HTTPException(status_code=400, detail="Invalid package filename")

    if _ssh_read(device, db, "pgrep -af '[/](data/components/apps/bin|usr/sbin|sbin)/update-device.sh' 2>/dev/null || true"):
        raise HTTPException(status_code=409, detail="Update already in progress on this device")

    os_package = re.fullmatch(r"flowmon-v([\d.]+)\.tar\.gz", package_file, re.IGNORECASE)
    if os_package:
        installed_packages = _ssh_read(device, db, "cat /etc/flowmon/pkg_versions.txt")
        installed_version = next(
            (version.strip() for line in installed_packages.splitlines()
             for name, separator, version in [line.partition(";")]
             if separator and name.strip().lower() in _OS_PACKAGE_NAMES),
            None,
        )
        comparison = (
            _compare_package_versions(installed_version, os_package.group(1))
            if installed_version is not None else None
        )
        if comparison is None:
            raise HTTPException(status_code=502, detail="Cannot verify installed Flowmon OS version; update not started")
        if comparison >= 0:
            raise HTTPException(
                status_code=409,
                detail=f"Flowmon OS {installed_version} is already installed; equal or older packages cannot be installed",
            )

    client = _get_ssh_client(device, db)
    try:
        pkg_path = shlex.quote(f"/data/packages/{package_file}")
        command = (
            f"nohup sh -c 'if [ -x /data/components/apps/bin/update-device.sh ]; then sudo -n /data/components/apps/bin/update-device.sh {pkg_path}; "
            f"elif [ -x /usr/sbin/update-device.sh ]; then sudo -n /usr/sbin/update-device.sh {pkg_path}; "
            f"elif which update-device.sh >/dev/null 2>&1; then sudo -n \"$(which update-device.sh)\" {pkg_path}; "
            f"else echo \"update-device.sh not found\" >&2; exit 127; fi' "
            f">/data/tmp/fdm-update.log 2>&1 </dev/null &"
        )
        client.exec_command(command)
    finally:
        client.close()

    logger.info("Package update launch requested device_id=%s filename=%s remote_log=/data/tmp/fdm-update.log",
                device.id, package_file)
    return PackageInstallResponse(
        device_id=device_id,
        package_file=package_file,
        status="started",
        message="Update in progress",
    )


class SupportBundleStartResponse(BaseModel):
    task_id: str
    status: str


class SupportBundleStatusResponse(BaseModel):
    task_id: str
    status: str
    error: Optional[str] = None
    size_bytes: Optional[int] = None
    elapsed_seconds: int


def _get_ssh_credential(device: Device, db: Session) -> SshCredential:
    cred: Optional[SshCredential] = None
    if device.ssh_credential_id:
        cred = db.get(SshCredential, device.ssh_credential_id)
    if not cred:
        raise HTTPException(status_code=400, detail="No SSH credential assigned to this device")
    return cred


@router.post(
    "/{device_id}/support-bundle", response_model=SupportBundleStartResponse, status_code=202
)
async def start_support_bundle(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
) -> SupportBundleStartResponse:
    """Kick off `gather-logs.sh` on the device and stage the resulting archive.

    Generation runs in a background thread — it legitimately takes minutes on
    a busy appliance — and the caller polls `/support-bundle/{task_id}` until
    the bundle is ready to download.
    """
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    cred = _get_ssh_credential(device, db)
    secret = decrypt_password(cred.secret_enc)

    sweep_stale_tasks()
    try:
        task = start_bundle_task(device.id, device.name, _session.username)
    except SupportBundleConflict as exc:
        raise HTTPException(
            status_code=409,
            detail={
                "message": str(exc),
                "task_id": exc.task_id,
            },
        ) from exc
    # Pass plain values, not ORM instances — this request's DB session (and
    # thus the objects bound to it) closes as soon as the endpoint returns,
    # long before the background thread finishes running gather-logs.sh.
    asyncio.create_task(
        asyncio.to_thread(
            run_bundle_generation,
            task.id,
            device.name,
            device.ip_address,
            effective_ssh_port(device, cred),
            cred.auth_type,
            cred.username,
            secret,
            _session.username,
        )
    )

    _audit(
        db,
        _session,
        "DEVICE_SUPPORT_BUNDLE_START",
        resource_type="device",
        resource_name=device.name,
        details={"device_id": device.id, "task_id": task.id},
    )
    return SupportBundleStartResponse(task_id=task.id, status=task.status)


@router.get("/{device_id}/support-bundle/{task_id}", response_model=SupportBundleStatusResponse)
async def get_support_bundle_status(
    device_id: str,
    task_id: str,
    _session=Depends(get_current_admin),
) -> SupportBundleStatusResponse:
    task = get_bundle_task(task_id)
    if not task or task.device_id != device_id:
        raise HTTPException(status_code=404, detail="Support bundle task not found")
    return SupportBundleStatusResponse(
        task_id=task.id,
        status=task.status,
        error=task.error,
        size_bytes=task.size_bytes,
        elapsed_seconds=int((task.finished_at or time.monotonic()) - task.started_at),
    )


def _support_bundle_download_info(device_id: str, task_id: str):
    task = get_bundle_task(task_id)
    if not task or task.device_id != device_id:
        raise HTTPException(status_code=404, detail="Support bundle task not found")
    if task.status == "running":
        raise HTTPException(status_code=409, detail="Support bundle is still being generated")
    if task.status == "failed":
        raise HTTPException(status_code=502, detail=task.error or "Support bundle generation failed")
    if not task.local_path or not task.local_path.exists():
        raise HTTPException(status_code=410, detail="Support bundle is no longer available; generate a new one")

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    safe_device_name = re.sub(r"[^A-Za-z0-9._-]+", "-", task.device_name).strip(".-_")
    safe_device_name = (safe_device_name or "device")[:80]
    ascii_filename = f"{safe_device_name}-support-{timestamp}.tar.gz"
    utf8_filename = f"{task.device_name}-support-{timestamp}.tar.gz"
    content_disposition = (
        f'attachment; filename="{ascii_filename}"; '
        f"filename*=UTF-8''{quote(utf8_filename)}"
    )
    return task, task.local_path, {
        "Content-Disposition": content_disposition,
        "Content-Length": str(task.local_path.stat().st_size),
    }


@router.head("/{device_id}/support-bundle/{task_id}/download")
async def check_support_bundle_download(
    device_id: str,
    task_id: str,
    _session=Depends(get_current_admin),
):
    _, _, headers = _support_bundle_download_info(device_id, task_id)
    return Response(media_type="application/gzip", headers=headers)


@router.get("/{device_id}/support-bundle/{task_id}/download")
async def download_support_bundle(
    device_id: str,
    task_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    task, path, headers = _support_bundle_download_info(device_id, task_id)
    device = task.device_name
    size_bytes = path.stat().st_size

    def _iter_file():
        with open(path, "rb") as f:
            while chunk := f.read(1024 * 1024):
                yield chunk

    _audit(
        db,
        _session,
        "DEVICE_SUPPORT_BUNDLE_DOWNLOAD",
        resource_type="device",
        resource_name=device,
        details={
            "device_id": device_id,
            "task_id": task_id,
            "size_bytes": size_bytes,
        },
    )

    return StreamingResponse(
        _iter_file(),
        media_type="application/gzip",
        headers=headers,
    )


@router.delete("/{device_id}", status_code=204)
async def delete_device(
    device_id: str,
    db: Session = Depends(get_db),
    _session=Depends(get_current_admin),
):
    device = db.get(Device, device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    name = device.name
    db.delete(device)
    db.commit()
    _audit(db, _session, "DEVICE_DELETE", resource_type="device", resource_name=name)
