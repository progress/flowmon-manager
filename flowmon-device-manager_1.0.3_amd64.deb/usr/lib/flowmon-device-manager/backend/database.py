from __future__ import annotations

import base64
import hashlib
import os
import secrets
import stat
import uuid
from datetime import datetime, timezone
from typing import Optional

import bcrypt
from cryptography.fernet import Fernet
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint, create_engine, event, text
from sqlalchemy.orm import DeclarativeBase, Session

from paths import DATA_DIR

DATABASE_URL = f"sqlite:///{DATA_DIR / 'fdm.db'}" if "FDM_DATA_DIR" in os.environ else "sqlite:///./fdm.db"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False, "timeout": 30.0},
)


@event.listens_for(engine, "connect")
def _set_sqlite_pragma(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA busy_timeout=30000")
    cursor.close()


class Base(DeclarativeBase):
    pass


class User(Base):
    """Local application user account."""
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String, nullable=False, unique=True, index=True)
    password_hash = Column(String, nullable=False)
    is_admin = Column(Integer, nullable=False, default=0)         # sqlite-safe bool
    disabled = Column(Integer, nullable=False, default=0)          # sqlite-safe bool
    must_change_password = Column(Integer, nullable=False, default=0)  # sqlite-safe bool
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class DeviceSession(Base):
    __tablename__ = "sessions"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String, nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class OidcIdentity(Base):
    __tablename__ = "oidc_identities"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    issuer = Column(String, nullable=False)
    subject = Column(String, nullable=False)
    user_id = Column(String, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    __table_args__ = (UniqueConstraint("issuer", "subject"),)


class OidcLoginAttempt(Base):
    __tablename__ = "oidc_login_attempts"
    state_hash = Column(String, primary_key=True)
    browser_hash = Column(String, nullable=False)
    nonce = Column(String, nullable=False)
    verifier = Column(String, nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False, index=True)


class DeviceGroup(Base):
    """A named group that devices can belong to (one group per device)."""
    __tablename__ = "device_groups"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Device(Base):
    __tablename__ = "devices"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    ip_address = Column(String, nullable=False)
    # Inline credentials kept for backward-compat; nullable when using credential refs
    rest_username = Column(String, nullable=True)
    rest_password_enc = Column(String, nullable=True)
    # Credential references (preferred)
    rest_credential_id = Column(String, ForeignKey("rest_credentials.id", ondelete="SET NULL"), nullable=True)
    ssh_credential_id = Column(String, ForeignKey("ssh_credentials.id", ondelete="SET NULL"), nullable=True)
    group_id = Column(String, ForeignKey("device_groups.id", ondelete="SET NULL"), nullable=True)
    status = Column(String, default="unknown")
    status_message = Column(String, nullable=True)  # why the device is offline, if it is
    unreachable_check_failures = Column(Integer, nullable=False, default=0)
    # Flowmon appliances ship self-signed certs, so verification is off by default
    verify_ssl = Column(Integer, nullable=False, default=0)
    # Per-device connection port overrides. NULL means "fall back to the
    # default" (22 for SSH, or the SSH credential's own port; 443 for HTTPS).
    # Needed because the same SSH credential/key can be reused across devices
    # that each expose SSH on a different forwarded/proxied port, and some
    # devices sit behind a reverse proxy that serves the REST API on a
    # non-standard HTTPS port.
    ssh_port = Column(Integer, nullable=True)
    https_port = Column(Integer, nullable=True)
    os_version = Column(String, nullable=True)
    device_hostname = Column(String, nullable=True)
    license_expiry = Column(DateTime(timezone=True), nullable=True)
    support_expiry = Column(DateTime(timezone=True), nullable=True)
    # True = device reports a permanent (non-temporary) license; False = temporary;
    # NULL = unknown (never checked or last check couldn't read license info).
    license_permanent = Column(Boolean, nullable=True)
    last_seen = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class DevicePackageInstall(Base):
    __tablename__ = "device_package_installs"

    device_id = Column(String, ForeignKey("devices.id", ondelete="CASCADE"), primary_key=True)
    package_file = Column(String, primary_key=True)
    package_name = Column(String, nullable=False)
    package_version = Column(String, nullable=True)
    finished_at = Column(String, nullable=False)


class RestCredential(Base):
    """Named REST API credential set (username + password)."""
    __tablename__ = "rest_credentials"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)           # human-readable label
    username = Column(String, nullable=False)
    password_enc = Column(String, nullable=False)   # Fernet-encrypted
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))


class SshCredential(Base):
    """Named SSH credential set (username + password or private key)."""
    __tablename__ = "ssh_credentials"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)           # human-readable label
    username = Column(String, nullable=False)
    port = Column(Integer, nullable=False, default=22)
    auth_type = Column(String, nullable=False, default="password")  # "password" | "key"
    secret_enc = Column(String, nullable=False)     # Fernet-encrypted password or private key
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))


class DeviceProvisioningConfig(Base):
    """Singleton config for the SSH device-provisioning wizard.

    Holds the manager's own SSH keypair (installed on devices' authorized_keys
    during provisioning) and the shared password for the local ``fm-user``
    REST/CLI account created on each device. Both are generated lazily, once,
    on first use of the wizard and then reused for every device provisioned
    this way — the actual credential sets attached to devices are ordinary
    rows in ``ssh_credentials``/``rest_credentials``.
    """
    __tablename__ = "device_provisioning_config"

    id = Column(String, primary_key=True, default=lambda: "default")
    manager_public_key = Column(Text, nullable=True)
    manager_private_key_enc = Column(Text, nullable=True)   # Fernet-encrypted PEM
    fm_user_password_enc = Column(Text, nullable=True)      # Fernet-encrypted
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class AuditLog(Base):
    """Immutable audit trail of user activity."""
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    timestamp = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    username = Column(String, nullable=False)
    action = Column(String, nullable=False)          # LOGIN, LOGOUT, DEVICE_ADD, DEVICE_DELETE, etc.
    resource_type = Column(String, nullable=True)    # "device", "rest_credential", "ssh_credential"
    resource_name = Column(String, nullable=True)    # human-readable name of the resource
    details = Column(Text, nullable=True)            # JSON string with extra info
    ip_address = Column(String, nullable=True)


class DeviceBackup(Base):
    """Stored configuration backup snapshots per device."""
    __tablename__ = "device_backups"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    device_id = Column(String, ForeignKey("devices.id", ondelete="CASCADE"), nullable=False)
    content_hash = Column(String, nullable=False)  # sha256 of normalized (timestamp-stripped) backup content
    content = Column(Text, nullable=False)         # raw XML backup content
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    last_verified_at = Column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("ix_device_backups_device_id_created_at", "device_id", "created_at"),
    )


class DevicePerfSample(Base):
    """Time-series performance samples collected from a device over SSH.

    Mirrors the metrics gathered by the Flowmon `perfmon.sh` script, but sampled
    over a live 1-second interval rather than since-boot averages so the values
    are meaningful when charted.
    """
    __tablename__ = "device_perf_samples"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    device_id = Column(String, ForeignKey("devices.id", ondelete="CASCADE"), nullable=False)
    collected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    # Storage (the data partition)
    disk_percent = Column(Float, nullable=True)        # % of /data capacity used
    disk_inode_percent = Column(Float, nullable=True)  # % of /data inodes used
    disk_tps = Column(Float, nullable=True)            # I/O transactions per second
    disk_util = Column(Float, nullable=True)           # % of time the device was busy

    # CPU
    cpu_user = Column(Float, nullable=True)
    cpu_system = Column(Float, nullable=True)
    cpu_iowait = Column(Float, nullable=True)

    # Memory
    mem_free_percent = Column(Float, nullable=True)    # "available" memory as % of total
    mem_total_bytes = Column(Float, nullable=True)
    mem_available_bytes = Column(Float, nullable=True)

    # Flow processing / product metrics (all optional — they depend on the
    # device role and licensed components, e.g. a probe-only appliance has no
    # collector FPS and a device without ADS has no event counters).
    fps = Column(Float, nullable=True)                      # flows/s received by the collector
    udp_buffer_errors = Column(Float, nullable=True)        # cumulative UDP receive buffer errors
    ads_events = Column(Float, nullable=True)               # ADS events across the last 5 records
    data_lifetime_days = Column(Float, nullable=True)       # span of stored flow data, in days

    # Probe / exporter metrics (absent on collector-only devices)
    probe_pkt_per_sec = Column(Float, nullable=True)        # packets/s processed by the exporters
    probe_bytes_per_sec = Column(Float, nullable=True)
    probe_skipped_pkt_per_sec = Column(Float, nullable=True)  # packets/s skipped by the exporters
    # Cumulative kernel RX counters summed over the monitored interfaces
    iface_rx_packets = Column(Float, nullable=True)
    iface_rx_dropped = Column(Float, nullable=True)
    iface_rx_errors = Column(Float, nullable=True)

    __table_args__ = (
        Index("ix_device_perf_samples_device_id_collected_at", "device_id", "collected_at"),
    )


class DevicePerfInterfaceSample(Base):
    """Per-interface counters belonging to one performance sample.

    A probe can monitor several ports, so interface counters are kept as child
    rows rather than being summed into the parent sample. device_id and
    collected_at are denormalized so a time range can be queried without joining
    back to the parent.
    """
    __tablename__ = "device_perf_interface_samples"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    sample_id = Column(
        String, ForeignKey("device_perf_samples.id", ondelete="CASCADE"), nullable=False
    )
    device_id = Column(String, ForeignKey("devices.id", ondelete="CASCADE"), nullable=False)
    collected_at = Column(DateTime(timezone=True), nullable=False)

    name = Column(String, nullable=False)          # logical name, e.g. "net2"
    kernel_name = Column(String, nullable=True)    # kernel name, e.g. "ens224"
    # net0/net1 are always management ports on Flowmon; net2+ are monitoring.
    is_monitoring = Column(Integer, nullable=False, default=0)
    speed_mbps = Column(Float, nullable=True)
    licensed_speed_mbps = Column(Float, nullable=True)

    rx_bytes = Column(Float, nullable=True)
    rx_packets = Column(Float, nullable=True)
    rx_errors = Column(Float, nullable=True)
    rx_dropped = Column(Float, nullable=True)

    __table_args__ = (
        Index(
            "ix_device_perf_iface_device_id_collected_at", "device_id", "collected_at"
        ),
        Index("ix_device_perf_iface_sample_id", "sample_id"),
    )


class LocalCASecret(Base):
    """Encrypted private key material for locally-generated CAs."""
    __tablename__ = "local_ca_secrets"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    ca_id = Column(String, nullable=False, unique=True, index=True)
    ca_name = Column(String, nullable=False)
    private_key_enc = Column(Text, nullable=False)  # Fernet-encrypted PEM
    cert_pem = Column(Text, nullable=False)         # Public CA cert PEM used for signing
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class BackupPolicy(Base):
    """Global configuration for backup retention policies."""
    __tablename__ = "backup_policies"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    # Retention mode: "days" or "count"
    retention_mode = Column(String, nullable=False, default="days")
    # If retention_mode == "days": keep backups from the last N days
    # If retention_mode == "count": keep the last N backups per device
    retention_value = Column(Integer, nullable=False, default=7)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class Alert(Base):
    """Proactive alert generated by background evaluation."""
    __tablename__ = "alerts"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    alert_type = Column(String, nullable=False, index=True)  # device_unreachable | certificate_expiry
    severity = Column(String, nullable=False, default="warning")  # warning | critical
    status = Column(String, nullable=False, default="open")  # open | acknowledged | resolved
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    dedupe_key = Column(String, nullable=False, unique=True, index=True)
    device_id = Column(String, ForeignKey("devices.id", ondelete="SET NULL"), nullable=True, index=True)
    payload_json = Column(Text, nullable=True)
    first_seen_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    last_seen_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    resolved_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class NotificationChannel(Base):
    """Destination configuration for alert notifications."""
    __tablename__ = "notification_channels"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    channel_type = Column(String, nullable=False, default="webhook")  # webhook
    target = Column(String, nullable=False)  # URL for webhook
    message_format = Column(String, nullable=False, default="generic")  # generic | msteams_adaptive_card
    verify_ssl = Column(Integer, nullable=False, default=1)  # per-webhook TLS verify toggle
    enabled = Column(Integer, nullable=False, default=1)  # sqlite-safe bool
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class AlertNotification(Base):
    """Delivery attempts for alert notifications."""
    __tablename__ = "alert_notifications"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    alert_id = Column(String, ForeignKey("alerts.id", ondelete="CASCADE"), nullable=False, index=True)
    channel_id = Column(String, ForeignKey("notification_channels.id", ondelete="SET NULL"), nullable=True, index=True)
    channel_type = Column(String, nullable=False)
    target = Column(String, nullable=False)
    state = Column(String, nullable=False, default="pending")  # pending | sent | failed
    alert_status = Column(String, nullable=False, default="open")
    response_status = Column(Integer, nullable=True)
    error_message = Column(Text, nullable=True)
    sent_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class AlertRule(Base):
    """Configurable thresholds and enable flags per alert type."""
    __tablename__ = "alert_rules"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    alert_type = Column(String, nullable=False, unique=True, index=True)
    enabled = Column(Integer, nullable=False, default=1)
    warning_threshold = Column(Integer, nullable=True)
    critical_threshold = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class DevicePerfAlertRule(Base):
    """Per-device threshold overrides for performance metric alerting.

    A row only exists for a metric the user has customised on that device;
    everything else falls back to the built-in defaults in
    ``services.perf_alerts``. Thresholds are Float (unlike ``AlertRule``)
    because several metrics are rates that are meaningful below 1.
    """
    __tablename__ = "device_perf_alert_rules"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    device_id = Column(String, ForeignKey("devices.id", ondelete="CASCADE"), nullable=False)
    metric = Column(String, nullable=False)
    enabled = Column(Integer, nullable=False, default=1)
    # NULL means "inherit the shipped default" rather than "no threshold".
    warning_threshold = Column(Float, nullable=True)
    critical_threshold = Column(Float, nullable=True)
    # How many consecutive breaching samples are required before alerting.
    consecutive_samples = Column(Integer, nullable=False, default=3)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )

    __table_args__ = (
        UniqueConstraint("device_id", "metric", name="uq_device_perf_alert_rule"),
    )


class NotificationSetting(Base):
    """Global webhook delivery behavior controls."""
    __tablename__ = "notification_settings"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    cooldown_seconds = Column(Integer, nullable=False, default=1800)
    max_retries = Column(Integer, nullable=False, default=2)
    backoff_seconds = Column(Integer, nullable=False, default=5)
    muted_until = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


class AlertSnooze(Base):
    """Temporary suppression window for alerts by device/group and type."""
    __tablename__ = "alert_snoozes"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    device_id = Column(String, ForeignKey("devices.id", ondelete="CASCADE"), nullable=True, index=True)
    group_id = Column(String, ForeignKey("device_groups.id", ondelete="CASCADE"), nullable=True, index=True)
    alert_type = Column(String, nullable=True, index=True)  # null => all alert types
    muted_until = Column(DateTime(timezone=True), nullable=False, index=True)
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False,
    )


# ---------- Encryption helpers ----------

def _fernet() -> Fernet:
    from config import settings
    key = base64.urlsafe_b64encode(hashlib.sha256(settings.secret_key.encode()).digest())
    return Fernet(key)


def encrypt_password(plaintext: str) -> str:
    return _fernet().encrypt(plaintext.encode()).decode()


def decrypt_password(ciphertext: str) -> str:
    return _fernet().decrypt(ciphertext.encode()).decode()


# ---------- Password hashing (local user accounts) ----------

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except (ValueError, TypeError):
        return False


# ---------- DB helpers ----------

def create_tables() -> None:
    Base.metadata.create_all(bind=engine)
    _migrate_notification_channels_schema()
    with engine.begin() as conn:
        if not _column_exists(conn, "alert_notifications", "alert_status"):
            conn.execute(text(
                "ALTER TABLE alert_notifications "
                "ADD COLUMN alert_status VARCHAR NOT NULL DEFAULT 'open'"
            ))
    _migrate_devices_schema()
    _migrate_device_perf_samples_schema()
    with engine.begin() as conn:
        if not _column_exists(conn, "device_backups", "last_verified_at"):
            conn.execute(text("ALTER TABLE device_backups ADD COLUMN last_verified_at DATETIME"))
    _secure_database_file_permissions()


def _secure_database_file_permissions() -> None:
    """The SQLite file holds password hashes and encrypted credentials -
    make sure it is never world/group readable, regardless of the
    process umask that created it."""
    db_path = DATABASE_URL.removeprefix("sqlite:///")
    if not db_path or not os.path.isfile(db_path):
        return
    try:
        current_mode = stat.S_IMODE(os.stat(db_path).st_mode)
        if current_mode != 0o600:
            os.chmod(db_path, 0o600)
    except OSError:
        pass


def _column_exists(conn, table_name: str, column_name: str) -> bool:
    rows = conn.execute(text(f"PRAGMA table_info({table_name})")).fetchall()
    return any(row[1] == column_name for row in rows)


def _migrate_notification_channels_schema() -> None:
    with engine.begin() as conn:
        if not _column_exists(conn, "notification_channels", "message_format"):
            conn.execute(
                text(
                    "ALTER TABLE notification_channels "
                    "ADD COLUMN message_format VARCHAR NOT NULL DEFAULT 'generic'"
                )
            )
        if not _column_exists(conn, "notification_channels", "verify_ssl"):
            conn.execute(
                text(
                    "ALTER TABLE notification_channels "
                    "ADD COLUMN verify_ssl INTEGER NOT NULL DEFAULT 1"
                )
            )


def _migrate_devices_schema() -> None:
    with engine.begin() as conn:
        if not _column_exists(conn, "devices", "status_message"):
            conn.execute(text("ALTER TABLE devices ADD COLUMN status_message VARCHAR"))
        if not _column_exists(conn, "devices", "unreachable_check_failures"):
            conn.execute(text(
                "ALTER TABLE devices "
                "ADD COLUMN unreachable_check_failures INTEGER NOT NULL DEFAULT 0"
            ))
        if not _column_exists(conn, "devices", "verify_ssl"):
            conn.execute(
                text("ALTER TABLE devices ADD COLUMN verify_ssl INTEGER NOT NULL DEFAULT 0")
            )
        if not _column_exists(conn, "devices", "license_permanent"):
            conn.execute(text("ALTER TABLE devices ADD COLUMN license_permanent BOOLEAN"))
        if not _column_exists(conn, "devices", "ssh_port"):
            conn.execute(text("ALTER TABLE devices ADD COLUMN ssh_port INTEGER"))
        if not _column_exists(conn, "devices", "https_port"):
            conn.execute(text("ALTER TABLE devices ADD COLUMN https_port INTEGER"))


def _migrate_device_perf_samples_schema() -> None:
    """Add flow/product metric columns to pre-existing perf sample tables."""
    with engine.begin() as conn:
        for column in (
            "fps",
            "udp_buffer_errors",
            "ads_events",
            "data_lifetime_days",
            "probe_pkt_per_sec",
            "probe_bytes_per_sec",
            "probe_skipped_pkt_per_sec",
            "iface_rx_packets",
            "iface_rx_dropped",
            "iface_rx_errors",
        ):
            if not _column_exists(conn, "device_perf_samples", column):
                conn.execute(
                    text(f"ALTER TABLE device_perf_samples ADD COLUMN {column} FLOAT")
                )


def get_db():
    with Session(engine) as session:
        yield session


def ensure_default_admin() -> Optional[str]:
    """
    Create a default local admin account if no users exist yet.
    Returns the generated password (to be saved to an owner-only file), or None
    if an account already existed.
    """
    with Session(engine) as db:
        if db.query(User).count() > 0:
            return None
        password = secrets.token_urlsafe(12)
        db.add(
            User(
                username="admin",
                password_hash=hash_password(password),
                is_admin=1,
                disabled=0,
                must_change_password=1,
            )
        )
        db.commit()
        return password


def purge_expired_sessions(db: Session) -> None:
    db.query(DeviceSession).filter(
        DeviceSession.expires_at < datetime.now(timezone.utc)
    ).delete()
    db.commit()


def get_or_create_backup_policy(db: Session) -> BackupPolicy:
    """Get the global backup policy, creating a default one if it doesn't exist."""
    policy = db.query(BackupPolicy).first()
    if not policy:
        policy = BackupPolicy(retention_mode="days", retention_value=7)
        db.add(policy)
        db.commit()
        db.refresh(policy)
    return policy


def get_or_create_notification_settings(db: Session) -> NotificationSetting:
    settings_row = db.query(NotificationSetting).first()
    if not settings_row:
        settings_row = NotificationSetting(
            cooldown_seconds=1800,
            max_retries=2,
            backoff_seconds=5,
            muted_until=None,
        )
        db.add(settings_row)
        db.commit()
        db.refresh(settings_row)
    return settings_row


def get_or_create_alert_rules(db: Session) -> list[AlertRule]:
    defaults = [
        ("device_unreachable", 1, None, None),
        ("certificate_expiry", 1, 30, 7),
        ("backup_stale", 1, 26, 72),
        ("license_expiry", 1, 45, 14),
        ("support_expiry", 1, 45, 14),
        ("update_failure", 1, None, None),
        # Master switch for per-device performance thresholds. The actual
        # limits live in device_perf_alert_rules / services.perf_alerts, so
        # this row only carries the enable flag.
        ("perf_threshold", 1, None, None),
    ]

    existing = {r.alert_type: r for r in db.query(AlertRule).all()}
    changed = False
    for alert_type, enabled, warn, critical in defaults:
        if alert_type in existing:
            continue
        db.add(
            AlertRule(
                alert_type=alert_type,
                enabled=enabled,
                warning_threshold=warn,
                critical_threshold=critical,
            )
        )
        changed = True
    if changed:
        db.commit()
    return db.query(AlertRule).order_by(AlertRule.alert_type).all()
