"""Bootstrap a new Flowmon device over SSH ("Add device wizard").

Instead of requiring the admin to hand-create SSH/REST credential sets
before adding a device, the wizard takes the appliance's built-in
``flowmon`` SSH user credentials once, and:

1. Installs the device-manager's own SSH public key into that user's
   ``~/.ssh/authorized_keys`` (idempotent — safe to re-run).
2. Creates a dedicated local Flowmon OS user (``fm-user``, role ``admin``)
   via the appliance's own CLI, for REST API access.

The manager's SSH keypair and the ``fm-user`` password are each generated
once, lazily, the first time the wizard runs — mirroring how
``database.ensure_default_admin`` seeds the app's own admin account — and
are then reused for every device provisioned this way, so the resulting
SSH/REST credential sets can be shared across the whole fleet.
"""
from __future__ import annotations

import logging
import secrets
import socket
from typing import Callable, Optional

import paramiko
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from sqlalchemy.orm import Session

from database import (
    DeviceProvisioningConfig,
    RestCredential,
    SshCredential,
    decrypt_password,
    encrypt_password,
)
from services.ssh_utils import create_ssh_client
from services.support_bundle import _wait_for_command

logger = logging.getLogger(__name__)

FM_USER_LOGIN = "fm-user"
_FM_USER_CLI_CMD = (
    '/usr/bin/php /var/www/shtml/index.php Cli:AddUser '
    '-login="{login}" -pass="{password}" -name="Device" -surname="Manager" '
    '-email="device.manager@progress.com" -role="admin"'
)
_ALREADY_EXISTS_MARKERS = ("already exist", "duplicate", "unique constraint", "is already in use")

_SSH_CRED_NAME_TEMPLATE = "Auto-provisioned SSH key ({username})"
_REST_CRED_NAME = "Auto-provisioned fm-user"

PROVISIONING_TIMEOUT_SECONDS = 30
_CONFIG_ID = "default"


class ProvisioningError(Exception):
    """Raised for any failure during the SSH device-provisioning wizard."""


def _get_or_create_config(db: Session) -> DeviceProvisioningConfig:
    config = db.get(DeviceProvisioningConfig, _CONFIG_ID)
    if config is None:
        config = DeviceProvisioningConfig(id=_CONFIG_ID)
        db.add(config)
        db.commit()
        db.refresh(config)
    return config


def _ensure_manager_keypair(db: Session, config: DeviceProvisioningConfig) -> tuple[str, str]:
    """Return (public_key_line, private_key_pem), generating an Ed25519
    keypair the first time this is called.

    paramiko's ``Ed25519Key`` has no key-generation API of its own, so the
    keypair is generated with ``cryptography`` (already a dependency, used
    by the local CA feature) and serialized to OpenSSH format, which
    paramiko can load directly.
    """
    if config.manager_public_key and config.manager_private_key_enc:
        return config.manager_public_key, decrypt_password(config.manager_private_key_enc)

    private_key = Ed25519PrivateKey.generate()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.OpenSSH,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("ascii")
    public_openssh = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.OpenSSH,
        format=serialization.PublicFormat.OpenSSH,
    ).decode("ascii")
    public_line = f"{public_openssh} fdm-provisioning"

    config.manager_public_key = public_line
    config.manager_private_key_enc = encrypt_password(private_pem)
    db.commit()
    db.refresh(config)
    return public_line, private_pem


def _ensure_fm_user_password(db: Session, config: DeviceProvisioningConfig) -> str:
    if config.fm_user_password_enc:
        return decrypt_password(config.fm_user_password_enc)
    # token_urlsafe only ever emits [A-Za-z0-9_-], which is always safe to
    # embed in a double-quoted shell argument without further escaping.
    password = secrets.token_urlsafe(18)
    config.fm_user_password_enc = encrypt_password(password)
    db.commit()
    db.refresh(config)
    return password


def get_manager_public_key(db: Session) -> str:
    """Return the manager's SSH public key, generating the keypair if needed."""
    config = _get_or_create_config(db)
    public_key, _ = _ensure_manager_keypair(db, config)
    return public_key


def _run(client: paramiko.SSHClient, command: str) -> tuple[int, str, str]:
    _, stdout, _ = client.exec_command(command, timeout=PROVISIONING_TIMEOUT_SECONDS)
    stdout.channel.settimeout(PROVISIONING_TIMEOUT_SECONDS)
    exit_status, out_bytes, err_bytes = _wait_for_command(stdout.channel, PROVISIONING_TIMEOUT_SECONDS)
    return exit_status, out_bytes.decode("utf-8", errors="replace"), err_bytes.decode("utf-8", errors="replace")


def _install_authorized_key(client: paramiko.SSHClient, public_key_line: str) -> None:
    """Idempotently append the manager's public key to the bootstrap user's
    authorized_keys file, creating ~/.ssh with safe permissions if needed."""
    quoted = "'" + public_key_line.replace("'", "'\\''") + "'"
    command = (
        "mkdir -p ~/.ssh && chmod 700 ~/.ssh && touch ~/.ssh/authorized_keys "
        "&& chmod 600 ~/.ssh/authorized_keys && "
        f"(grep -qxF {quoted} ~/.ssh/authorized_keys || echo {quoted} >> ~/.ssh/authorized_keys)"
    )
    exit_status, out, err = _run(client, command)
    if exit_status != 0:
        raise ProvisioningError(
            f"Failed to install the manager's SSH key: {err.strip() or out.strip() or f'exit status {exit_status}'}"
        )


def _create_fm_user(client: paramiko.SSHClient, password: str) -> None:
    command = _FM_USER_CLI_CMD.format(login=FM_USER_LOGIN, password=password)
    exit_status, out, err = _run(client, command)
    if exit_status != 0:
        combined = f"{out}\n{err}".lower()
        if any(marker in combined for marker in _ALREADY_EXISTS_MARKERS):
            logger.info("fm-user already exists on device — continuing")
            return
        raise ProvisioningError(
            f"Failed to create the fm-user account: {err.strip() or out.strip() or f'exit status {exit_status}'}"
        )


def _get_or_create_ssh_credential(db: Session, username: str, port: int, private_key_pem: str) -> tuple[SshCredential, bool]:
    name = _SSH_CRED_NAME_TEMPLATE.format(username=username)
    cred = (
        db.query(SshCredential)
        .filter(SshCredential.name == name, SshCredential.auth_type == "key")
        .first()
    )
    if cred:
        return cred, False
    cred = SshCredential(
        name=name,
        username=username,
        port=port,
        auth_type="key",
        secret_enc=encrypt_password(private_key_pem),
    )
    db.add(cred)
    db.commit()
    db.refresh(cred)
    return cred, True


def _get_or_create_rest_credential(db: Session, password: str) -> tuple[RestCredential, bool]:
    cred = db.query(RestCredential).filter(RestCredential.name == _REST_CRED_NAME).first()
    if cred:
        return cred, False
    cred = RestCredential(
        name=_REST_CRED_NAME,
        username=FM_USER_LOGIN,
        password_enc=encrypt_password(password),
    )
    db.add(cred)
    db.commit()
    db.refresh(cred)
    return cred, True


def provision_device(
    *,
    db: Session,
    ip_address: str,
    ssh_port: int,
    bootstrap_username: str,
    bootstrap_password: str,
    audit: Optional[Callable[..., None]] = None,
) -> tuple[SshCredential, RestCredential]:
    """Bootstrap a device over SSH and return the (possibly reused) SSH and
    REST credential sets to attach to it.

    ``bootstrap_password`` is only ever used for this one connection — it is
    never stored. The manager's own SSH keypair and the shared fm-user
    password are generated on first use and persisted for reuse.
    """
    config = _get_or_create_config(db)
    public_key, private_key_pem = _ensure_manager_keypair(db, config)
    fm_password = _ensure_fm_user_password(db, config)

    client = create_ssh_client()
    try:
        try:
            client.connect(
                ip_address,
                port=ssh_port,
                username=bootstrap_username,
                password=bootstrap_password,
                timeout=10,
            )
        except paramiko.AuthenticationException as exc:
            raise ProvisioningError(
                "SSH authentication failed — check the flowmon user credentials"
            ) from exc
        except (socket.timeout, OSError, paramiko.SSHException) as exc:
            raise ProvisioningError(f"Could not connect over SSH: {exc}") from exc

        transport = client.get_transport()
        if transport:
            transport.set_keepalive(15)

        _install_authorized_key(client, public_key)
        _create_fm_user(client, fm_password)
    finally:
        client.close()

    ssh_cred, ssh_created = _get_or_create_ssh_credential(db, bootstrap_username, ssh_port, private_key_pem)
    if ssh_created and audit:
        audit("CRED_ADD", resource_type="ssh_credential", resource_name=ssh_cred.name)

    rest_cred, rest_created = _get_or_create_rest_credential(db, fm_password)
    if rest_created and audit:
        audit("CRED_ADD", resource_type="rest_credential", resource_name=rest_cred.name)

    return ssh_cred, rest_cred
