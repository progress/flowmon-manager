"""Collect and summarise the *important* log entries from a Flowmon device.

The existing device log browser exposes whole files; this module answers a
different question: "what is actually wrong with this box right now?".

It works entirely over SSH because the alternatives do not hold up on a real
appliance:

* ``/rest/messages/find`` returns the Flowmon UI's system messages, but on a
  healthy device that list is frequently empty (HTTP 204), so it cannot be the
  only source.
* ``journalctl`` is readable by the ``flowmon`` user but only for that user's
  own units — it shows ``flowmonexp`` and little else, and those entries are
  already covered by ``/var/log/flowmon/flowmonexp/*.log``. Reading the full
  journal needs root, which the appliance's sudo policy does not grant.

So the digest greps the component logs under ``/var/log/flowmon`` plus the
system log, keeps only warning-and-above lines, and groups near-identical
messages together. Grouping matters more than it sounds: a single stuck
component can emit the same warning thousands of times, which is exactly what
buries the one line that matters.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Iterable, Optional

if TYPE_CHECKING:  # pragma: no cover - typing only
    from database import Device, SshCredential

logger = logging.getLogger(__name__)


class LogDigestError(Exception):
    """Raised when the digest could not be collected from the device."""


# --------------------------------------------------------------------------
# Severity handling
# --------------------------------------------------------------------------

SEVERITY_RANK = {"warning": 1, "error": 2, "critical": 3}
SEVERITIES = ("critical", "error", "warning")

# Flowmon components use several logging stacks, so the same level shows up
# under different spellings ("WARNI" is Python's levelname truncated to 5).
_SEVERITY_ALIASES = {
    "EMERG": "critical",
    "ALERT": "critical",
    "FATAL": "critical",
    "CRITICAL": "critical",
    "CRIT": "critical",
    "SEVERE": "error",
    "ERROR": "error",
    "ERR": "error",
    "WARNING": "warning",
    "WARNI": "warning",
    "WARN": "warning",
}

# Longest-first so ERROR is not truncated to ERR, WARNING to WARN, etc.
_SEVERITY_RE = re.compile(
    r"(?<![A-Za-z])\[?"
    r"(CRITICAL|CRIT|EMERG|ALERT|FATAL|SEVERE|ERROR|ERR|WARNING|WARNI|WARN)"
    r"\]?(?![A-Za-z])"
)

# How far into a line a severity token is still considered a *field* rather
# than a word inside the message body.
_SEVERITY_SEARCH_WINDOW = 80

# The system log carries no severity field, so fall back to keywords. Ordered
# most severe first.
_SYSLOG_KEYWORDS: tuple[tuple[str, str], ...] = (
    ("critical", r"\b(?:panic|critical|fatal|emergency)\b"),
    ("error", r"\b(?:error|errors|failed|failure|denied|refused|cannot|unable)\b"),
    ("warning", r"\b(?:warn|warning)\b"),
)
_SYSLOG_KEYWORD_RES = tuple((sev, re.compile(pat, re.I)) for sev, pat in _SYSLOG_KEYWORDS)


# --------------------------------------------------------------------------
# Remote collection
# --------------------------------------------------------------------------

# Marker-delimited so one SSH round-trip collects every source. Only the tail
# of each file is read: these logs reach tens of megabytes and we only ever
# care about a recent window.
_COLLECT_SCRIPT = r"""
WINDOW_MIN=__WINDOW_MIN__
TAIL_BYTES=__TAIL_BYTES__
MAX_LINES=__MAX_LINES__
MAX_FILES=__MAX_FILES__
SEV='(CRITICAL|CRIT|EMERG|ALERT|FATAL|SEVERE|ERROR|ERR|WARNING|WARNI|WARN)'
echo "@@BEGIN"
for f in $(find /var/log/flowmon -type f -name '*.log' -readable -mmin -$WINDOW_MIN -size +0 2>/dev/null | head -n $MAX_FILES); do
  out=$(tail -c $TAIL_BYTES "$f" 2>/dev/null | grep -aE "(^|[^A-Za-z])$SEV([^A-Za-z]|$)" | tail -n $MAX_LINES)
  if [ -n "$out" ]; then
    echo "@@FILE $f"
    echo "$out"
  fi
done
if [ -r /var/log/messages ]; then
  out=$(tail -c $TAIL_BYTES /var/log/messages 2>/dev/null | grep -aiwE 'error|errors|failed|failure|critical|warning|warn|denied|refused|panic|fatal' | tail -n $MAX_LINES)
  if [ -n "$out" ]; then
    echo "@@FILE /var/log/messages"
    echo "$out"
  fi
fi
echo "@@END"
"""


def build_collect_script(
    window_minutes: int,
    tail_bytes: int = 512 * 1024,
    max_lines: int = 400,
    max_files: int = 80,
) -> str:
    """Render the remote collection script for a given time window."""
    return (
        _COLLECT_SCRIPT.replace("__WINDOW_MIN__", str(int(window_minutes)))
        .replace("__TAIL_BYTES__", str(int(tail_bytes)))
        .replace("__MAX_LINES__", str(int(max_lines)))
        .replace("__MAX_FILES__", str(int(max_files)))
    )


# --------------------------------------------------------------------------
# Line parsing
# --------------------------------------------------------------------------

# Flowmon components disagree on timestamp format; notably the Python-based
# services (arm, adam, utm, investigation) write day-first dates while the
# C++ ones (flowsen, flowmonexp) write ISO-like ones.
_TS_ISO = re.compile(
    r"^(?P<y>\d{4})-(?P<mo>\d{2})-(?P<d>\d{2})[ T](?P<h>\d{2}):(?P<mi>\d{2}):(?P<s>\d{2})(?:[.,](?P<frac>\d{1,6}))?"
)
_TS_DMY = re.compile(
    r"^(?P<d>\d{2})-(?P<mo>\d{2})-(?P<y>\d{4})[ T](?P<h>\d{2}):(?P<mi>\d{2}):(?P<s>\d{2})(?:[.,](?P<frac>\d{1,6}))?"
)
_TS_SYSLOG = re.compile(
    r"^(?P<mon>[A-Z][a-z]{2}) +(?P<d>\d{1,2}) (?P<h>\d{2}):(?P<mi>\d{2}):(?P<s>\d{2})"
)

_MONTHS = {
    m: i + 1
    for i, m in enumerate(
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    )
}

# `host program[pid]: message`
_SYSLOG_BODY = re.compile(r"^(?P<host>\S+)\s+(?P<prog>[^\s:\[]+)(?:\[(?P<pid>\d+)\])?:\s*(?P<msg>.*)$")

# Correlation markers such as `[@mmcommons-64da6d@]` add no information and
# differ per process, which would otherwise split identical messages apart.
_CORRELATION_RE = re.compile(r"\[@[^\]]*@\]")

# flowmonexp collapses repeats itself and reports them as a `(151x)` suffix.
_REPEAT_SUFFIX_RE = re.compile(r"\s*\((\d+)x\)\s*$")

# Structural prefixes left over once the timestamp and severity are removed:
# pids, thread ids, `(SourceFile:123 )`, `module:123:function`, `[context]`.
_PREFIX_PATTERNS = (
    re.compile(r"^\((?:[^()]*)\)\s*"),
    re.compile(r"^\[[^\[\]]*\]\s*"),
    re.compile(r"^[\w.]+:\d+\s*:\s*\S+\s+"),
    re.compile(r"^[\w.]+:\d+\s+"),
    re.compile(r"^\d+\s+"),
    # A lone component name used as a separator, e.g. `ProcessCon - ...`.
    re.compile(r"^[\w.]+\s+-\s+"),
    re.compile(r"^-\s+"),
)


@dataclass
class LogEntry:
    """A single parsed log line."""

    timestamp: Optional[datetime]
    severity: str
    source: str
    file: str
    message: str
    raw: str
    occurrences: int = 1


@dataclass
class LogGroup:
    """Near-identical entries collapsed into one row."""

    severity: str
    message: str
    signature: str
    sources: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    count: int = 0
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    samples: list[str] = field(default_factory=list)


def source_from_path(path: str) -> str:
    """Component name for a log path, e.g. /var/log/flowmon/arm/arm.log -> arm."""
    prefix = "/var/log/flowmon/"
    if path.startswith(prefix):
        rest = path[len(prefix):]
        head = rest.split("/", 1)[0]
        return head or "flowmon"
    if path == "/var/log/messages":
        return "system"
    return path.rsplit("/", 1)[-1].removesuffix(".log") or path


def _infer_year(month: int, day: int, now: datetime) -> int:
    """Syslog omits the year; assume the most recent occurrence, not the future."""
    year = now.year
    try:
        candidate = datetime(year, month, day, tzinfo=timezone.utc)
    except ValueError:  # Feb 29 in a non-leap year
        return year
    # Allow a day of slack for clock skew between manager and device.
    if candidate > now + timedelta(days=1):
        return year - 1
    return year


def parse_timestamp(line: str, now: Optional[datetime] = None) -> tuple[Optional[datetime], str]:
    """Split a leading timestamp off a log line.

    Returns ``(timestamp, remainder)``; the timestamp is ``None`` when the line
    does not start with a recognised format.
    """
    now = now or datetime.now(timezone.utc)

    for pattern, day_first in ((_TS_ISO, False), (_TS_DMY, True)):
        match = pattern.match(line)
        if not match:
            continue
        parts = match.groupdict()
        frac = parts.get("frac") or "0"
        try:
            ts = datetime(
                int(parts["y"]),
                int(parts["mo"]),
                int(parts["d"]),
                int(parts["h"]),
                int(parts["mi"]),
                int(parts["s"]),
                int(frac.ljust(6, "0")[:6]),
                tzinfo=timezone.utc,
            )
        except ValueError:
            # A day-first pattern can still hold an impossible date if the log
            # actually used month-first; treat it as unparseable rather than
            # inventing a wrong timestamp.
            logger.debug("Unparseable %s timestamp: %r", "DMY" if day_first else "ISO", line[:40])
            return None, line
        return ts, line[match.end():].lstrip()

    match = _TS_SYSLOG.match(line)
    if match:
        parts = match.groupdict()
        month = _MONTHS.get(parts["mon"])
        if month is not None:
            day = int(parts["d"])
            try:
                ts = datetime(
                    _infer_year(month, day, now),
                    month,
                    day,
                    int(parts["h"]),
                    int(parts["mi"]),
                    int(parts["s"]),
                    tzinfo=timezone.utc,
                )
            except ValueError:
                return None, line
            return ts, line[match.end():].lstrip()

    return None, line


def extract_severity(remainder: str) -> tuple[Optional[str], str]:
    """Find the severity *field* near the start of a line and return the tail.

    Every Flowmon logging stack puts the severity after its structural prefix
    (pid, logger name, thread) and before the message, so everything preceding
    the token is noise and only the tail is kept.

    The search is limited to the first few dozen characters so that a message
    merely mentioning "error" is not misread as an error-level entry.
    """
    match = _SEVERITY_RE.search(remainder[:_SEVERITY_SEARCH_WINDOW])
    if not match:
        return None, remainder
    severity = _SEVERITY_ALIASES.get(match.group(1).upper())
    if severity is None:  # pragma: no cover - alias table covers the regex
        return None, remainder
    return severity, remainder[match.end():].lstrip()


def _severity_from_keywords(text: str) -> Optional[str]:
    for severity, pattern in _SYSLOG_KEYWORD_RES:
        if pattern.search(text):
            return severity
    return None


def clean_message(text: str) -> str:
    """Strip structural noise so equivalent messages compare equal."""
    text = _CORRELATION_RE.sub(" ", text)
    text = text.strip()
    # Peel leading structural fields, but stop as soon as nothing matches so a
    # message legitimately starting with a bracket is not eaten away. A strip
    # that would consume the whole line is rejected: the remainder is all we
    # have, so keeping it verbatim beats dropping the entry.
    changed = True
    while changed and text:
        changed = False
        for pattern in _PREFIX_PATTERNS:
            new = pattern.sub("", text, count=1)
            if new != text and new.strip():
                text = new
                changed = True
    return re.sub(r"\s+", " ", text).strip()


def signature_for(message: str) -> str:
    """Collapse variable parts of a message so repeats group together."""
    text = message.lower()
    text = re.sub(r"\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\b", "<mac>", text)
    text = re.sub(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", "<ip>", text)
    text = re.sub(r"0x[0-9a-f]+", "<hex>", text)
    text = re.sub(r"\b[0-9a-f]{8,}\b", "<id>", text)
    text = re.sub(r"\d+", "<n>", text)
    return re.sub(r"\s+", " ", text).strip()


def parse_line(line: str, path: str, now: Optional[datetime] = None) -> Optional[LogEntry]:
    """Turn one raw log line into a :class:`LogEntry`, or ``None`` if it is not
    a warning-or-worse entry we can make sense of."""
    line = line.rstrip("\n").rstrip("\r")
    if not line.strip():
        return None

    source = source_from_path(path)
    timestamp, remainder = parse_timestamp(line, now=now)

    if source == "system":
        # syslog has no severity field: derive it from the message body, and
        # peel off `host program[pid]:` first so the hostname cannot match.
        body = remainder
        match = _SYSLOG_BODY.match(remainder)
        program = None
        if match:
            program = match.group("prog")
            body = match.group("msg")
        severity = _severity_from_keywords(body)
        if severity is None:
            return None
        message = clean_message(body)
        if program:
            source = program
    else:
        severity, remainder = extract_severity(remainder)
        if severity is None:
            return None
        message = clean_message(remainder)

    if not message:
        return None

    occurrences = 1
    repeat = _REPEAT_SUFFIX_RE.search(message)
    if repeat:
        # flowmonexp already collapsed identical lines; honour its own count so
        # the digest reflects real volume.
        occurrences = max(1, int(repeat.group(1)))
        message = _REPEAT_SUFFIX_RE.sub("", message).strip()

    return LogEntry(
        timestamp=timestamp,
        severity=severity,
        source=source,
        file=path,
        message=message,
        raw=line.strip(),
        occurrences=occurrences,
    )


def parse_collect_output(output: str, now: Optional[datetime] = None) -> list[LogEntry]:
    """Parse the marker-delimited output of :data:`_COLLECT_SCRIPT`."""
    entries: list[LogEntry] = []
    current: Optional[str] = None
    for line in output.splitlines():
        if line.startswith("@@FILE "):
            current = line[len("@@FILE "):].strip()
            continue
        if line.startswith("@@"):
            continue
        if current is None:
            continue
        entry = parse_line(line, current, now=now)
        if entry is not None:
            entries.append(entry)
    return entries


# --------------------------------------------------------------------------
# Grouping
# --------------------------------------------------------------------------

def group_entries(
    entries: Iterable[LogEntry],
    min_severity: str = "warning",
    since: Optional[datetime] = None,
    max_samples: int = 3,
) -> list[LogGroup]:
    """Collapse entries into groups sorted by severity, then recency.

    Entries without a parseable timestamp are kept — dropping them would hide
    multi-line tracebacks' continuation lines and any format we have not seen
    yet — but they cannot be filtered by ``since``.
    """
    floor = SEVERITY_RANK.get(min_severity, 1)
    groups: dict[tuple[str, str], LogGroup] = {}

    for entry in entries:
        if SEVERITY_RANK.get(entry.severity, 0) < floor:
            continue
        if since is not None and entry.timestamp is not None and entry.timestamp < since:
            continue

        signature = signature_for(entry.message)
        key = (entry.severity, signature)
        group = groups.get(key)
        if group is None:
            group = LogGroup(severity=entry.severity, message=entry.message, signature=signature)
            groups[key] = group

        group.count += entry.occurrences
        if entry.source not in group.sources:
            group.sources.append(entry.source)
        if entry.file not in group.files:
            group.files.append(entry.file)
        if len(group.samples) < max_samples:
            group.samples.append(entry.raw)
        if entry.timestamp is not None:
            if group.first_seen is None or entry.timestamp < group.first_seen:
                group.first_seen = entry.timestamp
            if group.last_seen is None or entry.timestamp > group.last_seen:
                group.last_seen = entry.timestamp
                # Show the most recent wording of a message that varies.
                group.message = entry.message

    ordered = sorted(
        groups.values(),
        key=lambda g: (
            -SEVERITY_RANK.get(g.severity, 0),
            -(g.last_seen.timestamp() if g.last_seen else 0),
            -g.count,
        ),
    )
    return ordered


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def collect_device_log_digest(
    device: "Device",
    cred: "SshCredential",
    window_minutes: int = 1440,
    timeout: int = 60,
) -> list[LogEntry]:
    """SSH into the device, grep its logs, and return the parsed entries."""
    from services.ssh_utils import open_ssh_connection

    script = build_collect_script(window_minutes)
    client = None
    stdin = stdout = stderr = None
    try:
        client = open_ssh_connection(device, cred)
        stdin, stdout, stderr = client.exec_command(script, timeout=timeout)
        output = stdout.read().decode(errors="replace")
        err = stderr.read().decode(errors="replace").strip()
    except Exception as exc:
        raise LogDigestError(f"SSH log collection failed: {exc}") from exc
    finally:
        # Close channel streams before the transport so paramiko does not emit
        # noise from __del__ during garbage collection.
        for stream in (stdin, stdout, stderr):
            if stream is not None:
                try:
                    stream.close()
                except Exception:  # pragma: no cover - best-effort cleanup
                    pass
        if client is not None:
            try:
                client.close()
            except Exception:  # pragma: no cover - best-effort cleanup
                pass

    if "@@END" not in output:
        raise LogDigestError(f"Log collection failed on device: {err or 'no output'}")

    return parse_collect_output(output)
