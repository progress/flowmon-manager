"""Collect performance statistics from a Flowmon device over SSH.

Modelled on the Flowmon `perfmon.sh` community script
(https://github.com/progress/Flowmon-Various-Scripts/tree/main/perfmon), with
some deliberate differences:

* The data disk is resolved dynamically instead of assuming ``sda`` — on most
  appliances ``/data`` actually lives on a second disk (e.g. ``sdb``).
* ``iostat`` is sampled over a live 1-second interval and the *second* report is
  used. The original script reads the first report, which is an average since
  boot and therefore flat/meaningless when plotted over time.
* Several of the script's sources no longer exist on Flowmon OS 13, so current
  equivalents are used: collector FPS comes from the flowsen stats log rather
  than ``nfcapd.log``, UDP receive buffer errors are read from ``/proc/net/snmp``
  because ``netstat`` is no longer installed, and the stored-data lifetime is
  derived from the date-partitioned flow directories rather than ``profile.dat``.
* No state is written to the managed device. The script keeps counter deltas in
  files under ``/home/flowmon/perfmon``; here the cumulative UDP error counter is
  stored as-is and the delta is derived when the history is served.
* Logs are read via ``tail`` rather than grepped end to end — these files reach
  several megabytes and are sampled every few minutes.

Every flow/product metric is optional: probes have no collector FPS, devices
without ADS have no event counts, and so on. Missing values are reported as
``None`` rather than failing the whole sample.
"""
from __future__ import annotations

import logging
import re
from dataclasses import asdict, dataclass, field
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:  # pragma: no cover - typing only
    from database import Device, SshCredential

logger = logging.getLogger(__name__)

# Marker-delimited so a single SSH round-trip collects everything.
_COLLECT_SCRIPT = r"""
TARGET=/data
[ -d "$TARGET" ] || TARGET=/
SRC=$(df -P "$TARGET" | tail -1 | awk '{print $1}')
DISK=$(lsblk -no pkname "$SRC" 2>/dev/null | grep -v '^$' | head -1)
if [ -z "$DISK" ]; then
  DISK=$(basename "$SRC" | sed 's/[0-9]*$//')
fi
echo "@@DISK"
echo "$DISK"
echo "@@DF"
df -P "$TARGET" | tail -1
echo "@@DFI"
df -iP "$TARGET" | tail -1
echo "@@MEM"
free -b | grep -i '^Mem:'
echo "@@IOSTAT"
iostat -dxc 1 2
echo "@@FPS"
for f in /var/log/flowmon/flowsen/flowsen/Stats.log /var/log/flowmon/flowsen/flowsen/all.log; do
  if [ -r "$f" ]; then
    LINE=$(tail -n 2000 "$f" 2>/dev/null | grep 'InputNetwork' | grep -v 'Templates\]' | tail -1)
    if [ -n "$LINE" ]; then echo "$LINE"; break; fi
  fi
done
echo "@@UDP"
grep '^Udp:' /proc/net/snmp 2>/dev/null
echo "@@ADSEPS"
tail -n 2000 /data/components/ads-psql/log/ads-output.log 2>/dev/null \
  | grep 'Event queue size: ' | tail -5
echo "@@FLOWDAYS"
if [ -d /data/flows ]; then
  find /data/flows -maxdepth 6 -type d 2>/dev/null \
    | grep -oE '[0-9]{4}/[0-9]{2}/[0-9]{2}$' | sort -u | sed -n '1p;$p'
fi
echo "@@EXPSTATS"
for f in $(find /var/log/flowmon/flowmonexp -name 'flowmonexp_*.log' -mmin -60 2>/dev/null); do
  LINE=$(tail -n 2000 "$f" 2>/dev/null | grep 'Traffic statistics' | tail -1)
  [ -n "$LINE" ] && echo "$LINE"
done
echo "@@IFACE"
for KIF in $(ls /sys/class/net 2>/dev/null); do
  [ "$KIF" = "lo" ] && continue
  ALT=$(ip -o link show "$KIF" 2>/dev/null | grep -oE 'altname [A-Za-z0-9_.-]+' | head -1 | awk '{print $2}')
  NAME="${ALT:-$KIF}"
  SPEED=$(cat "/sys/class/net/$KIF/speed" 2>/dev/null)
  case "$SPEED" in ''|*[!0-9]*) SPEED='-' ;; esac
  STATS=$(grep -E "^[[:space:]]*$KIF:" /proc/net/dev 2>/dev/null | head -1 | sed 's/.*://')
  [ -n "$STATS" ] && echo "$NAME $KIF $SPEED $STATS"
done
echo "@@LICIFACE"
grep -aoE '(eth|net)[0-9]+ \([0-9]+\)' /etc/flowmon/license 2>/dev/null | sort -u
echo "@@END"
"""


@dataclass
class InterfaceSample:
    """Counters for a single network interface at a point in time."""

    name: str                      # logical Flowmon name, e.g. "net2"
    kernel_name: str               # kernel name, e.g. "ens224"
    is_monitoring: bool            # False for the management ports (net0/net1)
    speed_mbps: Optional[float] = None      # link speed reported by the kernel
    licensed_speed_mbps: Optional[float] = None  # speed the license permits
    rx_bytes: Optional[float] = None
    rx_packets: Optional[float] = None
    rx_errors: Optional[float] = None
    rx_dropped: Optional[float] = None

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class PerfSample:
    disk_percent: Optional[float] = None
    disk_inode_percent: Optional[float] = None
    disk_tps: Optional[float] = None
    disk_util: Optional[float] = None
    cpu_user: Optional[float] = None
    cpu_system: Optional[float] = None
    cpu_iowait: Optional[float] = None
    mem_free_percent: Optional[float] = None
    mem_total_bytes: Optional[float] = None
    mem_available_bytes: Optional[float] = None
    fps: Optional[float] = None
    udp_buffer_errors: Optional[float] = None
    ads_events: Optional[float] = None
    data_lifetime_days: Optional[float] = None
    # Probe / exporter metrics — only present on devices that capture traffic.
    probe_pkt_per_sec: Optional[float] = None
    probe_bytes_per_sec: Optional[float] = None
    probe_skipped_pkt_per_sec: Optional[float] = None
    # Cumulative kernel counters, summed over the monitored interfaces.
    iface_rx_packets: Optional[float] = None
    iface_rx_dropped: Optional[float] = None
    iface_rx_errors: Optional[float] = None

    # Per-interface breakdown. Not a database column on the sample itself —
    # these are stored as child rows.
    interfaces: list["InterfaceSample"] = field(default_factory=list)

    def as_dict(self) -> dict:
        """Scalar columns only, for direct assignment onto the ORM model."""
        data = asdict(self)
        data.pop("interfaces", None)
        return data

    def is_empty(self) -> bool:
        return all(v is None for v in self.as_dict().values()) and not self.interfaces


class PerfCollectionError(Exception):
    pass


def _to_float(value: str) -> Optional[float]:
    try:
        return float(value.replace("%", "").replace(",", "."))
    except (ValueError, AttributeError):
        return None


def _split_sections(output: str) -> dict[str, list[str]]:
    sections: dict[str, list[str]] = {}
    current: Optional[str] = None
    for line in output.splitlines():
        stripped = line.strip()
        if stripped.startswith("@@"):
            current = stripped[2:]
            sections[current] = []
            continue
        if current is not None:
            sections[current].append(line)
    return sections


def _parse_percent_from_df(lines: list[str]) -> Optional[float]:
    """df -P output: Filesystem 1024-blocks Used Available Capacity Mounted-on."""
    for line in lines:
        parts = line.split()
        if len(parts) >= 5:
            return _to_float(parts[4])
    return None


def _parse_mem(lines: list[str]) -> tuple[Optional[float], Optional[float], Optional[float]]:
    """free -b: Mem: total used free shared buff/cache available.

    Older `free` builds omit the trailing "available" column, in which case we
    fall back to the plain "free" column.
    """
    for line in lines:
        parts = line.split()
        if len(parts) >= 4 and parts[0].lower().startswith("mem"):
            total = _to_float(parts[1])
            available = _to_float(parts[6]) if len(parts) >= 7 else _to_float(parts[3])
            if total and available is not None and total > 0:
                return round(available / total * 100.0, 2), total, available
            return None, total, available
    return None, None, None


def _parse_iostat(lines: list[str], disk: str) -> tuple[
    Optional[float], Optional[float], Optional[float], Optional[float], Optional[float]
]:
    """Parse `iostat -dxc 1 2`, using the last (live-interval) report.

    Returns (cpu_user, cpu_system, cpu_iowait, disk_tps, disk_util).
    """
    cpu_user = cpu_system = cpu_iowait = None
    disk_tps = disk_util = None

    header: list[str] = []
    expect_cpu_values = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        if stripped.startswith("avg-cpu:"):
            expect_cpu_values = True
            continue

        if expect_cpu_values:
            values = [_to_float(v) for v in stripped.split()]
            # %user %nice %system %iowait %steal %idle — later reports overwrite
            # earlier ones so we end up with the live interval sample.
            if len(values) >= 4:
                cpu_user, cpu_system, cpu_iowait = values[0], values[2], values[3]
            expect_cpu_values = False
            continue

        if stripped.startswith("Device"):
            header = stripped.split()
            continue

        parts = stripped.split()
        if not header or parts[0] != disk:
            continue

        row = dict(zip(header, parts))
        disk_util = _to_float(row.get("%util", ""))
        # sysstat's extended output has no tps column; it is the sum of the
        # read, write and discard request rates.
        rates = [_to_float(row.get(key, "")) for key in ("r/s", "w/s", "d/s")]
        present = [r for r in rates if r is not None]
        if present:
            disk_tps = round(sum(present), 2)

    return cpu_user, cpu_system, cpu_iowait, disk_tps, disk_util


_FPS_RE = re.compile(r"\bfps=(\d+)")
_ADS_EVENTS_RE = re.compile(r"#(\d+)\s*$")


def _parse_fps(lines: list[str]) -> Optional[float]:
    """Flows per second from the flowsen collector stats line.

    The value is logged as ``fps=<current>/<total-since-start>``; only the
    current rate is of interest. On Flowmon OS 13 the nfcapd-era log used by the
    original script no longer exists, so this reads the flowsen stats log.
    """
    for line in reversed(lines):
        match = _FPS_RE.search(line)
        if match:
            return float(match.group(1))
    return None


def _parse_udp_errors(lines: list[str]) -> Optional[float]:
    """UDP receive buffer errors from /proc/net/snmp.

    This is the same counter that ``netstat -su`` reports as "receive buffer
    errors"; netstat is no longer installed on Flowmon OS 13. The value is
    cumulative since boot — the per-interval delta is derived when serving.
    """
    header: list[str] = []
    for line in lines:
        parts = line.split()
        if not parts or parts[0] != "Udp:":
            continue
        if not header:
            header = parts
            continue
        row = dict(zip(header, parts))
        return _to_float(row.get("RcvbufErrors", ""))
    return None


def _parse_ads_events(lines: list[str]) -> Optional[float]:
    """Sum the trailing ``#<n>`` event counts of the last ADS output records."""
    values = [
        float(match.group(1))
        for match in (_ADS_EVENTS_RE.search(line.strip()) for line in lines)
        if match
    ]
    return sum(values) if values else None


def _parse_data_lifetime(lines: list[str]) -> Optional[float]:
    """Span in days between the oldest and newest stored flow-data day.

    The original script derived this from ``profile.dat`` under
    ``/data/nfsen/profiles-stat``, which no longer exists on Flowmon OS 13; the
    date-partitioned flow storage directories are used instead.
    """
    from datetime import date

    days: list[date] = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        try:
            year, month, day = (int(p) for p in stripped.split("/"))
            days.append(date(year, month, day))
        except (ValueError, TypeError):
            continue
    if not days:
        return None
    return float((max(days) - min(days)).days)


_TRAFFIC_STATS_RE = re.compile(
    r"Traffic statistics:\s*(\d+)\s*pkt/s,\s*(\d+)\s*bytes/s,\s*(\d+)\s*flows/s,"
    r"\s*(\d+)\s*skipped pkt/s"
)


def _parse_exporter_stats(
    lines: list[str],
) -> tuple[Optional[float], Optional[float], Optional[float]]:
    """Packet/byte/skipped rates reported by the flow exporters.

    One line per running exporter; the rates are summed so a probe with several
    monitoring ports reports its total input rate. Returns
    (pkt_per_sec, bytes_per_sec, skipped_pkt_per_sec).
    """
    packets = byte_rate = skipped = None
    for line in lines:
        match = _TRAFFIC_STATS_RE.search(line)
        if not match:
            continue
        packets = (packets or 0.0) + float(match.group(1))
        byte_rate = (byte_rate or 0.0) + float(match.group(2))
        skipped = (skipped or 0.0) + float(match.group(4))
    return packets, byte_rate, skipped


_IFACE_INDEX_RE = re.compile(r"^(?:net|eth)(\d+)$")
_LICENSE_IFACE_RE = re.compile(r"^(?:eth|net)(\d+) \((\d+)\)$")

# On Flowmon appliances net0 and net1 are always management ports; every
# higher-numbered interface is a monitoring (capture) port.
FIRST_MONITORING_INDEX = 2


def _interface_index(name: str) -> Optional[int]:
    match = _IFACE_INDEX_RE.match(name)
    return int(match.group(1)) if match else None


def _parse_licensed_interfaces(lines: list[str]) -> dict[int, float]:
    """Licensed monitoring ports from the license file, keyed by index.

    The license lists them as ``eth2 (1000) eth3 (1000)`` — ``ethN`` there is the
    same port as ``netN`` on the running system, and the number in parentheses is
    the licensed speed in Mbps.
    """
    licensed: dict[int, float] = {}
    for line in lines:
        for token in re.findall(r"(?:eth|net)[0-9]+ \([0-9]+\)", line):
            match = _LICENSE_IFACE_RE.match(token)
            if match:
                licensed[int(match.group(1))] = float(match.group(2))
    return licensed


def _parse_interfaces(
    lines: list[str], licensed: dict[int, float]
) -> list[InterfaceSample]:
    """Per-interface counters.

    Each line is ``<logical> <kernel> <speed> <rx_bytes> <rx_packets> <rx_errs>
    <rx_drop> ...``, the trailing fields coming straight from /proc/net/dev.
    """
    interfaces: list[InterfaceSample] = []
    for line in lines:
        parts = line.split()
        if len(parts) < 7:
            continue
        name, kernel_name, raw_speed = parts[0], parts[1], parts[2]
        counters = [_to_float(p) for p in parts[3:7]]
        if any(v is None for v in counters):
            continue
        rx_bytes, rx_packets, rx_errors, rx_dropped = counters

        index = _interface_index(name)
        # A negative kernel speed means "unknown" (e.g. link down).
        speed = _to_float(raw_speed)
        if speed is not None and speed < 0:
            speed = None

        interfaces.append(
            InterfaceSample(
                name=name,
                kernel_name=kernel_name,
                is_monitoring=index is not None and index >= FIRST_MONITORING_INDEX,
                speed_mbps=speed,
                licensed_speed_mbps=licensed.get(index) if index is not None else None,
                rx_bytes=rx_bytes,
                rx_packets=rx_packets,
                rx_errors=rx_errors,
                # Kernel drops are not exporter loss, especially on VMs.
                rx_dropped=None,
            )
        )
    interfaces.sort(key=lambda i: (_interface_index(i.name) is None, _interface_index(i.name) or 0, i.name))
    return interfaces


def _aggregate_monitoring(
    interfaces: list[InterfaceSample],
) -> tuple[Optional[float], Optional[float], Optional[float]]:
    """Sum RX counters over the monitoring ports only.

    Management ports are excluded — their traffic is unrelated to capture, and
    counting their drops would misrepresent packet loss.
    """
    monitoring = [i for i in interfaces if i.is_monitoring]
    if not monitoring:
        return None, None, None

    def total(attr: str) -> Optional[float]:
        values = [getattr(i, attr) for i in monitoring if getattr(i, attr) is not None]
        return sum(values) if values else None

    return total("rx_packets"), total("rx_dropped"), total("rx_errors")


def parse_perf_output(output: str) -> PerfSample:
    sections = _split_sections(output)
    if "END" not in sections:
        raise PerfCollectionError("Incomplete performance output from device")

    disk_lines = sections.get("DISK", [])
    disk = next((l.strip() for l in disk_lines if l.strip()), "")

    cpu_user, cpu_system, cpu_iowait, disk_tps, disk_util = _parse_iostat(
        sections.get("IOSTAT", []), disk
    )
    mem_free_percent, mem_total, mem_available = _parse_mem(sections.get("MEM", []))
    exporter_pkts, exporter_bytes, exporter_skipped = _parse_exporter_stats(
        sections.get("EXPSTATS", [])
    )
    interfaces = _parse_interfaces(
        sections.get("IFACE", []),
        _parse_licensed_interfaces(sections.get("LICIFACE", [])),
    )
    iface_packets, iface_dropped, iface_errors = _aggregate_monitoring(interfaces)

    return PerfSample(
        disk_percent=_parse_percent_from_df(sections.get("DF", [])),
        disk_inode_percent=_parse_percent_from_df(sections.get("DFI", [])),
        disk_tps=disk_tps,
        disk_util=disk_util,
        cpu_user=cpu_user,
        cpu_system=cpu_system,
        cpu_iowait=cpu_iowait,
        mem_free_percent=mem_free_percent,
        mem_total_bytes=mem_total,
        mem_available_bytes=mem_available,
        fps=_parse_fps(sections.get("FPS", [])),
        udp_buffer_errors=_parse_udp_errors(sections.get("UDP", [])),
        ads_events=_parse_ads_events(sections.get("ADSEPS", [])),
        data_lifetime_days=_parse_data_lifetime(sections.get("FLOWDAYS", [])),
        probe_pkt_per_sec=exporter_pkts,
        probe_bytes_per_sec=exporter_bytes,
        probe_skipped_pkt_per_sec=exporter_skipped,
        iface_rx_packets=iface_packets,
        iface_rx_dropped=iface_dropped,
        iface_rx_errors=iface_errors,
        interfaces=interfaces,
    )


def collect_device_perf(device: "Device", cred: "SshCredential") -> PerfSample:
    """SSH into the device, sample performance counters, and return them."""
    from services.ssh_utils import open_ssh_connection

    client = None
    stdin = stdout = stderr = None
    try:
        client = open_ssh_connection(device, cred)
        # iostat samples for 1s; allow generous headroom for slow appliances.
        stdin, stdout, stderr = client.exec_command(_COLLECT_SCRIPT, timeout=45)
        output = stdout.read().decode(errors="replace")
        err = stderr.read().decode(errors="replace").strip()
    except PerfCollectionError:
        raise
    except Exception as exc:
        raise PerfCollectionError(f"SSH collection failed: {exc}") from exc
    finally:
        # Close the channel streams before the transport so paramiko does not
        # emit noisy errors from __del__ during garbage collection. stdin counts
        # too, even though it is never written to.
        for stream in (stdin, stdout, stderr):
            if stream is not None:
                try:
                    stream.close()
                except Exception:  # pragma: no cover - best-effort cleanup
                    pass
        if client is not None:
            try:
                client.close()
            except Exception:  # pragma: no cover - best-effort cleanup
                pass

    if "@@END" not in output:
        detail = err or "no output"
        raise PerfCollectionError(f"Performance collection failed on device: {detail}")

    sample = parse_perf_output(output)
    if sample.is_empty():
        raise PerfCollectionError(
            "Could not parse any performance counters from the device "
            "(is the `sysstat`/iostat package installed?)"
        )
    return sample
