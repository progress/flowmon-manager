from __future__ import annotations

import socket
from ipaddress import ip_address
from urllib.parse import urlparse


class WebhookTargetValidationError(ValueError):
    pass


def _is_public_ip(raw_ip: str) -> bool:
    ip = ip_address(raw_ip.split("%", 1)[0])
    return not (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    )


def validate_webhook_target(target: str) -> str:
    normalized = target.strip()
    if not normalized:
        raise WebhookTargetValidationError("Webhook target is required")

    parsed = urlparse(normalized)
    if parsed.scheme.lower() != "https":
        raise WebhookTargetValidationError("Webhook target must use https://")
    if parsed.username or parsed.password:
        raise WebhookTargetValidationError("Webhook target must not include credentials")

    host = parsed.hostname
    if not host:
        raise WebhookTargetValidationError("Webhook target must include a valid hostname")
    if host.lower() == "localhost":
        raise WebhookTargetValidationError("Webhook target cannot use localhost")

    try:
        resolved = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise WebhookTargetValidationError(f"Webhook target host could not be resolved: {host}") from exc

    resolved_ips = {entry[4][0] for entry in resolved if entry and entry[4]}
    if not resolved_ips:
        raise WebhookTargetValidationError(f"Webhook target host could not be resolved: {host}")

    for resolved_ip in resolved_ips:
        if not _is_public_ip(resolved_ip):
            raise WebhookTargetValidationError("Webhook target resolves to non-public address space")

    return normalized


def is_msteams_webhook_target(target: str) -> bool:
    parsed = urlparse(target.strip())
    host = (parsed.hostname or "").lower()
    return (
        "webhook.office.com" in host
        or "webhook.microsoft.com" in host
        or "logic.azure.com" in host
    )


def resolve_webhook_tls_verify(channel_verify_ssl: int | bool | None) -> bool:
    if channel_verify_ssl is None:
        return True
    return bool(channel_verify_ssl)
