from __future__ import annotations

import ssl

import httpx

from config import settings


class FlowmonAuthError(Exception):
    pass


class FlowmonTlsError(FlowmonAuthError):
    """TLS/certificate verification failed when connecting to the device."""


def _is_tls_error(exc: Exception) -> bool:
    """Detect certificate/TLS failures, which httpx reports as ConnectError."""
    current: BaseException | None = exc
    while current is not None:
        if isinstance(current, ssl.SSLError):
            return True
        current = current.__cause__ or current.__context__
    return "certificate" in str(exc).lower() or "ssl" in str(exc).lower()


def resolve_ssl_verify(verify_ssl: bool | None) -> bool | str:
    """
    Translate a device's `verify_ssl` flag into an httpx `verify=` value.

    - False (default): no certificate verification — Flowmon appliances ship
      self-signed certificates, so this is what works out of the box.
    - True: verify using the CA bundle configured in FLOWMON_VERIFY_SSL if one
      is set, otherwise the system CA bundle.
    - None: fall back to the global FLOWMON_VERIFY_SSL setting.
    """
    if verify_ssl is None:
        return settings.ssl_verify
    if not verify_ssl:
        return False
    configured = settings.ssl_verify
    return configured if isinstance(configured, str) else True


async def acquire_flowmon_token(
    device_url: str,
    username: str,
    password: str,
    verify_ssl: bool | None = None,
) -> dict:
    """
    Exchange username/password for a Flowmon OAuth2 bearer token.
    Returns the full token response dict on success.
    Raises FlowmonAuthError on invalid credentials or unreachable device.
    """
    url = f"{device_url.rstrip('/')}/resources/oauth/token"
    payload = {
        "grant_type": "password",
        "client_id": "invea-tech",
        "username": username,
        "password": password,
    }

    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(verify_ssl), timeout=10.0) as client:
            response = await client.post(
                url,
                data=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
    except httpx.ConnectError as exc:
        if _is_tls_error(exc):
            raise FlowmonTlsError(
                "TLS certificate verification failed for the device. Flowmon appliances use "
                "self-signed certificates by default — turn off 'Verify TLS certificate' for "
                "this device, or set FLOWMON_VERIFY_SSL to a CA bundle that trusts it."
            ) from exc
        raise FlowmonAuthError("Cannot reach Flowmon device") from exc
    except httpx.TimeoutException as exc:
        raise FlowmonAuthError("Connection to Flowmon device timed out") from exc
    except httpx.RequestError as exc:
        raise FlowmonAuthError(f"Device communication failed ({type(exc).__name__})") from exc

    if response.status_code == 200:
        return response.json()

    if response.status_code in (400, 401):
        raise FlowmonAuthError("Invalid username or password")

    raise FlowmonAuthError(f"Flowmon auth endpoint returned HTTP {response.status_code}")
