"""Generate and retrieve Flowmon support log bundles over SSH.

Flowmon ships `gather-logs.sh`, which the `flowmon` user can run via
passwordless sudo. It collects logs and diagnostic tool output into a tar.gz
under `/data/tmp` and prints the resulting path. On a busy appliance this
takes on the order of minutes and the archive can be several hundred MB, so
generation runs as a background task: the caller polls a status endpoint and
downloads the finished file over SFTP once ready.

The `-p` flag disables the script's own encryption. The manager already
transports the file over an authenticated SSH/SFTP session and keeps the
staged copy only for a short retry window, so the encryption step would only
add a password prompt with no security benefit here.
"""
from __future__ import annotations

import logging
import os
import re
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

from services.ssh_utils import _load_private_key, create_ssh_client
from paths import DATA_DIR

logger = logging.getLogger(__name__)

GATHER_LOGS_CMD = "sudo -n /data/components/apps/bin/gather-logs.sh -p"
GENERATION_TIMEOUT_SECONDS = 20 * 60
TRANSFER_TIMEOUT_SECONDS = 30 * 60

# Printed path looks like `/data/tmp/logs-2026-09-08_01-32-15.tar.gz`.
_PATH_RE = re.compile(r"(/data/tmp/[A-Za-z0-9._-]+\.tar\.gz)")

# Local staging area for bundles in flight. Finished files remain available
# for retry until the periodic TTL sweep removes them.
STAGING_DIR = DATA_DIR / "support_bundles"
STAGING_DIR.mkdir(mode=0o700, exist_ok=True)
os.chmod(STAGING_DIR, 0o700)

# How long a finished bundle remains available for download/retry.
STAGING_TTL_SECONDS = 30 * 60
RUNNING_TASK_TIMEOUT_SECONDS = (
    GENERATION_TIMEOUT_SECONDS + TRANSFER_TIMEOUT_SECONDS + 5 * 60
)


class SupportBundleError(Exception):
    pass


class SupportBundleConflict(SupportBundleError):
    def __init__(self, task_id: str):
        self.task_id = task_id
        super().__init__("Support log collection is already running for this device")


@dataclass
class SupportBundleTask:
    id: str
    device_id: str
    device_name: str
    status: str = "running"  # running | ready | failed
    error: Optional[str] = None
    remote_path: Optional[str] = None
    local_path: Optional[Path] = None
    size_bytes: Optional[int] = None
    requested_by: str = "unknown"
    started_at: float = field(default_factory=time.monotonic)
    finished_at: Optional[float] = None


# In-memory task registry. Bundles are large, one-off downloads that don't
# need to survive a restart, so unlike alert rules this is not persisted.
_TASKS: Dict[str, SupportBundleTask] = {}
_TASKS_LOCK = threading.RLock()


def get_task(task_id: str) -> Optional[SupportBundleTask]:
    with _TASKS_LOCK:
        return _TASKS.get(task_id)


def _cleanup_task_file(task: SupportBundleTask) -> None:
    if task.local_path and task.local_path.exists():
        try:
            task.local_path.unlink()
        except OSError:
            logger.warning("Failed to remove staged support bundle %s", task.local_path)
    task.local_path = None


def sweep_stale_tasks() -> None:
    """Remove expired tasks plus orphaned files left by an interrupted process."""
    now = time.monotonic()
    with _TASKS_LOCK:
        timed_out = [
            task
            for task in _TASKS.values()
            if task.status == "running"
            and (now - task.started_at) > RUNNING_TASK_TIMEOUT_SECONDS
        ]
        for task in timed_out:
            task.status = "failed"
            task.error = "Support log collection exceeded its maximum runtime"
            task.finished_at = now
            _write_task_audit(
                task.requested_by,
                "DEVICE_SUPPORT_BUNDLE_FAILED",
                task,
                {"error": task.error},
            )
        stale = [
            task_id
            for task_id, task in _TASKS.items()
            if task.finished_at is not None and (now - task.finished_at) > STAGING_TTL_SECONDS
        ]
        for task_id in stale:
            _cleanup_task_file(_TASKS[task_id])
            _TASKS.pop(task_id, None)
        referenced_paths = {
            task.local_path.resolve()
            for task in _TASKS.values()
            if task.local_path is not None
        }

    cutoff = time.time() - STAGING_TTL_SECONDS
    for path in STAGING_DIR.glob("*"):
        try:
            if path.is_file() and path.resolve() not in referenced_paths and path.stat().st_mtime < cutoff:
                path.unlink()
        except OSError:
            logger.warning("Failed to remove orphaned support bundle %s", path)


def start_bundle_task(
    device_id: str,
    device_name: str,
    requested_by: str = "unknown",
) -> SupportBundleTask:
    with _TASKS_LOCK:
        for existing in _TASKS.values():
            if existing.device_id == device_id and existing.status == "running":
                raise SupportBundleConflict(existing.id)
        task = SupportBundleTask(
            id=str(uuid.uuid4()),
            device_id=device_id,
            device_name=device_name,
            requested_by=requested_by,
        )
        _TASKS[task.id] = task
        return task


def _write_task_audit(
    username: str,
    action: str,
    task: SupportBundleTask,
    details: Optional[dict] = None,
) -> None:
    try:
        from sqlalchemy.orm import Session

        from database import engine
        from routers.audit import write_audit

        payload = {"device_id": task.device_id, "task_id": task.id}
        if details:
            payload.update(details)
        with Session(engine) as db:
            write_audit(
                db,
                username=username,
                action=action,
                resource_type="device",
                resource_name=task.device_name,
                details=payload,
            )
    except Exception:
        logger.exception("Failed to write support bundle audit event %s", action)


def _wait_for_command(channel, timeout_seconds: float) -> tuple[int, bytes, bytes]:
    deadline = time.monotonic() + timeout_seconds
    stdout_chunks: list[bytes] = []
    stderr_chunks: list[bytes] = []
    while True:
        while channel.recv_ready():
            stdout_chunks.append(channel.recv(64 * 1024))
        while channel.recv_stderr_ready():
            stderr_chunks.append(channel.recv_stderr(64 * 1024))
        if channel.exit_status_ready():
            break
        if time.monotonic() >= deadline:
            raise socket.timeout("Support log collection command timed out")
        time.sleep(0.5)
    while channel.recv_ready():
        stdout_chunks.append(channel.recv(64 * 1024))
    while channel.recv_stderr_ready():
        stderr_chunks.append(channel.recv_stderr(64 * 1024))
    return channel.recv_exit_status(), b"".join(stdout_chunks), b"".join(stderr_chunks)


def run_bundle_generation(
    task_id: str,
    device_name: str,
    ip_address: str,
    port: int,
    auth_type: str,
    username: str,
    secret: str,
    requested_by: str,
) -> None:
    """Generate the bundle on the device and fetch it over SFTP.

    Intended to run in a worker thread via ``asyncio.to_thread`` — paramiko is
    blocking and the remote command can take minutes. Takes plain values
    rather than SQLAlchemy model instances because those are bound to a
    request-scoped session that closes before this thread runs.
    """
    with _TASKS_LOCK:
        task = _TASKS.get(task_id)
    if task is None or task.status != "running":
        return

    client = None
    local_part_path = STAGING_DIR / f"{task_id}.tar.gz.part"
    try:
        client = create_ssh_client()
        if auth_type == "key":
            pkey = _load_private_key(secret)
            client.connect(ip_address, port=port, username=username, pkey=pkey, timeout=10)
        else:
            client.connect(ip_address, port=port, username=username, password=secret, timeout=10)
        transport = client.get_transport()
        if transport:
            transport.set_keepalive(30)
        _, stdout, stderr = client.exec_command(
            GATHER_LOGS_CMD,
            timeout=GENERATION_TIMEOUT_SECONDS,
        )
        stdout.channel.settimeout(GENERATION_TIMEOUT_SECONDS)
        exit_status, out_bytes, err_bytes = _wait_for_command(
            stdout.channel,
            GENERATION_TIMEOUT_SECONDS,
        )
        out = out_bytes.decode("utf-8", errors="replace")
        err = err_bytes.decode("utf-8", errors="replace")

        if exit_status != 0:
            raise SupportBundleError(
                f"gather-logs.sh exited with status {exit_status}: {err.strip() or out.strip()}"
            )

        match = _PATH_RE.search(out) or _PATH_RE.search(err)
        if not match:
            raise SupportBundleError(
                f"Could not determine the generated bundle path from device output: {out.strip() or err.strip()}"
            )
        remote_path = match.group(1)
        task.remote_path = remote_path

        with _TASKS_LOCK:
            if task.status != "running":
                return

        sftp = client.open_sftp()
        try:
            sftp.get_channel().settimeout(TRANSFER_TIMEOUT_SECONDS)
            local_path = STAGING_DIR / f"{task_id}.tar.gz"
            local_part_path.touch(mode=0o600)
            os.chmod(local_part_path, 0o600)
            sftp.get(remote_path, str(local_part_path))
            local_part_path.replace(local_path)
            try:
                sftp.remove(remote_path)
            except OSError:
                logger.warning(
                    "Failed to remove remote support bundle %s on %s",
                    remote_path,
                    device_name,
                )
        finally:
            sftp.close()

        with _TASKS_LOCK:
            if task.status != "running":
                local_path.unlink(missing_ok=True)
                return
            task.local_path = local_path
            task.size_bytes = local_path.stat().st_size
            task.status = "ready"
            task.finished_at = time.monotonic()
        _write_task_audit(
            requested_by,
            "DEVICE_SUPPORT_BUNDLE_READY",
            task,
            {"size_bytes": task.size_bytes},
        )
    except socket.timeout:
        error = "Support log collection timed out"
        logger.warning("%s for %s", error, device_name)
        with _TASKS_LOCK:
            if task.status != "running":
                return
            task.status = "failed"
            task.error = error
            task.finished_at = time.monotonic()
        _cleanup_task_file(task)
        _write_task_audit(
            requested_by,
            "DEVICE_SUPPORT_BUNDLE_FAILED",
            task,
            {"error": error},
        )
    except Exception as exc:
        logger.warning("Support bundle generation failed for %s: %s", device_name, exc)
        with _TASKS_LOCK:
            if task.status != "running":
                return
            task.status = "failed"
            task.error = str(exc)
            task.finished_at = time.monotonic()
        _cleanup_task_file(task)
        _write_task_audit(
            requested_by,
            "DEVICE_SUPPORT_BUNDLE_FAILED",
            task,
            {"error": str(exc)},
        )
    finally:
        try:
            local_part_path.unlink(missing_ok=True)
        except OSError:
            logger.warning("Failed to remove partial support bundle %s", local_part_path)
        if client:
            try:
                client.close()
            except Exception:
                pass
