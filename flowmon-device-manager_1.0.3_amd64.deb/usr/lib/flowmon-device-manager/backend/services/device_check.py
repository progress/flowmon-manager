from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import httpx

from config import settings
from services.flowmon import FlowmonAuthError, acquire_flowmon_token, resolve_ssl_verify


def device_base_url(ip_address: str, https_port: Optional[int] = None) -> str:
    """Build a device's REST API base URL, honoring an optional HTTPS port
    override for devices that sit behind a reverse proxy on a non-standard
    port. Falls back to the standard ``https://`` (443) URL when unset."""
    if https_port and https_port != 443:
        return f"https://{ip_address}:{https_port}"
    return f"https://{ip_address}"


def _to_number(value: Any) -> Optional[float]:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None


def normalize_device_payload(data: Any) -> Dict[str, Any]:
    """Normalize a ``/rest/fcc/device`` response so callers can treat FOS 12
    and FOS 13 payloads identically.

    FOS 13 returns a flat structure (``cpuLoadAvgPerc``, ``memory``,
    ``sysdiskUsageMb``/``sysdiskTotalMb``, ``diskUsage`` list, ``deviceName``
    at the root, ...). FOS 12 nests the same information under
    ``deviceInfo``/``cpuLoad``/``ramUsage``/``systemDiskUsage``/
    ``dataDiskUsage`` objects, with different field names and units. When the
    FOS 12 shape is detected, this maps it onto the FOS 13 field names/units
    consumed elsewhere in the codebase so a single code path works for both.
    """
    if not isinstance(data, dict):
        return {}

    device_info = data.get("deviceInfo")
    if not isinstance(device_info, dict):
        # Already FOS 13 shaped (or an unrecognized shape) — pass through.
        return data

    normalized = dict(data)
    normalized["deviceName"] = device_info.get("deviceName")

    # CPU: FOS 12 only exposes 1/5/15-minute load averages, not a load
    # percentage, and doesn't report a CPU core count, so a percentage can't
    # be reliably derived. Surface the load averages as free text (shown in
    # the "CPU" info row) instead of leaving the CPU panel blank.
    cpu_load_obj = data.get("cpuLoad")
    if isinstance(cpu_load_obj, dict) and any(
        k in cpu_load_obj for k in ("avg1Min", "avg5Min", "avg15Min")
    ):
        normalized["cpuInfo"] = (
            f"Load average: {cpu_load_obj.get('avg1Min', '?')} (1m), "
            f"{cpu_load_obj.get('avg5Min', '?')} (5m), "
            f"{cpu_load_obj.get('avg15Min', '?')} (15m)"
        )

    # RAM: FOS 12 reports total/used directly in MB.
    ram = data.get("ramUsage")
    if isinstance(ram, dict):
        total_mb = _to_number(ram.get("total"))
        used_mb = _to_number(ram.get("used"))
        normalized["memoryTotalMb"] = total_mb
        normalized["memoryUsageMb"] = used_mb
        if total_mb:
            normalized["memory"] = round((used_mb or 0) / total_mb * 100, 1)

    # System disk (OS partition): FOS 12 reports this as systemDiskUsage in
    # bytes; FOS 13 uses sysdiskUsageMb/sysdiskTotalMb.
    sys_disk = data.get("systemDiskUsage")
    if isinstance(sys_disk, dict):
        total_bytes = _to_number(sys_disk.get("total"))
        used_bytes = _to_number(sys_disk.get("used"))
        if total_bytes:
            normalized["sysdiskTotalMb"] = total_bytes / (1024 ** 2)
            normalized["sysdiskUsageMb"] = (used_bytes or 0) / (1024 ** 2)
            normalized["sysdiskUsage"] = round((used_bytes or 0) / total_bytes * 100, 1)

    # Data disk (monitoring/flow storage): FOS 12 reports this as
    # dataDiskUsage in bytes; FOS 13 exposes a "diskUsage" list with
    # Total/Free category entries, matched by _disk_usage_entry().
    data_disk = data.get("dataDiskUsage")
    if isinstance(data_disk, dict):
        total_bytes = _to_number(data_disk.get("total"))
        used_bytes = _to_number(data_disk.get("used"))
        if total_bytes is not None:
            free_bytes = max(total_bytes - (used_bytes or 0), 0)
            normalized["diskUsage"] = [
                {"category": "Total", "sizeBytes": total_bytes},
                {"category": "Free", "sizeBytes": free_bytes},
            ]

    # Uptime: FOS 12 reports onlineTime in seconds; FOS 13 already reports
    # daysRunning directly.
    online_time = _to_number(device_info.get("onlineTime"))
    if online_time is not None:
        normalized["daysRunning"] = round(online_time / 86400, 1)

    # SMART status: FOS 12 has no aggregate smartStatus field, only a
    # per-disk isSmart/smartError breakdown under deviceInfo.disks[].
    disks = device_info.get("disks")
    if isinstance(disks, list) and disks:
        entries = [d for d in disks if isinstance(d, dict)]
        if any(_to_number(d.get("smartError")) for d in entries):
            normalized["smartStatus"] = "fail"
        elif entries and all(_to_number(d.get("isSmart")) == 0 for d in entries):
            # Virtual disks typically don't support SMART reporting at all.
            normalized["smartStatus"] = None
        else:
            normalized["smartStatus"] = "ok"

    return normalized



@dataclass
class DeviceInfo:
    status: str  # "online" | "offline"
    os_version: Optional[str]
    device_hostname: Optional[str]
    cpu_load: Optional[int]
    memory_usage: Optional[int]
    license_expiry: Optional[datetime]
    support_expiry: Optional[datetime]
    # True when the device reports a non-temporary (permanent) license with no
    # expiry date; False when it has a temporary license; None when unknown
    # (e.g. device unreachable or license endpoint failed).
    license_permanent: Optional[bool]
    checked_at: datetime
    error: Optional[str] = None


def _offline(now: datetime, error: str) -> DeviceInfo:
    return DeviceInfo(
        status="offline",
        os_version=None,
        device_hostname=None,
        cpu_load=None,
        memory_usage=None,
        license_expiry=None,
        support_expiry=None,
        license_permanent=None,
        checked_at=now,
        error=error,
    )


async def check_device(
    device_url: str,
    rest_username: str,
    rest_password: str,
    verify_ssl: bool | None = None,
) -> DeviceInfo:
    """
    Connect to a Flowmon device via REST API and return its current status.
    Returns DeviceInfo with status="offline" and a populated `error` if the device
    is unreachable or the REST credentials are rejected.
    """
    base = device_url.rstrip("/")
    now = datetime.now(timezone.utc)

    try:
        token_data = await acquire_flowmon_token(base, rest_username, rest_password, verify_ssl)
        token = token_data["access_token"]
    except FlowmonAuthError as exc:
        return _offline(now, str(exc))

    headers = {"Authorization": f"bearer {token}"}
    try:
        async with httpx.AsyncClient(verify=resolve_ssl_verify(verify_ssl), timeout=10.0) as client:
            version_res = await client.get(f"{base}/rest/version", headers=headers)
            device_res = await client.get(f"{base}/rest/fcc/device", headers=headers)
            license_res = await client.get(f"{base}/rest/fcc/license", headers=headers)
    except (httpx.ConnectError, httpx.TimeoutException) as exc:
        return _offline(now, f"Device became unreachable while reading status: {exc}")

    os_version = None
    if version_res.status_code == 200:
        os_version = version_res.json().get("version")

    device_hostname = None
    cpu_load = None
    memory_usage = None
    if device_res.status_code == 200:
        data = normalize_device_payload(device_res.json())
        device_hostname = data.get("deviceName")
        cpu_load = data.get("cpuLoadAvgPerc")
        memory_usage = data.get("memory")

    license_expiry = None
    support_expiry = None
    license_permanent = None
    if license_res.status_code == 200:
        license_json = license_res.json()
        functions = license_json.get("function", [])
        license_tos = [int(f["licenseTo"]) for f in functions if f.get("licenseTo") and int(f["licenseTo"]) > 0]
        support_tos = [int(f["supportTo"]) for f in functions if f.get("supportTo") and int(f["supportTo"]) > 0]
        if license_tos:
            license_expiry = datetime.fromtimestamp(min(license_tos), tz=timezone.utc)
        if support_tos:
            support_expiry = datetime.fromtimestamp(min(support_tos), tz=timezone.utc)
        temporary_license = license_json.get("device", {}).get("temporaryLicense")
        if temporary_license is not None:
            license_permanent = temporary_license is False

    return DeviceInfo(
        status="online",
        os_version=os_version,
        device_hostname=device_hostname,
        cpu_load=cpu_load,
        memory_usage=memory_usage,
        license_expiry=license_expiry,
        support_expiry=support_expiry,
        license_permanent=license_permanent,
        checked_at=now,
    )
