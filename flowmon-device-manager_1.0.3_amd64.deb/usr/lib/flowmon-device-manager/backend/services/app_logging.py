"""Bounded application logging and customer-shareable diagnostics."""
from __future__ import annotations

import contextvars
import hashlib
import io
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import platform
import re
import sys
import time
import uuid
import zipfile
from datetime import datetime, timezone
from importlib.metadata import version
from urllib.parse import urlsplit
from paths import DATA_DIR

request_id = contextvars.ContextVar("request_id", default="-")
LOG_DIR = DATA_DIR / "logs"
BOOTSTRAP_PASSWORD_FILE = LOG_DIR / "bootstrap-admin-password"
LOG_BYTES = 5 * 1024 * 1024
LOG_BACKUPS = 4


def save_bootstrap_admin_password(password: str) -> Path:
    LOG_DIR.mkdir(mode=0o700, exist_ok=True)
    os.chmod(LOG_DIR, 0o700)
    fd = os.open(
        BOOTSTRAP_PASSWORD_FILE,
        os.O_CREAT | os.O_TRUNC | os.O_WRONLY | os.O_NOFOLLOW,
        0o600,
    )
    os.fchmod(fd, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as password_file:
        password_file.write(password + "\n")
    return BOOTSTRAP_PASSWORD_FILE


def clear_bootstrap_admin_password() -> None:
    BOOTSTRAP_PASSWORD_FILE.unlink(missing_ok=True)


def redact(message: str) -> str:
    message = re.sub(
        r"-----BEGIN [^-]*PRIVATE KEY-----.*?(?:-----END [^-]*PRIVATE KEY-----|$)",
        "[REDACTED PRIVATE KEY]", message, flags=re.DOTALL,
    )
    message = re.sub(
        r"(?i)\b(bearer|basic)\s+[A-Za-z0-9+/=._-]+",
        r"\1 [REDACTED]", message,
    )
    message = re.sub(
        r"""(?ix)(["']?\b(?:password|passwd|pass|secret|secret_key|access_token|refresh_token|
        client_secret|authorization|cookie|fdm_session|secret_enc|password_enc|
        private_key|api_key)\b["']?\s*[:=]\s*)
        ("[^"]*"|'[^']*'|[^\s,;]+)""",
        r"\1[REDACTED]", message,
    )
    message = re.sub(r"(https?://)[^/\s:@]+:[^/\s@]+@", r"\1[REDACTED]@", message)
    message = re.sub(r"(?s)\[parameters:.*", "[parameters: REDACTED]", message)
    # Signed download URLs and arbitrary query parameters are not diagnostics.
    return re.sub(r"(https?://[^\s?'\"<>]+)\?[^\s'\"<>]*", r"\1?[REDACTED]", message)


class SafeFormatter(logging.Formatter):
    converter = time.gmtime

    def format(self, record: logging.LogRecord) -> str:
        # SQLAlchemy exceptions can embed SQL parameters, including credentials.
        # Keep the traceback and exception type, but not arbitrary exception text.
        if record.exc_info:
            import traceback
            trace = "".join(
                f'  File "{frame.filename}", line {frame.lineno}, in {frame.name}\n'
                for frame in traceback.extract_tb(record.exc_info[2])
            )
            exception_type = record.exc_info[0]
            record.exc_text = trace + (exception_type.__name__ if exception_type else "Exception")
            error = record.exc_info[1]
            seen: set[int] = set()
            while error is not None and id(error) not in seen:
                seen.add(id(error))
                code = getattr(error, "sqlite_errorname", None)
                errno = getattr(error, "errno", None)
                record.exc_text += f"\nCause: {type(error).__name__}"
                if code:
                    record.exc_text += f" code={code}"
                if isinstance(errno, int):
                    record.exc_text += f" errno={errno}"
                error = error.__cause__ or error.__context__
        return redact(super().format(record))


class DiagnosticFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id.get()
        return True


class OidcCallbackAccessFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.args, tuple) and len(record.args) == 5:
            path = urlsplit(str(record.args[2])).path
            if path.endswith("/api/auth/oidc/callback"):
                return False
        return True


class PrivateRotatingFileHandler(RotatingFileHandler):
    def _open(self):
        fd = os.open(self.baseFilename, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        os.close(fd)
        os.chmod(self.baseFilename, 0o600)
        return super()._open()


def build_id() -> str:
    """Fingerprint shipped source rather than relying on an absent .git directory."""
    digest = hashlib.sha256()
    backend = Path(__file__).resolve().parent.parent
    for path in sorted([*backend.glob("*.py"), *backend.glob("routers/*.py"),
                        *backend.glob("services/*.py")]):
        digest.update(str(path.relative_to(backend)).encode())
        digest.update(path.read_bytes())
    index = backend.parent / "frontend" / "dist" / "index.html"
    if index.exists():
        digest.update(index.read_bytes())
    return digest.hexdigest()[:16]


def configure_logging(level: str) -> None:
    LOG_DIR.mkdir(mode=0o700, exist_ok=True)
    os.chmod(LOG_DIR, 0o700)
    root = logging.getLogger()
    if any(getattr(h, "fdm_log_handler", False) for h in root.handlers):
        return
    path = LOG_DIR / "fdm.log"
    fd = os.open(path, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
    os.close(fd)
    os.chmod(path, 0o600)
    handler = PrivateRotatingFileHandler(path, maxBytes=LOG_BYTES, backupCount=LOG_BACKUPS, encoding="utf-8")
    handler.fdm_log_handler = True
    handler.addFilter(DiagnosticFilter())
    handler.setFormatter(SafeFormatter(
        "%(asctime)sZ %(levelname)s %(name)s request_id=%(request_id)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    ))
    root.addHandler(handler)
    root.setLevel(level)
    if not any(isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
               for h in root.handlers):
        console = logging.StreamHandler()
        console.setFormatter(SafeFormatter("%(levelname)s %(name)s %(message)s"))
        root.addHandler(console)
    # Avoid HTTP URLs, SSH protocol chatter and SQL parameters from dependencies.
    for name in ("httpx", "httpcore", "paramiko", "sqlalchemy", "authlib", "joserfc"):
        logging.getLogger(name).setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").addFilter(OidcCallbackAccessFilter())
    logging.getLogger("uvicorn").addHandler(handler)


class RequestLoggingMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        identifier = uuid.uuid4().hex
        scope.setdefault("state", {})["request_id"] = identifier
        token = request_id.set(identifier)
        started = time.monotonic()
        status = 500
        logger = logging.getLogger("fdm.requests")

        async def send_response(message):
            nonlocal status
            if message["type"] == "http.response.start":
                status = message["status"]
                message["headers"] = [
                    *message.get("headers", []),
                    (b"x-request-id", identifier.encode("ascii")),
                ]
            await send(message)

        try:
            await self.app(scope, receive, send_response)
        except Exception:
            logger.exception("Unhandled request failure")
            raise
        finally:
            route = scope.get("route")
            # Route templates avoid recording query strings or user-supplied paths.
            path = getattr(route, "path", "<unmatched-or-static>")
            logger.log(
                logging.ERROR if status >= 500 else logging.WARNING if status >= 400 else logging.INFO,
                "%s %s status=%d duration_ms=%.1f",
                scope["method"], path, status, (time.monotonic() - started) * 1000,
            )
            request_id.reset(token)


def build_diagnostics() -> bytes:
    for handler in logging.getLogger().handlers:
        handler.flush()
    metadata = {
        "application": "Flowmon Device Manager",
        "build_id": build_id(),
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "python": sys.version.split()[0],
        "platform": platform.system(),
        "dependencies": {name: version(name) for name in ("fastapi", "sqlalchemy", "paramiko", "httpx")},
        "log_timezone": "UTC",
        "log_limit_bytes": LOG_BYTES,
        "retained_files": LOG_BACKUPS + 1,
    }
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("environment.json", json.dumps(metadata, indent=2))
        archive.writestr("README.txt",
            "Device Manager diagnostics; not a Flowmon appliance support bundle.\n"
            "Contains bounded application logs only; no database, .env, credentials or request bodies.\n"
            "Logs may contain internal device names, addresses and filenames. Review before sharing.\n"
            "Provide the incident time (with timezone), steps to reproduce and any request ID.\n")
        for suffix in ("", *(f".{i}" for i in range(1, LOG_BACKUPS + 1))):
            path = LOG_DIR / f"fdm.log{suffix}"
            try:
                with path.open("rb") as source:
                    data = source.read(LOG_BYTES)
            except FileNotFoundError:
                continue  # Rotation may move a file while collection is in progress.
            archive.writestr(path.name, redact(data.decode("utf-8", errors="replace")))
    return output.getvalue()
