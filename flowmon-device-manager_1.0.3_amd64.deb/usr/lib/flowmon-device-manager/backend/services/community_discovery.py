"""Discover the latest published Flowmon packages on the Progress artifact host.

The packages advertised on the Progress community portal are served from a
predictable artifact host, so instead of driving a headless browser through a
JavaScript-rendered portal we probe the artifact host directly:

    <BASE>/<Product>/<maj>.<min>.<patch>-<Stable|Beta>/<prefix>-v<maj>.<mm>.<pp>.tar.gz

Starting from the newest version we already know about, every plausible next
version is checked with a HEAD request. A ``200`` means the package is really
published and downloadable; anything else means it does not exist (the artifact
host answers ``403`` rather than ``404`` for unknown keys, because bucket
listing is denied).

This is both more reliable and far cheaper than scraping: there is no browser to
install, the result is verified against the actual download URL rather than a
link that may 404, and each component is resolved independently — component
versions genuinely diverge (the FPI probe package regularly lags the FPI
collector package by a release).
"""
from __future__ import annotations

import asyncio
import logging
import re
from typing import Dict, List, Literal, Optional, Sequence, Tuple

import httpx

from config import settings

logger = logging.getLogger(__name__)

ARTIFACT_BASE = "https://kemptechnologies.com/files/packages/flowmon-products"

# The artifact host rejects requests without a browser-like User-Agent.
_USER_AGENT = "Mozilla/5.0 (compatible; FlowmonDeviceManager/1.0)"

Version = Tuple[int, int, int]
ReleaseChannel = Literal["stable", "beta"]

# Oldest version each component is known to have published. Discovery starts
# here and walks forward, so this only ever needs to move if a component is
# removed from the artifact host; newer releases are found automatically.
COMPONENTS: List[Dict] = [
    {
        "slug": "flowmon",
        "name": "Flowmon OS",
        "product_dir": "Flowmon",
        "file_prefix": "flowmon",
        "baseline": (13, 0, 10),
        "release_notes_url": "https://docs.progress.com/bundle/progress-release-notes-OS/page/topics/Release-notes-OS/Version-13.0.html",
    },
    {
        "slug": "ads",
        "name": "Flowmon ADS",
        "product_dir": "Flowmon-ADS",
        "file_prefix": "flowmonplug-ads",
        "baseline": (13, 0, 4),
        "release_notes_url": "https://docs.progress.com/bundle/progress-release-notes-ADS/page/topics/Flowmon-release-notes-ADS/Version-13.0.html",
    },
    {
        "slug": "fpi",
        "name": "Flowmon FPI (Collector)",
        "product_dir": "Flowmon-Packet-Investigator",
        "file_prefix": "flowmonplug-fpi",
        "baseline": (13, 0, 0),
        "release_notes_url": "https://docs.progress.com/bundle/progress-release-notes-FPI/page/topics/Flowmon-release-notes-FPI/Version-13.0.html",
    },
    {
        "slug": "fpi-probe",
        "name": "Flowmon FPI (Probe)",
        "product_dir": "Flowmon-Packet-Investigator",
        "file_prefix": "flowmonplug-fpi-probe",
        "baseline": (13, 0, 0),
        "release_notes_url": "https://docs.progress.com/bundle/progress-release-notes-FPI/page/topics/Flowmon-release-notes-FPI/Version-13.0.html",
    },
    {
        "slug": "apm",
        "name": "Flowmon APM (Collector)",
        "product_dir": "Flowmon-APM",
        "file_prefix": "flowmonplug-apm",
        "baseline": (13, 0, 1),
        "release_notes_url": "https://docs.progress.com/bundle/progress-release-notes-APM/page/topics/Flowmon-release-notes-APM/Version-13.0.html",
    },
    {
        "slug": "apm-probe",
        "name": "Flowmon APM (Probe)",
        "product_dir": "Flowmon-APM",
        "file_prefix": "flowmonplug-apm-probe",
        "baseline": (13, 0, 1),
        "release_notes_url": "https://docs.progress.com/bundle/progress-release-notes-APM/page/topics/Flowmon-release-notes-APM/Version-13.0.html",
    },
]

# How far ahead of the newest known version to look.
PATCH_LOOKAHEAD = 6
MINOR_LOOKAHEAD = 2
MAJOR_LOOKAHEAD = 1
MAX_CONCURRENT_PROBES = 6

_VERSION_RE = re.compile(r"-v(\d+)\.(\d+)\.(\d+)\.tar\.gz$")


def parse_version(text: str) -> Optional[Version]:
    """Parse a version out of a package filename or a plain version string."""
    if not text:
        return None
    m = _VERSION_RE.search(text)
    if m:
        return int(m.group(1)), int(m.group(2)), int(m.group(3))
    # Plain "13.00.11" / "13.0.11" style, tolerating a trailing dot from the
    # version regex the old scraper used.
    parts = text.strip().strip(".").split(".")
    if len(parts) == 3 and all(p.isdigit() for p in parts):
        return int(parts[0]), int(parts[1]), int(parts[2])
    return None


def format_version(version: Version) -> str:
    """Version as it appears in a package filename, e.g. ``13.00.11``."""
    major, minor, patch = version
    return f"{major}.{minor:02d}.{patch:02d}"


def build_filename(comp: Dict, version: Version) -> str:
    return f"{comp['file_prefix']}-v{format_version(version)}.tar.gz"


def build_url(
    comp: Dict, version: Version, channel: ReleaseChannel = "stable"
) -> str:
    """Artifact URL. The directory uses unpadded numbers, the file padded ones."""
    major, minor, patch = version
    return (
        f"{ARTIFACT_BASE}/{comp['product_dir']}/{major}.{minor}.{patch}-{channel.title()}/"
        f"{build_filename(comp, version)}"
    )


def candidate_versions(known: Version) -> List[Version]:
    """Versions to probe, ordered oldest first.

    Looks ahead on the patch level (the common case), then tries the next minor
    and major series so a release train change is picked up too.
    """
    major, minor, patch = known
    candidates: List[Version] = []
    for p in range(patch + 1, patch + 1 + PATCH_LOOKAHEAD):
        candidates.append((major, minor, p))
    for m in range(minor + 1, minor + 1 + MINOR_LOOKAHEAD):
        for p in range(0, PATCH_LOOKAHEAD):
            candidates.append((major, m, p))
    for mj in range(major + 1, major + 1 + MAJOR_LOOKAHEAD):
        for p in range(0, PATCH_LOOKAHEAD):
            candidates.append((mj, 0, p))
    return candidates


async def _package_exists(client: httpx.AsyncClient, url: str) -> Tuple[bool, Optional[int]]:
    """HEAD the artifact URL. Returns (exists, size in bytes)."""
    resp = await client.head(url, follow_redirects=True, timeout=20.0)
    if resp.status_code not in (200, 403, 404):
        resp.raise_for_status()
    if resp.status_code != 200:
        return False, None
    size = resp.headers.get("content-length")
    return True, int(size) if size and size.isdigit() else None


async def _discover_component(
    client: httpx.AsyncClient, comp: Dict, known: Version, channel: ReleaseChannel,
    semaphore: asyncio.Semaphore,
) -> Dict:
    """Find the newest published version of one component, at or after ``known``."""
    result: Dict = {
        "slug": comp["slug"],
        "name": comp["name"],
        "download_url": None,
        "release_notes_url": comp.get("release_notes_url"),
        "version": None,
        "filename": None,
        "size": None,
        "error": None,
    }

    failures: List[str] = []

    async def probe(version: Version) -> Tuple[bool, Optional[int]]:
        async with semaphore:
            try:
                return await _package_exists(client, build_url(comp, version, channel))
            except httpx.HTTPError as exc:
                failures.append(type(exc).__name__)
                return False, None

    candidates = candidate_versions(known)
    checks = await asyncio.gather(
        *(probe(v) for v in candidates)
    )
    found = [v for v, (exists, _) in zip(candidates, checks) if exists]

    if found:
        latest = max(found)
        exists, size = next(
            (r for v, r in zip(candidates, checks) if v == latest), (True, None)
        )
    else:
        # Nothing newer — confirm the version we already know about is still
        # downloadable so the UI never advertises a dead link.
        latest = known
        exists, size = await probe(latest)

    if exists:
        result["version"] = format_version(latest)
        result["filename"] = build_filename(comp, latest)
        result["download_url"] = build_url(comp, latest, channel)
        result["size"] = size
    if failures:
        result["error"] = (
            f"Incomplete discovery: {len(failures)} package checks failed "
            f"({', '.join(sorted(set(failures)))}); check network access, "
            "COMMUNITY_PROXY_URL and TLS certificates."
        )
    elif not exists:
        result["error"] = (
            f"No published {channel} package found at or after {format_version(known)}"
        )
    if result["error"]:
        logger.warning("Community discovery component=%s channel=%s: %s",
                       comp["slug"], channel, result["error"])
    return result


def _baseline_for(comp: Dict, known_versions: Dict[str, Version]) -> Version:
    """Start from the newest of the configured baseline and what we already found."""
    baseline: Version = comp["baseline"]
    previous = known_versions.get(comp["slug"])
    return max(baseline, previous) if previous else baseline


async def discover_latest_packages(
    known_versions: Optional[Dict[str, Version]] = None,
    components: Optional[Sequence[Dict]] = None,
    channel: ReleaseChannel = "stable",
) -> List[Dict]:
    """Resolve the latest published package for every component.

    ``known_versions`` seeds the search from previously discovered versions so
    repeated runs stay cheap and never regress to an older release.
    """
    comps = list(components if components is not None else COMPONENTS)
    known = known_versions or {}
    headers = {"User-Agent": _USER_AGENT}
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_PROBES)
    limits = httpx.Limits(
        max_connections=MAX_CONCURRENT_PROBES,
        max_keepalive_connections=MAX_CONCURRENT_PROBES,
    )
    async with httpx.AsyncClient(
        headers=headers, proxy=settings.community_proxy, limits=limits
    ) as client:
        return await asyncio.gather(
            *(_discover_component(client, c, _baseline_for(c, known), channel, semaphore)
              for c in comps)
        )


def known_versions_from_cache(cache: Dict) -> Dict[str, Version]:
    """Rebuild the version baselines from a previously stored cache document."""
    versions: Dict[str, Version] = {}
    for pkg in (cache or {}).get("packages", []) or []:
        slug = pkg.get("slug")
        if not slug:
            continue
        version = parse_version(pkg.get("filename") or "") or parse_version(
            pkg.get("version") or ""
        )
        if version:
            versions[slug] = version
    return versions
