"""Parse Flowmon exporter configuration into flow export destinations.

Answers "where is each monitoring interface sending its flow data?" from
``GET /rest/fcc/exporters/`` and ``GET /rest/fcc/exporters/status/``.

Two details of the appliance's data model drive most of this module:

* The exporter list contains a pseudo-entry with id ``global`` holding the
  default export targets. A per-interface exporter only carries its own
  targets when ``useCustomExportTargets`` is true; otherwise it *inherits* the
  global ones. Reading the per-interface ``exportTargets`` blindly would
  therefore be wrong whenever a device is configured globally, which is the
  default.
* Destinations live in a flat ``params`` string
  (``host=localhost,port=3000,protocol=udp``) rather than structured fields.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

# `/rest/fcc/exporters/` uses this id for the shared default configuration.
GLOBAL_EXPORTER_ID = "global"

# Flowmon names its export plugins after the protocol they speak.
_PROTOCOL_LABELS = {
    "ipfix-ng": "IPFIX",
    "ipfix": "IPFIX",
    "netflow-v9": "NetFlow v9",
    "nfv9": "NetFlow v9",
    "netflow-v5": "NetFlow v5",
    "nfv5": "NetFlow v5",
}

# Hosts that mean "the collector on this same appliance".
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "ip6-localhost"}


def protocol_label(name: Optional[str]) -> str:
    """Human-readable export protocol, falling back to the raw plugin name."""
    if not name:
        return "—"
    return _PROTOCOL_LABELS.get(name.strip().lower(), name)


def parse_params(params: Optional[str]) -> dict[str, str]:
    """Parse a ``key=value,key=value`` plugin parameter string.

    Unknown or malformed fragments are skipped rather than raising — this
    string is free-form on the device and new keys appear between releases.
    """
    result: dict[str, str] = {}
    if not params:
        return result
    for fragment in params.split(","):
        key, sep, value = fragment.partition("=")
        if not sep:
            continue
        key = key.strip()
        if key:
            result[key] = value.strip()
    return result


def is_local_host(host: Optional[str]) -> bool:
    """True when flows stay on the appliance (its own collector)."""
    return (host or "").strip().lower() in _LOCAL_HOSTS


@dataclass
class ExportTarget:
    """One destination that an interface's flow data is sent to."""

    host: str
    port: Optional[str]
    protocol: str
    transport: Optional[str]
    sampling: int = 0
    description: str = ""
    filter_count: int = 0
    local: bool = False

    @property
    def destination(self) -> str:
        return f"{self.host}:{self.port}" if self.port else self.host


@dataclass
class InterfaceExport:
    """Export configuration for a single monitoring interface."""

    interface: str
    targets: list[ExportTarget] = field(default_factory=list)
    # False when the interface inherits the device-wide export targets.
    custom_targets: bool = False
    enabled: bool = False
    active: bool = False
    status_message: Optional[str] = None
    active_timeout: Optional[int] = None
    inactive_timeout: Optional[int] = None


def _parse_targets(export_targets: Optional[dict[str, Any]]) -> list[ExportTarget]:
    if not isinstance(export_targets, dict):
        return []
    outputs = export_targets.get("outputs")
    if not isinstance(outputs, list):
        return []

    targets: list[ExportTarget] = []
    for output in outputs:
        if not isinstance(output, dict):
            continue
        params = parse_params(output.get("params"))
        host = params.get("host") or ""
        filters = output.get("filters")
        sampling = output.get("sampling")
        targets.append(
            ExportTarget(
                host=host,
                port=params.get("port"),
                protocol=protocol_label(output.get("name")),
                transport=(params.get("protocol") or "").upper() or None,
                sampling=sampling if isinstance(sampling, int) else 0,
                description=output.get("description") or "",
                filter_count=len(filters) if isinstance(filters, list) else 0,
                local=is_local_host(host),
            )
        )
    return targets


def _is_fos12_exporter_entry(entry: Any) -> bool:
    """FOS12 lists exporters flat, per-interface, with a ``targets`` array
    of ``{ip, port, exportProtocol}`` — no shared ``global`` entry and no
    ``exportTargets``/``useCustomExportTargets`` fields like FOS13."""
    return (
        isinstance(entry, dict)
        and "interface" in entry
        and "targets" in entry
        and "exportTargets" not in entry
    )


def _parse_targets_fos12(targets: Any) -> list[ExportTarget]:
    if not isinstance(targets, list):
        return []
    result: list[ExportTarget] = []
    for t in targets:
        if not isinstance(t, dict):
            continue
        host = t.get("ip") or ""
        result.append(
            ExportTarget(
                host=host,
                port=str(t.get("port")) if t.get("port") is not None else None,
                protocol=protocol_label(t.get("exportProtocol")),
                transport=None,
                sampling=0,
                description="",
                filter_count=0,
                local=is_local_host(host),
            )
        )
    return result


def _parse_exporters_fos12(exporters: list[Any]) -> list[InterfaceExport]:
    results: list[InterfaceExport] = []
    for entry in exporters:
        if not isinstance(entry, dict):
            continue
        iface = entry.get("interface")
        if not iface:
            continue
        state = entry.get("state") if isinstance(entry.get("state"), dict) else {}
        label = (state.get("label") or "").strip().lower()
        running = label == "running"
        active_timeout = entry.get("activeTimeout")
        inactive_timeout = entry.get("inactiveTimeout")
        results.append(
            InterfaceExport(
                interface=iface,
                targets=_parse_targets_fos12(entry.get("targets")),
                # FOS12 always reports explicit per-interface targets; there
                # is no global/inherited configuration concept.
                custom_targets=True,
                enabled=running,
                active=running,
                status_message=state.get("label"),
                active_timeout=active_timeout if isinstance(active_timeout, int) else None,
                inactive_timeout=inactive_timeout if isinstance(inactive_timeout, int) else None,
            )
        )
    results.sort(key=lambda r: r.interface)
    return results


def parse_exporters(
    exporters: Any,
    status: Any = None,
) -> list[InterfaceExport]:
    """Build the per-interface export view.

    ``exporters`` is the body of ``/rest/fcc/exporters/`` and ``status`` the
    optional body of ``/rest/fcc/exporters/status/``.
    """
    if not isinstance(exporters, list):
        return []

    if exporters and all(_is_fos12_exporter_entry(e) for e in exporters if isinstance(e, dict)):
        return _parse_exporters_fos12(exporters)

    global_targets: list[ExportTarget] = []
    global_timeouts: dict[str, Any] = {}
    for entry in exporters:
        if isinstance(entry, dict) and entry.get("id") == GLOBAL_EXPORTER_ID:
            global_targets = _parse_targets(entry.get("exportTargets"))
            if isinstance(entry.get("exportTargets"), dict):
                global_timeouts = entry["exportTargets"]
            break

    status_map = status if isinstance(status, dict) else {}
    results: list[InterfaceExport] = []

    for entry in exporters:
        if not isinstance(entry, dict):
            continue
        iface = entry.get("id")
        if not iface or iface == GLOBAL_EXPORTER_ID:
            continue

        custom = bool(entry.get("useCustomExportTargets"))
        own_targets = entry.get("exportTargets")
        targets = _parse_targets(own_targets) if custom else list(global_targets)
        timeouts = own_targets if custom and isinstance(own_targets, dict) else global_timeouts

        iface_status = status_map.get(iface)
        if not isinstance(iface_status, dict):
            iface_status = {}

        active_timeout = timeouts.get("activeTimeout") if isinstance(timeouts, dict) else None
        inactive_timeout = timeouts.get("inactiveTimeout") if isinstance(timeouts, dict) else None

        results.append(
            InterfaceExport(
                interface=iface,
                targets=targets,
                custom_targets=custom,
                # `requiredRunningState` is the configured intent; the status
                # endpoint reports what is actually running.
                enabled=bool(iface_status.get("enabled", entry.get("requiredRunningState"))),
                active=bool(iface_status.get("active")),
                status_message=iface_status.get("message"),
                active_timeout=active_timeout if isinstance(active_timeout, int) else None,
                inactive_timeout=inactive_timeout if isinstance(inactive_timeout, int) else None,
            )
        )

    results.sort(key=lambda r: r.interface)
    return results


def serialize_exports(exports: list[InterfaceExport]) -> list[dict[str, Any]]:
    """Convert to the JSON shape returned by the device detail endpoint."""
    return [
        {
            "interface": e.interface,
            "custom_targets": e.custom_targets,
            "enabled": e.enabled,
            "active": e.active,
            "status_message": e.status_message,
            "active_timeout": e.active_timeout,
            "inactive_timeout": e.inactive_timeout,
            "targets": [
                {
                    "host": t.host,
                    "port": t.port,
                    "destination": t.destination,
                    "protocol": t.protocol,
                    "transport": t.transport,
                    "sampling": t.sampling,
                    "description": t.description,
                    "filter_count": t.filter_count,
                    "local": t.local,
                }
                for t in e.targets
            ],
        }
        for e in exports
    ]
