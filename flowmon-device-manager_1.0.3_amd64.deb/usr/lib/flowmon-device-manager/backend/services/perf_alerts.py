"""Threshold alerting on collected device performance metrics.

The performance collector (``services.perfmon``) stores a time series of
samples per device. This module turns those samples into alerts.

Design notes:

* **Direction matters.** Most metrics are bad when they climb (disk usage,
  I/O wait) but some are bad when they fall (free memory, flow-data retention,
  flows per second). Each metric therefore declares whether it breaches
  ``above`` or ``below`` its thresholds, which also means "critical" is not
  always the larger number.
* **Counters are not gauges.** ``udp_buffer_errors`` and the interface RX
  counters are cumulative since boot, so their absolute value is meaningless
  for alerting — a device up for a year will always look terrible. These are
  evaluated as a *rate* computed from the delta between consecutive samples.
* **Sustained breaches only.** A single sample above the line is usually a
  spike, not a problem. A rule only fires once ``consecutive_samples`` samples
  in a row breach it, which at the default 5-minute collection interval means
  roughly 15 minutes of sustained load.
* Thresholds are **per device**, overriding built-in defaults chosen to be
  quiet on a healthy Flowmon appliance.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional, Sequence

# Breach directions.
ABOVE = "above"
BELOW = "below"

# How a raw metric is turned into a comparable value.
GAUGE = "gauge"      # use the sampled value as-is
COUNTER = "counter"  # cumulative; compare the per-second delta between samples

DEFAULT_CONSECUTIVE_SAMPLES = 3

# A counter that goes backwards means the device rebooted or the counter
# wrapped; the delta is meaningless and the sample pair is skipped.
_COUNTER_RESET = object()


@dataclass(frozen=True)
class PerfMetric:
    """One alertable performance metric."""

    key: str
    label: str
    unit: str
    direction: str
    kind: str
    warning: Optional[float]
    critical: Optional[float]
    enabled: bool
    description: str
    # Metrics that only exist on devices that capture traffic. Used by the UI
    # to hide irrelevant rows; evaluation simply skips absent data.
    probe_only: bool = False
    # Derived metrics are computed from a sample rather than read off a column.
    compute: Optional[Callable[[Any], Optional[float]]] = None

    def value_from(self, sample: Any) -> Optional[float]:
        """Read this metric's raw value from a perf sample row."""
        if self.compute is not None:
            return self.compute(sample)
        value = getattr(sample, self.key, None)
        return float(value) if isinstance(value, (int, float)) else None


def _cpu_total(sample: Any) -> Optional[float]:
    """Combined user + system CPU. Deliberately excludes iowait, which is
    tracked separately and means something quite different."""
    user = getattr(sample, "cpu_user", None)
    system = getattr(sample, "cpu_system", None)
    if not isinstance(user, (int, float)) and not isinstance(system, (int, float)):
        return None
    return float(user or 0.0) + float(system or 0.0)


# Defaults are tuned to stay silent on a healthy appliance. Metrics that are
# routinely noisy on Flowmon (disk utilisation pegs at 100% during flow
# writes; flows/s varies by orders of magnitude between deployments) ship
# disabled so users opt into them deliberately.
PERF_METRICS: tuple[PerfMetric, ...] = (
    PerfMetric(
        key="disk_percent",
        label="Disk usage",
        unit="%",
        direction=ABOVE,
        kind=GAUGE,
        warning=80.0,
        critical=90.0,
        enabled=True,
        description="Used capacity of the /data partition, which stores flow data.",
    ),
    PerfMetric(
        key="disk_inode_percent",
        label="Disk inode usage",
        unit="%",
        direction=ABOVE,
        kind=GAUGE,
        warning=80.0,
        critical=90.0,
        enabled=True,
        description="Used inodes on /data. Can exhaust before capacity does.",
    ),
    PerfMetric(
        key="disk_util",
        label="Disk utilization",
        unit="%",
        direction=ABOVE,
        kind=GAUGE,
        warning=90.0,
        critical=98.0,
        enabled=False,
        description="Share of time the disk was busy. Normally spiky on a collector, so off by default.",
    ),
    PerfMetric(
        key="disk_tps",
        label="Disk transactions",
        unit="tps",
        direction=ABOVE,
        kind=GAUGE,
        warning=2000.0,
        critical=5000.0,
        enabled=False,
        description="I/O transactions per second. Baseline varies by hardware, so off by default.",
    ),
    PerfMetric(
        key="cpu_total",
        label="CPU usage",
        unit="%",
        direction=ABOVE,
        kind=GAUGE,
        warning=85.0,
        critical=95.0,
        enabled=True,
        description="Combined user and system CPU time.",
        compute=_cpu_total,
    ),
    PerfMetric(
        key="cpu_iowait",
        label="CPU I/O wait",
        unit="%",
        direction=ABOVE,
        kind=GAUGE,
        warning=20.0,
        critical=40.0,
        enabled=True,
        description="Time the CPU spent waiting on storage. Sustained values point at a disk bottleneck.",
    ),
    PerfMetric(
        key="mem_free_percent",
        label="Free memory",
        unit="%",
        direction=BELOW,
        kind=GAUGE,
        warning=15.0,
        critical=7.0,
        enabled=True,
        description="Available memory as a share of total.",
    ),
    PerfMetric(
        key="data_lifetime_days",
        label="Flow data retention",
        unit="days",
        direction=BELOW,
        kind=GAUGE,
        warning=30.0,
        critical=14.0,
        enabled=True,
        description="How far back stored flow data reaches. Shrinks as traffic volume grows.",
    ),
    PerfMetric(
        key="fps",
        label="Flows per second",
        unit="fps",
        direction=BELOW,
        kind=GAUGE,
        warning=10.0,
        critical=1.0,
        enabled=False,
        description="Flows received by the collector. Normal volume is deployment-specific, so off by default.",
    ),
    PerfMetric(
        key="udp_buffer_errors",
        label="UDP buffer errors",
        unit="errors/s",
        direction=ABOVE,
        kind=COUNTER,
        warning=1.0,
        critical=100.0,
        enabled=True,
        description="Flow packets dropped because the receive buffer was full.",
    ),
    PerfMetric(
        key="iface_rx_errors",
        label="Interface RX errors",
        unit="pkt/s",
        direction=ABOVE,
        kind=COUNTER,
        warning=1.0,
        critical=100.0,
        enabled=True,
        description="Receive errors on the monitoring interfaces.",
        probe_only=True,
    ),
    PerfMetric(
        key="probe_skipped_pkt_per_sec",
        label="Exporter skipped packets",
        unit="pkt/s",
        direction=ABOVE,
        kind=GAUGE,
        warning=1.0,
        critical=100.0,
        enabled=True,
        description="Packets the exporter could not process. Indicates the probe is overloaded.",
        probe_only=True,
    ),
)

PERF_METRICS_BY_KEY: dict[str, PerfMetric] = {m.key: m for m in PERF_METRICS}


def get_metric(key: str) -> Optional[PerfMetric]:
    return PERF_METRICS_BY_KEY.get(key)


@dataclass
class EffectiveRule:
    """A metric's thresholds after applying any per-device override."""

    metric: PerfMetric
    enabled: bool
    warning: Optional[float]
    critical: Optional[float]
    consecutive_samples: int

    @property
    def key(self) -> str:
        return self.metric.key


def _clean_threshold(value: Any) -> Optional[float]:
    if value is None or isinstance(value, bool):
        return None
    if not isinstance(value, (int, float)):
        return None
    return float(value)


def resolve_rules(overrides: Sequence[Any] = ()) -> list[EffectiveRule]:
    """Merge per-device override rows over the built-in metric defaults.

    Overrides are matched by ``metric``; unknown metric keys (left over from a
    removed metric) are ignored rather than raising. A ``None`` threshold on an
    override means "inherit the default", so clearing a field restores the
    shipped value instead of disabling the check.
    """
    by_metric = {}
    for row in overrides or ():
        key = getattr(row, "metric", None)
        if key in PERF_METRICS_BY_KEY:
            by_metric[key] = row

    resolved: list[EffectiveRule] = []
    for metric in PERF_METRICS:
        override = by_metric.get(metric.key)
        if override is None:
            resolved.append(
                EffectiveRule(
                    metric=metric,
                    enabled=metric.enabled,
                    warning=metric.warning,
                    critical=metric.critical,
                    consecutive_samples=DEFAULT_CONSECUTIVE_SAMPLES,
                )
            )
            continue

        warning = _clean_threshold(getattr(override, "warning_threshold", None))
        critical = _clean_threshold(getattr(override, "critical_threshold", None))
        consecutive = getattr(override, "consecutive_samples", None)
        try:
            consecutive = int(consecutive)
        except (TypeError, ValueError):
            consecutive = DEFAULT_CONSECUTIVE_SAMPLES
        resolved.append(
            EffectiveRule(
                metric=metric,
                enabled=bool(getattr(override, "enabled", metric.enabled)),
                warning=metric.warning if warning is None else warning,
                critical=metric.critical if critical is None else critical,
                consecutive_samples=max(1, consecutive),
            )
        )
    return resolved


def breaches(value: float, threshold: Optional[float], direction: str) -> bool:
    """Whether ``value`` is on the wrong side of ``threshold``."""
    if threshold is None:
        return False
    if direction == BELOW:
        return value < threshold
    return value > threshold


def severity_for(value: float, rule: EffectiveRule) -> Optional[str]:
    """Worst severity ``value`` breaches, or None if it is within limits."""
    if breaches(value, rule.critical, rule.metric.direction):
        return "critical"
    if breaches(value, rule.warning, rule.metric.direction):
        return "warning"
    return None


def _sample_time(sample: Any) -> Optional[float]:
    collected = getattr(sample, "collected_at", None)
    if collected is None:
        return None
    try:
        return collected.timestamp()
    except AttributeError:
        return None


def counter_rate(newer: Any, older: Any, key: str) -> Optional[float]:
    """Per-second rate of a cumulative counter between two samples.

    Returns None when either value is missing, the elapsed time is unusable,
    or the counter went backwards (a reboot resets it to zero, which would
    otherwise read as a large negative rate).
    """
    new_value = getattr(newer, key, None)
    old_value = getattr(older, key, None)
    if not isinstance(new_value, (int, float)) or not isinstance(old_value, (int, float)):
        return None
    if new_value < old_value:
        return None

    new_time = _sample_time(newer)
    old_time = _sample_time(older)
    if new_time is None or old_time is None:
        return None
    elapsed = new_time - old_time
    if elapsed <= 0:
        return None
    return (float(new_value) - float(old_value)) / elapsed


def metric_series(samples: Sequence[Any], metric: PerfMetric) -> list[float]:
    """Comparable values for a metric, newest first.

    ``samples`` must be ordered newest first. Gauges map one-to-one onto
    samples; counters yield one value per *pair* of samples, so a counter
    needs one more sample than a gauge to satisfy the same consecutive count.
    """
    if metric.kind == COUNTER:
        values: list[float] = []
        for newer, older in zip(samples, samples[1:]):
            rate = counter_rate(newer, older, metric.key)
            if rate is None:
                break
            values.append(rate)
        return values

    values = []
    for sample in samples:
        value = metric.value_from(sample)
        if value is None:
            break
        values.append(value)
    return values


@dataclass
class PerfBreach:
    """A metric that has been breaching its threshold long enough to alert."""

    metric: PerfMetric
    severity: str
    value: float
    threshold: float
    consecutive_samples: int

    @property
    def key(self) -> str:
        return self.metric.key


def evaluate_samples(
    samples: Sequence[Any],
    rules: Sequence[EffectiveRule],
) -> list[PerfBreach]:
    """Find metrics breaching their thresholds across recent samples.

    ``samples`` must be ordered newest first. A metric only breaches when
    *every* one of the most recent ``consecutive_samples`` values is out of
    bounds, and the reported severity is the mildest of those — a single
    critical spike inside an otherwise warning-level run reports as a warning,
    so severity reflects the sustained state rather than the worst instant.
    """
    results: list[PerfBreach] = []
    if not samples:
        return results

    for rule in rules:
        if not rule.enabled:
            continue
        if rule.warning is None and rule.critical is None:
            continue

        series = metric_series(samples, rule.metric)
        if len(series) < rule.consecutive_samples:
            continue

        window = series[: rule.consecutive_samples]
        severities = [severity_for(value, rule) for value in window]
        if any(s is None for s in severities):
            continue

        severity = "critical" if all(s == "critical" for s in severities) else "warning"
        threshold = rule.critical if severity == "critical" else rule.warning
        # A warning-level run can occur with only a critical threshold set.
        if threshold is None:
            threshold = rule.critical if rule.warning is None else rule.warning

        results.append(
            PerfBreach(
                metric=rule.metric,
                severity=severity,
                value=window[0],
                threshold=float(threshold),
                consecutive_samples=rule.consecutive_samples,
            )
        )
    return results


def format_value(value: float, unit: str) -> str:
    """Render a metric value for an alert title, without noisy precision."""
    if abs(value) >= 100 or float(value).is_integer():
        text = f"{value:.0f}"
    elif abs(value) >= 1:
        text = f"{value:.1f}"
    else:
        text = f"{value:.2f}"
    return f"{text}{unit}" if unit == "%" else f"{text} {unit}"


def describe_breach(breach: PerfBreach) -> str:
    """Human-readable explanation used as the alert description."""
    metric = breach.metric
    comparison = "below" if metric.direction == BELOW else "above"
    return (
        f"{metric.label} is {format_value(breach.value, metric.unit)}, "
        f"{comparison} the {breach.severity} threshold of "
        f"{format_value(breach.threshold, metric.unit)} "
        f"across {breach.consecutive_samples} consecutive samples. "
        f"{metric.description}"
    )


def serialize_metrics() -> list[dict[str, Any]]:
    """Metric catalog for the UI, including the shipped defaults."""
    return [
        {
            "metric": m.key,
            "label": m.label,
            "unit": m.unit,
            "direction": m.direction,
            "kind": m.kind,
            "description": m.description,
            "probe_only": m.probe_only,
            "default_enabled": m.enabled,
            "default_warning": m.warning,
            "default_critical": m.critical,
            "default_consecutive_samples": DEFAULT_CONSECUTIVE_SAMPLES,
        }
        for m in PERF_METRICS
    ]


def serialize_rules(rules: Sequence[EffectiveRule]) -> list[dict[str, Any]]:
    """Effective per-device configuration for the UI."""
    return [
        {
            "metric": r.metric.key,
            "label": r.metric.label,
            "unit": r.metric.unit,
            "direction": r.metric.direction,
            "kind": r.metric.kind,
            "description": r.metric.description,
            "probe_only": r.metric.probe_only,
            "enabled": r.enabled,
            "warning_threshold": r.warning,
            "critical_threshold": r.critical,
            "consecutive_samples": r.consecutive_samples,
            "default_enabled": r.metric.enabled,
            "default_warning": r.metric.warning,
            "default_critical": r.metric.critical,
            "is_default": (
                r.enabled == r.metric.enabled
                and r.warning == r.metric.warning
                and r.critical == r.metric.critical
                and r.consecutive_samples == DEFAULT_CONSECUTIVE_SAMPLES
            ),
        }
        for r in rules
    ]
