"""Extract completed installations from the appliance's package-install log."""
import re

from sqlalchemy.orm import Session
from sqlalchemy.dialects.sqlite import insert

from database import DevicePackageInstall


def parse_package_installs(log: str) -> list[dict[str, str | None]]:
    installs: dict[str, dict[str, str | None]] = {}
    package_file = None
    package_name = None
    package_version = None
    for line in log.splitlines():
        source = re.search(r"Package file:\s*(.*?)(?:\s+\([^)]*\))?\s*$", line)
        if source:
            filename = re.fullmatch(r"/data/packages/([^/]+\.tar\.gz)", source.group(1))
            package_file = filename.group(1) if filename else None
            package_name = package_version = None
            continue
        success = re.search(r"Package '([^';]+)(?:;([^']+))?' installed successfully\.", line)
        if success and package_file:
            package_name, package_version = success.groups()
        finished = re.search(r"Installation Finished:\s*(.*?)\s*\*+\s*$", line)
        if finished:
            if package_file and package_name and finished.group(1):
                installs[package_file] = {
                    "package_file": package_file,
                    "package_name": package_name,
                    "package_version": package_version,
                    "finished_at": finished.group(1),
                }
            package_file = package_name = package_version = None
    return list(installs.values())


def remember_package_installs(db: Session, device_id: str, log: str) -> None:
    installs = parse_package_installs(log)
    for install in installs:
        statement = insert(DevicePackageInstall).values(device_id=device_id, **install)
        db.execute(statement.on_conflict_do_update(
            index_elements=["device_id", "package_file"],
            set_={
                "package_name": statement.excluded.package_name,
                "package_version": statement.excluded.package_version,
                "finished_at": statement.excluded.finished_at,
            },
            where=DevicePackageInstall.finished_at != statement.excluded.finished_at,
        ))
    if installs:
        db.commit()


def package_install_history(db: Session, device_id: str) -> list[dict[str, str | None]]:
    return [
        {
            "package_file": row.package_file,
            "package_name": row.package_name,
            "package_version": row.package_version,
            "finished_at": row.finished_at,
        }
        for row in db.query(DevicePackageInstall)
        .filter(DevicePackageInstall.device_id == device_id)
        .order_by(DevicePackageInstall.package_file)
    ]
