"""Shared SSH helpers used across routers."""
from __future__ import annotations

import io
import logging
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING

import paramiko
from paths import DATA_DIR

if TYPE_CHECKING:
    from database import Device, SshCredential

logger = logging.getLogger(__name__)

_KNOWN_HOSTS_PATH = DATA_DIR / "known_hosts"
_known_hosts_lock = threading.Lock()


def _load_private_key(secret: str) -> paramiko.PKey:
    """Auto-detect and load an SSH private key regardless of its type.

    Tries RSA, Ed25519, ECDSA and DSS in sequence so that non-RSA keys
    (Ed25519, ECDSA, DSA) work correctly instead of failing with a
    cryptographic parse error.
    """
    key_classes = [
        paramiko.RSAKey,
        paramiko.Ed25519Key,
        paramiko.ECDSAKey,
        paramiko.DSSKey,
    ]
    last_exc: Exception | None = None
    for cls in key_classes:
        try:
            return cls.from_private_key(io.StringIO(secret))
        except Exception as exc:
            last_exc = exc
    raise paramiko.SSHException("Unsupported or malformed private key") from last_exc


class _TofuPolicy(paramiko.MissingHostKeyPolicy):
    """Trust-On-First-Use host-key policy.

    When a host is encountered for the first time the key is accepted,
    logged, and written to the known-hosts file.  On all subsequent
    connections paramiko validates the stored key automatically; if the
    key has changed (possible MITM) the connection is refused.
    """

    def missing_host_key(
        self, client: paramiko.SSHClient, hostname: str, key: paramiko.PKey
    ) -> None:
        fingerprint = key.get_fingerprint().hex()
        logger.warning(
            "SSH: trusting new host key for %s (%s %s) — verify out-of-band if possible",
            hostname,
            key.get_name(),
            fingerprint,
        )
        client.get_host_keys().add(hostname, key.get_name(), key)
        with _known_hosts_lock:
            client.save_host_keys(str(_KNOWN_HOSTS_PATH))


def create_ssh_client() -> paramiko.SSHClient:
    """Return an SSH client with TOFU host-key verification.

    * Known hosts are loaded from disk on every call so that keys saved by
      a previous connection are honoured immediately.
    * Unknown hosts are accepted once and persisted (Trust On First Use).
    * A host whose stored key no longer matches will cause paramiko to raise
      ``BadHostKeyException``, refusing the connection.
    """
    client = paramiko.SSHClient()
    if _KNOWN_HOSTS_PATH.exists():
        client.load_host_keys(str(_KNOWN_HOSTS_PATH))
    client.set_missing_host_key_policy(_TofuPolicy())
    return client


def effective_ssh_port(device: "Device", cred: "SshCredential") -> int:
    """Resolve the SSH port to use for this device.

    A device-level override (set manually, or captured from the
    auto-provision wizard) always wins, since the same SSH credential/key
    can be shared across devices that expose SSH on different ports.
    Falls back to the credential's own port, then 22.
    """
    if getattr(device, "ssh_port", None):
        return device.ssh_port
    if cred and cred.port:
        return cred.port
    return 22


def open_ssh_connection(device: "Device", cred: "SshCredential") -> paramiko.SSHClient:
    """Create and return a connected SSH client for the given device + credential.

    The caller is responsible for closing the returned client.
    """
    from database import decrypt_password  # lazy import to avoid circular dependency

    secret = decrypt_password(cred.secret_enc)
    port = effective_ssh_port(device, cred)
    pkey = _load_private_key(secret) if cred.auth_type == "key" else None
    for attempt in range(2):
        client = create_ssh_client()
        try:
            if cred.auth_type == "key":
                client.connect(device.ip_address, port=port, username=cred.username, pkey=pkey,
                               timeout=10, banner_timeout=10, auth_timeout=10, channel_timeout=10)
            else:
                client.connect(device.ip_address, port=port, username=cred.username, password=secret,
                               timeout=10, banner_timeout=10, auth_timeout=10, channel_timeout=10)
            return client
        except TimeoutError as exc:
            client.close()
            if attempt:
                raise TimeoutError(
                    f"SSH connection to {device.ip_address}:{port} timed out after two attempts"
                ) from exc
            logger.warning("SSH connection timed out device_id=%s port=%s; retrying once",
                           device.id, port)
            time.sleep(1)
        except Exception:
            client.close()
            raise
