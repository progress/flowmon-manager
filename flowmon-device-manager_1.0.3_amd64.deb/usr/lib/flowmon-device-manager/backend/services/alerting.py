from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Tuple

import httpx
from sqlalchemy import false
from sqlalchemy.orm import Session

from database import (
    Alert,
    AlertRule,
    AlertNotification,
    AlertSnooze,
    Device,
    DeviceBackup,
    DevicePerfAlertRule,
    DevicePerfSample,
    NotificationSetting,
    NotificationChannel,
    RestCredential,
    SshCredential,
    decrypt_password,
    get_or_create_alert_rules,
    get_or_create_notification_settings,
)
from routers.certificates import _extract_cert_info
from services.device_check import check_device, device_base_url
from services.perf_alerts import (
    describe_breach,
    evaluate_samples,
    format_value,
    resolve_rules,
)
from services.ssh_utils import open_ssh_connection
from services.webhook_security import (
    WebhookTargetValidationError,
    is_msteams_webhook_target,
    resolve_webhook_tls_verify,
    validate_webhook_target,
)

logger = logging.getLogger(__name__)

# Performance samples older than this describe a device that has stopped
# reporting; its thresholds are skipped so stale readings don't hold alerts
# open. Three times the default 5-minute collection interval.
PERF_SAMPLE_MAX_AGE_SECONDS = 15 * 60
UNREACHABLE_FAILURE_THRESHOLD = 3


def _ensure_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _days_left(now: datetime, target: datetime) -> int:
    return int((_ensure_utc(target) - _ensure_utc(now)).total_seconds() // 86400)


def _hours_since(now: datetime, target: datetime) -> float:
    return (_ensure_utc(now) - _ensure_utc(target)).total_seconds() / 3600.0


def _rule_enabled(rule: AlertRule | None) -> bool:
    if rule is None:
        return False
    return bool(rule.enabled)


def _rule_threshold(rule: AlertRule | None, field: str, default_value: int) -> int:
    if rule is None:
        return default_value
    value = getattr(rule, field, None)
    if value is None:
        return default_value
    try:
        return int(value)
    except Exception:
        return default_value


def _get_rules_map(db: Session) -> Dict[str, AlertRule]:
    return {r.alert_type: r for r in get_or_create_alert_rules(db)}


def _is_snoozed(db: Session, device: Device, alert_type: str, now: datetime) -> bool:
    q = db.query(AlertSnooze).filter(AlertSnooze.muted_until > _ensure_utc(now))
    q = q.filter((AlertSnooze.alert_type.is_(None)) | (AlertSnooze.alert_type == alert_type))
    group_clause = (AlertSnooze.group_id == device.group_id) if device.group_id else false()
    q = q.filter(
        (AlertSnooze.device_id == device.id)
        | group_clause
    )
    return q.first() is not None


def _channel_enabled(channel: NotificationChannel) -> bool:
    return bool(channel.enabled)


def _notifications_muted(settings_row: NotificationSetting, now: datetime) -> bool:
    if not settings_row.muted_until:
        return False
    return _ensure_utc(settings_row.muted_until) > _ensure_utc(now)


def _is_in_cooldown(
    db: Session,
    *,
    alert: Alert,
    channel_id: str,
    cooldown_seconds: int,
) -> bool:
    if cooldown_seconds <= 0:
        return False
    sent = (
        db.query(AlertNotification)
        .filter(
            AlertNotification.alert_id == alert.id,
            AlertNotification.channel_id == channel_id,
            AlertNotification.state == "sent",
            AlertNotification.alert_status == alert.status,
            AlertNotification.sent_at.is_not(None),
        )
        .order_by(AlertNotification.sent_at.desc())
        .first()
    )
    if not sent or not sent.sent_at:
        return False
    elapsed = (_ensure_utc(datetime.now(timezone.utc)) - _ensure_utc(sent.sent_at)).total_seconds()
    return elapsed < cooldown_seconds


async def _send_webhook(
    db: Session,
    alert: Alert,
    channel: NotificationChannel,
    settings_row: NotificationSetting,
) -> None:
    payload_data = {
        "alert_id": alert.id,
        "type": alert.alert_type,
        "severity": alert.severity,
        "status": alert.status,
        "title": alert.title,
        "description": alert.description,
        "device_id": alert.device_id,
        "first_seen_at": alert.first_seen_at.isoformat() if alert.first_seen_at else None,
        "last_seen_at": alert.last_seen_at.isoformat() if alert.last_seen_at else None,
        "resolved_at": alert.resolved_at.isoformat() if alert.resolved_at else None,
    }
    if alert.alert_type == "device_unreachable" and alert.status == "resolved":
        device = db.get(Device, alert.device_id) if alert.device_id else None
        if device:
            payload_data["title"] = f"Communication restored: {device.name}"
            payload_data["description"] = (
                f"{device.name} ({device.ip_address}) is reachable again via REST API."
            )
    payload = _build_webhook_payload(channel, payload_data)

    delivery = AlertNotification(
        alert_id=alert.id,
        channel_id=channel.id,
        channel_type=channel.channel_type,
        target=channel.target,
        state="pending",
        alert_status=alert.status,
    )
    db.add(delivery)
    db.flush()

    try:
        safe_target = validate_webhook_target(channel.target)
    except WebhookTargetValidationError as exc:
        delivery.state = "failed"
        delivery.error_message = str(exc)
        return

    retries = max(int(settings_row.max_retries), 0)
    backoff = max(int(settings_row.backoff_seconds), 0)
    last_error = None

    for attempt in range(retries + 1):
        if attempt > 0 and backoff > 0:
            await asyncio.sleep(backoff * attempt)
        try:
            async with httpx.AsyncClient(
                timeout=10.0,
                verify=resolve_webhook_tls_verify(getattr(channel, "verify_ssl", None)),
            ) as client:
                resp = await client.post(safe_target, json=payload)
                delivery.response_status = resp.status_code
                if 200 <= resp.status_code < 300:
                    delivery.state = "sent"
                    delivery.sent_at = datetime.now(timezone.utc)
                    delivery.error_message = None
                    return
                last_error = f"HTTP {resp.status_code}"
        except Exception as exc:
            last_error = str(exc)

    delivery.state = "failed"
    delivery.error_message = last_error


def _effective_webhook_format(channel: NotificationChannel) -> str:
    configured = (getattr(channel, "message_format", None) or "").strip().lower()
    if configured == "msteams_adaptive_card":
        return configured
    if is_msteams_webhook_target(channel.target):
        return "msteams_adaptive_card"
    return "generic"


def _build_webhook_payload(channel: NotificationChannel, payload_data: Dict[str, Any]) -> Dict[str, Any]:
    if _effective_webhook_format(channel) != "msteams_adaptive_card":
        return payload_data
    return _build_msteams_adaptive_payload(payload_data)


def _build_msteams_adaptive_payload(payload_data: Dict[str, Any]) -> Dict[str, Any]:
    title = str(payload_data.get("title") or "Flowmon Device Manager alert")
    severity = str(payload_data.get("severity") or "warning").upper()
    status = str(payload_data.get("status") or "open")
    alert_type = str(payload_data.get("type") or "unknown")
    alert_id = str(payload_data.get("alert_id") or "")
    description = str(payload_data.get("description") or "")
    first_seen = str(payload_data.get("first_seen_at") or "")
    device_id = str(payload_data.get("device_id") or "N/A")

    return {
        "type": "message",
        "summary": f"{'RESOLVED' if status == 'resolved' else severity}: {title}",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": {
                    "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.5",
                    "msteams": {"width": "Full"},
                    "body": [
                        {
                            "type": "TextBlock",
                            "text": f"{title}",
                            "weight": "Bolder",
                            "size": "Large",
                            "wrap": True,
                        },
                        {
                            "type": "TextBlock",
                            "text": description,
                            "wrap": True,
                        },
                        {
                            "type": "FactSet",
                            "facts": [
                                {"title": "Severity", "value": severity},
                                {"title": "Status", "value": status},
                                {"title": "Alert type", "value": alert_type},
                                {"title": "Alert ID", "value": alert_id},
                                {"title": "Device ID", "value": device_id},
                                {"title": "First seen", "value": first_seen},
                            ],
                        },
                    ],
                },
            }
        ],
    }


def build_test_webhook_payload(channel: NotificationChannel) -> Dict[str, Any]:
    payload_data = {
        "alert_id": "test-alert",
        "type": "device_unreachable",
        "severity": "critical",
        "status": "open",
        "title": "Test alert payload",
        "description": "This is a webhook test from Flowmon Device Manager.",
        "device_id": "test-device",
        "first_seen_at": datetime.now(timezone.utc).isoformat(),
        "last_seen_at": datetime.now(timezone.utc).isoformat(),
    }
    return _build_webhook_payload(channel, payload_data)


async def _dispatch_alert_notifications(db: Session, alert: Alert) -> None:
    settings_row = get_or_create_notification_settings(db)
    now = datetime.now(timezone.utc)
    if _notifications_muted(settings_row, now):
        return

    channels = db.query(NotificationChannel).order_by(NotificationChannel.created_at).all()
    enabled_webhooks = [c for c in channels if _channel_enabled(c) and c.channel_type == "webhook"]
    for channel in enabled_webhooks:
        if alert.status != "resolved" and _is_in_cooldown(
            db,
            alert=alert,
            channel_id=channel.id,
            cooldown_seconds=max(int(settings_row.cooldown_seconds), 0),
        ):
            continue
        await _send_webhook(db, alert, channel, settings_row)


def _upsert_open_alert(
    db: Session,
    *,
    dedupe_key: str,
    alert_type: str,
    severity: str,
    title: str,
    description: str,
    device_id: str | None,
    payload: Dict[str, Any] | None = None,
) -> Tuple[Alert, bool]:
    now = datetime.now(timezone.utc)
    existing_candidates = (
        db.query(Alert)
        .filter(Alert.dedupe_key == dedupe_key)
        .order_by(Alert.last_seen_at.desc(), Alert.created_at.desc(), Alert.id.desc())
        .all()
    )
    existing = existing_candidates[0] if existing_candidates else None

    if existing:
        if len(existing_candidates) > 1:
            for stale in existing_candidates[1:]:
                if stale.status in {"open", "acknowledged"}:
                    stale.status = "resolved"
                    stale.resolved_at = now
                    stale.last_seen_at = now
                stale.dedupe_key = f"{dedupe_key}::superseded::{stale.id}"

        was_resolved = existing.status == "resolved"
        existing.alert_type = alert_type
        existing.severity = severity
        existing.title = title
        existing.description = description
        existing.device_id = device_id
        existing.payload_json = json.dumps(payload) if payload else None
        existing.last_seen_at = now
        if was_resolved:
            existing.status = "open"
            existing.acknowledged_at = None
            existing.resolved_at = None
        db.flush()
        return existing, was_resolved

    created = Alert(
        alert_type=alert_type,
        severity=severity,
        status="open",
        title=title,
        description=description,
        dedupe_key=dedupe_key,
        device_id=device_id,
        payload_json=json.dumps(payload) if payload else None,
        first_seen_at=now,
        last_seen_at=now,
    )
    db.add(created)
    db.flush()
    return created, True


def _resolve_missing_keys(db: Session, active_keys: Iterable[str], relevant_types: Iterable[str]) -> None:
    active_set = set(active_keys)
    now = datetime.now(timezone.utc)
    q = (
        db.query(Alert)
        .filter(Alert.alert_type.in_(list(relevant_types)))
        .filter(Alert.status.in_(["open", "acknowledged"]))
    )
    for alert in q.all():
        if alert.dedupe_key in active_set:
            continue
        alert.status = "resolved"
        alert.resolved_at = now
        alert.last_seen_at = now


async def _evaluate_device_unreachable(db: Session, rules: Dict[str, AlertRule]) -> List[str]:
    active_keys: List[str] = []
    rule = rules.get("device_unreachable")
    if not _rule_enabled(rule):
        return active_keys
    devices = db.query(Device).order_by(Device.created_at).all()

    for device in devices:
        dedupe_key = f"device_unreachable:{device.id}"
        existing = (
            db.query(Alert)
            .filter(Alert.dedupe_key == dedupe_key, Alert.status.in_(["open", "acknowledged"]))
            .first()
        )
        try:
            info = None
            try:
                if device.rest_credential_id:
                    cred = db.get(RestCredential, device.rest_credential_id)
                    if not cred:
                        if existing:
                            active_keys.append(dedupe_key)
                        continue
                    username, password = cred.username, decrypt_password(cred.password_enc)
                elif device.rest_username and device.rest_password_enc:
                    username, password = device.rest_username, decrypt_password(device.rest_password_enc)
                else:
                    if existing:
                        active_keys.append(dedupe_key)
                    continue

                info = await check_device(
                    device_base_url(device.ip_address, device.https_port), username, password, bool(device.verify_ssl)
                )
                error = info.error or "REST API health check reported the device offline."
            except httpx.RequestError as exc:
                error = f"Health check failed ({type(exc).__name__})"

            if info is not None:
                device.status = info.status
                device.status_message = info.error
                device.os_version = info.os_version or device.os_version
                device.device_hostname = info.device_hostname or device.device_hostname
                if info.license_expiry:
                    device.license_expiry = info.license_expiry
                if info.support_expiry:
                    device.support_expiry = info.support_expiry
                if info.license_permanent is not None:
                    device.license_permanent = info.license_permanent
                if info.status == "online":
                    device.last_seen = info.checked_at
                    device.unreachable_check_failures = 0
                    if existing:
                        now = datetime.now(timezone.utc)
                        existing.status = "resolved"
                        existing.resolved_at = now
                        existing.last_seen_at = now
                        if not _is_snoozed(db, device, "device_unreachable", now):
                            await _dispatch_alert_notifications(db, existing)
                    continue

            device.unreachable_check_failures = (device.unreachable_check_failures or 0) + 1
            logger.warning(
                "Device reachability check failed device_id=%s consecutive_failures=%s: %s",
                device.id, device.unreachable_check_failures, error,
            )
            if _is_snoozed(db, device, "device_unreachable", datetime.now(timezone.utc)):
                continue
            if device.unreachable_check_failures < UNREACHABLE_FAILURE_THRESHOLD and not existing:
                continue
            alert, should_notify = _upsert_open_alert(
                db,
                dedupe_key=dedupe_key,
                alert_type="device_unreachable",
                severity="critical",
                title=f"Device unreachable: {device.name}",
                description=(
                    f"{device.name} ({device.ip_address}) is unreachable via REST API after "
                    f"{device.unreachable_check_failures} consecutive failed evaluations. {error}"
                ),
                device_id=device.id,
                payload={
                    "ip_address": device.ip_address,
                    "error": error,
                    "consecutive_failures": device.unreachable_check_failures,
                },
            )
            active_keys.append(dedupe_key)
            if should_notify:
                await _dispatch_alert_notifications(db, alert)
        finally:
            # Commit after every device instead of accumulating one long-lived
            # write transaction across the whole loop. Each device check can
            # involve a slow network round-trip; holding the write lock for
            # the entire loop (many devices x several seconds each) starves
            # other requests (e.g. an interactive "Refresh" click) with
            # "database is locked" errors under SQLite.
            db.commit()

    return active_keys


async def _evaluate_certificate_expiry(db: Session, rules: Dict[str, AlertRule]) -> List[str]:
    active_keys: List[str] = []
    rule = rules.get("certificate_expiry")
    if not _rule_enabled(rule):
        return active_keys
    now = datetime.now(timezone.utc)
    warning_days = _rule_threshold(rule, "warning_threshold", 30)
    critical_days = _rule_threshold(rule, "critical_threshold", 7)
    devices = db.query(Device).order_by(Device.created_at).all()

    for device in devices:
        if not device.ssh_credential_id:
            continue
        ssh_cred = db.get(SshCredential, device.ssh_credential_id)
        if not ssh_cred:
            continue

        ssh_client = None
        sftp = None
        try:
            ssh_client = open_ssh_connection(device, ssh_cred)
            sftp = ssh_client.open_sftp()
            cert_file = sftp.file("/etc/httpd/conf/ssl.crt/server.crt")
            cert_pem = cert_file.read().decode()
            cert_file.close()

            cert_info = _extract_cert_info(cert_pem)
            not_after = datetime.fromisoformat(cert_info["notAfter"])
            days_left = _days_left(now, not_after)

            if days_left <= warning_days:
                if _is_snoozed(db, device, "certificate_expiry", now):
                    continue
                severity = "critical" if days_left <= critical_days else "warning"
                dedupe_key = f"certificate_expiry:{device.id}"
                alert, should_notify = _upsert_open_alert(
                    db,
                    dedupe_key=dedupe_key,
                    alert_type="certificate_expiry",
                    severity=severity,
                    title=f"Certificate expiry: {device.name}",
                    description=(
                        f"Device certificate on {device.name} ({device.ip_address}) expires in {days_left} day(s)."
                    ),
                    device_id=device.id,
                    payload={"ip_address": device.ip_address, "notAfter": cert_info["notAfter"], "days_left": days_left},
                )
                active_keys.append(dedupe_key)
                if should_notify:
                    await _dispatch_alert_notifications(db, alert)
        except Exception as exc:
            logger.warning("Certificate check failed for %s: %s", device.name, exc)
        finally:
            if sftp:
                try:
                    sftp.close()
                except Exception:
                    pass
            if ssh_client:
                try:
                    ssh_client.close()
                except Exception:
                    pass
            # See note in _evaluate_device_unreachable: commit per-device so
            # the write lock isn't held across every device's SSH round-trip.
            db.commit()

    return active_keys


async def _evaluate_backup_stale(db: Session, rules: Dict[str, AlertRule]) -> List[str]:
    active_keys: List[str] = []
    rule = rules.get("backup_stale")
    if not _rule_enabled(rule):
        return active_keys
    now = datetime.now(timezone.utc)
    warning_hours = _rule_threshold(rule, "warning_threshold", 26)
    critical_hours = _rule_threshold(rule, "critical_threshold", 72)
    devices = db.query(Device).order_by(Device.created_at).all()

    for device in devices:
        latest = (
            db.query(DeviceBackup)
            .filter(DeviceBackup.device_id == device.id)
            .order_by(DeviceBackup.created_at.desc())
            .first()
        )

        dedupe_key = f"backup_stale:{device.id}"

        if latest is None:
            device_age_hours = _hours_since(now, device.created_at)
            if device_age_hours > warning_hours:
                if _is_snoozed(db, device, "backup_stale", now):
                    continue
                alert, should_notify = _upsert_open_alert(
                    db,
                    dedupe_key=dedupe_key,
                    alert_type="backup_stale",
                    severity="critical",
                    title=f"No backup found: {device.name}",
                    description=(
                        f"No backup snapshot exists for {device.name} ({device.ip_address}) "
                        f"and the device has been managed for over {warning_hours} hours."
                    ),
                    device_id=device.id,
                    payload={"ip_address": device.ip_address, "age_hours": round(device_age_hours, 1)},
                )
                active_keys.append(dedupe_key)
                if should_notify:
                    await _dispatch_alert_notifications(db, alert)
            continue

        verified_at = latest.last_verified_at or latest.created_at
        backup_age_hours = _hours_since(now, verified_at)
        if backup_age_hours > warning_hours:
            if _is_snoozed(db, device, "backup_stale", now):
                continue
            severity = "critical" if backup_age_hours > critical_hours else "warning"
            alert, should_notify = _upsert_open_alert(
                db,
                dedupe_key=dedupe_key,
                alert_type="backup_stale",
                severity=severity,
                title=f"Backup stale: {device.name}",
                description=(
                    f"Last successful backup verification for {device.name} ({device.ip_address}) "
                    f"was {round(backup_age_hours, 1)} hour(s) ago. Unchanged configurations count as successful."
                ),
                device_id=device.id,
                payload={
                    "ip_address": device.ip_address,
                    "backup_age_hours": round(backup_age_hours, 1),
                    "latest_backup_at": _ensure_utc(latest.created_at).isoformat(),
                    "last_verified_at": _ensure_utc(verified_at).isoformat(),
                },
            )
            active_keys.append(dedupe_key)
            if should_notify:
                await _dispatch_alert_notifications(db, alert)

    return active_keys


async def _evaluate_license_and_support_expiry(db: Session, rules: Dict[str, AlertRule]) -> Tuple[List[str], List[str]]:
    license_keys: List[str] = []
    support_keys: List[str] = []
    now = datetime.now(timezone.utc)
    devices = db.query(Device).order_by(Device.created_at).all()
    license_rule = rules.get("license_expiry")
    support_rule = rules.get("support_expiry")
    license_enabled = _rule_enabled(license_rule)
    support_enabled = _rule_enabled(support_rule)
    license_warning_days = _rule_threshold(license_rule, "warning_threshold", 45)
    license_critical_days = _rule_threshold(license_rule, "critical_threshold", 14)
    support_warning_days = _rule_threshold(support_rule, "warning_threshold", 45)
    support_critical_days = _rule_threshold(support_rule, "critical_threshold", 14)

    for device in devices:
        if license_enabled and device.license_expiry:
            license_days_left = _days_left(now, device.license_expiry)
            if license_days_left <= license_warning_days:
                if _is_snoozed(db, device, "license_expiry", now):
                    continue
                severity = "critical" if license_days_left <= license_critical_days else "warning"
                dedupe_key = f"license_expiry:{device.id}"
                alert, should_notify = _upsert_open_alert(
                    db,
                    dedupe_key=dedupe_key,
                    alert_type="license_expiry",
                    severity=severity,
                    title=f"License expiry: {device.name}",
                    description=(
                        f"Device license for {device.name} ({device.ip_address}) expires in {license_days_left} day(s)."
                    ),
                    device_id=device.id,
                    payload={
                        "ip_address": device.ip_address,
                        "license_expiry": _ensure_utc(device.license_expiry).isoformat(),
                        "days_left": license_days_left,
                    },
                )
                license_keys.append(dedupe_key)
                if should_notify:
                    await _dispatch_alert_notifications(db, alert)

        if support_enabled and device.support_expiry:
            support_days_left = _days_left(now, device.support_expiry)
            if support_days_left <= support_warning_days:
                if _is_snoozed(db, device, "support_expiry", now):
                    continue
                severity = "critical" if support_days_left <= support_critical_days else "warning"
                dedupe_key = f"support_expiry:{device.id}"
                alert, should_notify = _upsert_open_alert(
                    db,
                    dedupe_key=dedupe_key,
                    alert_type="support_expiry",
                    severity=severity,
                    title=f"Support expiry: {device.name}",
                    description=(
                        f"Support contract for {device.name} ({device.ip_address}) expires in {support_days_left} day(s)."
                    ),
                    device_id=device.id,
                    payload={
                        "ip_address": device.ip_address,
                        "support_expiry": _ensure_utc(device.support_expiry).isoformat(),
                        "days_left": support_days_left,
                    },
                )
                support_keys.append(dedupe_key)
                if should_notify:
                    await _dispatch_alert_notifications(db, alert)

    return license_keys, support_keys


async def _evaluate_update_failures(db: Session, rules: Dict[str, AlertRule]) -> List[str]:
    active_keys: List[str] = []
    rule = rules.get("update_failure")
    if not _rule_enabled(rule):
        return active_keys

    devices = db.query(Device).order_by(Device.created_at).all()
    for device in devices:
        if not device.ssh_credential_id:
            continue
        ssh_cred = db.get(SshCredential, device.ssh_credential_id)
        if not ssh_cred:
            continue
        if _is_snoozed(db, device, "update_failure", datetime.now(timezone.utc)):
            continue

        client = None
        try:
            client = open_ssh_connection(device, ssh_cred)
            cmd = (
                "{ tail -n 20 /var/log/pkg_install.log 2>/dev/null || true; "
                "echo '---PGREP---'; "
                "pgrep -af '[/](data/components/apps/bin|usr/sbin|sbin)/update-device.sh' 2>/dev/null || true; }"
            )
            _, stdout, _ = client.exec_command(cmd)
            combined = stdout.read().decode("utf-8", errors="replace")
            if "---PGREP---" in combined:
                log_part, pgrep_part = combined.split("---PGREP---", 1)
            else:
                log_part, pgrep_part = combined, ""
            running = bool(pgrep_part.strip())
            lines = [line.strip() for line in log_part.splitlines() if line.strip()]
            last_line = lines[-1] if lines else ""
            failed = bool(last_line) and ("error" in last_line.lower() or "failed" in last_line.lower())

            if failed and not running:
                dedupe_key = f"update_failure:{device.id}"
                alert, should_notify = _upsert_open_alert(
                    db,
                    dedupe_key=dedupe_key,
                    alert_type="update_failure",
                    severity="warning",
                    title=f"Update failure: {device.name}",
                    description=f"Latest package/update operation on {device.name} reported failure: {last_line}",
                    device_id=device.id,
                    payload={"ip_address": device.ip_address, "last_log_line": last_line},
                )
                active_keys.append(dedupe_key)
                if should_notify:
                    await _dispatch_alert_notifications(db, alert)
        except Exception as exc:
            logger.warning("Update failure detector check failed for %s: %s", device.name, exc)
        finally:
            if client:
                try:
                    client.close()
                except Exception:
                    pass
            # See note in _evaluate_device_unreachable: commit per-device so
            # the write lock isn't held across every device's SSH round-trip.
            db.commit()
    return active_keys


async def _evaluate_perf_thresholds(db: Session, rules: Dict[str, AlertRule]) -> List[str]:
    """Alert on collected performance samples breaching per-device thresholds.

    Reads only from the local sample store, so unlike the other evaluators it
    never touches the device — a device that is offline simply stops producing
    new samples and its metrics go stale rather than alerting here.
    """
    active_keys: List[str] = []
    rule = rules.get("perf_threshold")
    if not _rule_enabled(rule):
        return active_keys

    now = datetime.now(timezone.utc)
    devices = db.query(Device).order_by(Device.created_at).all()

    for device in devices:
        try:
            overrides = (
                db.query(DevicePerfAlertRule)
                .filter(DevicePerfAlertRule.device_id == device.id)
                .all()
            )
            effective = resolve_rules(overrides)
            # A counter needs one extra sample to produce its first rate.
            needed = max(
                (r.consecutive_samples for r in effective if r.enabled), default=0
            )
            if needed <= 0:
                continue

            samples = (
                db.query(DevicePerfSample)
                .filter(DevicePerfSample.device_id == device.id)
                .order_by(DevicePerfSample.collected_at.desc())
                .limit(needed + 1)
                .all()
            )
            if not samples:
                continue

            # Stale samples describe the past, not the present. If collection
            # has stopped (device offline, SSH broken), holding the alerts open
            # would be misleading, so let them resolve.
            newest = _ensure_utc(samples[0].collected_at)
            if (_ensure_utc(now) - newest).total_seconds() > PERF_SAMPLE_MAX_AGE_SECONDS:
                continue

            if _is_snoozed(db, device, "perf_threshold", now):
                continue

            for breach in evaluate_samples(samples, effective):
                dedupe_key = f"perf_threshold:{device.id}:{breach.key}"
                alert, should_notify = _upsert_open_alert(
                    db,
                    dedupe_key=dedupe_key,
                    alert_type="perf_threshold",
                    severity=breach.severity,
                    title=(
                        f"{breach.metric.label} {breach.severity} on {device.name}: "
                        f"{format_value(breach.value, breach.metric.unit)}"
                    ),
                    description=describe_breach(breach),
                    device_id=device.id,
                    payload={
                        "ip_address": device.ip_address,
                        "metric": breach.key,
                        "value": breach.value,
                        "threshold": breach.threshold,
                        "unit": breach.metric.unit,
                        "direction": breach.metric.direction,
                        "consecutive_samples": breach.consecutive_samples,
                    },
                )
                active_keys.append(dedupe_key)
                if should_notify:
                    await _dispatch_alert_notifications(db, alert)
        except Exception as exc:
            logger.warning("Performance threshold check failed for %s: %s", device.name, exc)

    return active_keys


async def evaluate_alerts(db: Session) -> Dict[str, int]:
    rules = _get_rules_map(db)
    device_unreachable_keys = await _evaluate_device_unreachable(db, rules)
    cert_expiry_keys = await _evaluate_certificate_expiry(db, rules)
    backup_stale_keys = await _evaluate_backup_stale(db, rules)
    license_expiry_keys, support_expiry_keys = await _evaluate_license_and_support_expiry(db, rules)
    update_failure_keys = await _evaluate_update_failures(db, rules)
    perf_threshold_keys = await _evaluate_perf_thresholds(db, rules)

    _resolve_missing_keys(db, device_unreachable_keys, ["device_unreachable"])
    _resolve_missing_keys(db, cert_expiry_keys, ["certificate_expiry"])
    _resolve_missing_keys(db, backup_stale_keys, ["backup_stale"])
    _resolve_missing_keys(db, license_expiry_keys, ["license_expiry"])
    _resolve_missing_keys(db, support_expiry_keys, ["support_expiry"])
    _resolve_missing_keys(db, update_failure_keys, ["update_failure"])
    _resolve_missing_keys(db, perf_threshold_keys, ["perf_threshold"])

    db.commit()

    open_count = db.query(Alert).filter(Alert.status.in_(["open", "acknowledged"])).count()
    critical_open_count = db.query(Alert).filter(Alert.status.in_(["open", "acknowledged"]), Alert.severity == "critical").count()

    return {
        "open_alerts": int(open_count),
        "critical_open_alerts": int(critical_open_count),
        "device_unreachable_open": len(device_unreachable_keys),
        "certificate_expiry_open": len(cert_expiry_keys),
        "backup_stale_open": len(backup_stale_keys),
        "license_expiry_open": len(license_expiry_keys),
        "support_expiry_open": len(support_expiry_keys),
        "update_failure_open": len(update_failure_keys),
        "perf_threshold_open": len(perf_threshold_keys),
    }
