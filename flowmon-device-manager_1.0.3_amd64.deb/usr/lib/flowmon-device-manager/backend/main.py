from __future__ import annotations

import asyncio
import contextlib
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
# StaticFiles raises Starlette's HTTPException, which FastAPI's subclasses —
# catching the FastAPI one would not match what is actually raised.
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.orm import Session

from config import settings
from services.app_logging import (
    RequestLoggingMiddleware,
    build_id,
    configure_logging,
    save_bootstrap_admin_password,
)

configure_logging(settings.log_level)
from database import create_tables, engine, ensure_default_admin
from routers.auth import router as auth_router
from routers.oidc import router as oidc_router
from routers.users import router as users_router
from routers.devices import router as devices_router
from routers.devices import refresh_all_devices_status
from routers.credentials import router as credentials_router
from routers.audit import router as audit_router
from routers.device_logs import router as device_logs_router
from routers.groups import router as groups_router
from routers.packages import router as packages_router, refresh_community_cache
from routers.license_packs import router as license_packs_router
from routers.backups import router as backups_router, run_daily_backups
from routers.certificates import router as certificates_router
from routers.alerts import router as alerts_router
from routers.perfmon import router as perfmon_router, collect_all_devices_perf
from services.alerting import evaluate_alerts
from services.support_bundle import sweep_stale_tasks

app = FastAPI(title="Flowmon Device Manager")
app.add_middleware(RequestLoggingMiddleware)

logger = logging.getLogger(__name__)


@app.exception_handler(Exception)
async def unhandled_error_response(request: Request, exc: Exception) -> JSONResponse:
    identifier = getattr(request.state, "request_id", "-")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "request_id": identifier},
        headers={"X-Request-ID": identifier},
    )

# CORS — only needed when frontend dev server is on a different port
if not settings.production:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

app.include_router(auth_router)
app.include_router(oidc_router)
app.include_router(users_router)
app.include_router(devices_router)
app.include_router(credentials_router)
app.include_router(audit_router)
app.include_router(device_logs_router)
app.include_router(groups_router)
app.include_router(packages_router)
app.include_router(license_packs_router)
app.include_router(backups_router)
app.include_router(certificates_router)
app.include_router(alerts_router)
app.include_router(perfmon_router)


async def _device_refresh_worker(interval_hours: int) -> None:
    interval_seconds = max(interval_hours * 3600, 60)
    while True:
        try:
            with Session(engine) as db:
                await refresh_all_devices_status(db)
        except Exception:
            logger.exception("Device refresh run failed")
        await asyncio.sleep(interval_seconds)


async def _daily_backup_worker(hour: int = 3, minute: int = 0) -> None:
    while True:
        now = datetime.now(timezone.utc)
        next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if next_run <= now:
            next_run = next_run + timedelta(days=1)
        await asyncio.sleep((next_run - now).total_seconds())
        with Session(engine) as db:
            try:
                await run_daily_backups(db)
            except Exception:
                logger.exception("Daily backup run failed")


async def _alerts_worker(interval_minutes: int = 5) -> None:
    interval_seconds = max(interval_minutes * 60, 30)
    while True:
        with Session(engine) as db:
            try:
                await evaluate_alerts(db)
            except Exception:
                logger.exception("Alert evaluation run failed")
        await asyncio.sleep(interval_seconds)


async def _perf_collect_worker(interval_minutes: int) -> None:
    interval_seconds = max(interval_minutes * 60, 60)
    while True:
        try:
            await collect_all_devices_perf()
        except Exception:
            logger.exception("Performance collection run failed")
        await asyncio.sleep(interval_seconds)


async def _community_refresh_worker(interval_hours: int) -> None:
    """Keep the community package list current without user interaction."""
    interval_seconds = max(interval_hours * 3600, 600)
    while True:
        try:
            await refresh_community_cache()
        except Exception:
            logger.exception("Community package refresh failed")
        await asyncio.sleep(interval_seconds)


async def _support_bundle_cleanup_worker(interval_minutes: int = 5) -> None:
    while True:
        try:
            sweep_stale_tasks()
        except Exception:
            logger.exception("Support bundle cleanup failed")
        await asyncio.sleep(max(interval_minutes * 60, 60))


@app.on_event("startup")
async def on_startup() -> None:
    logger.info("Device Manager starting build_id=%s log_level=%s", build_id(), settings.log_level)
    create_tables()
    generated_password = ensure_default_admin()
    if generated_password:
        password_file = save_bootstrap_admin_password(generated_password)
        logger.warning("=" * 64)
        logger.warning("No local users found — created default admin account:")
        logger.warning("  username: admin")
        logger.warning("  one-time password saved to %s (mode 0600)", password_file)
        logger.warning("Read the password file and change the password after logging in.")
        logger.warning("=" * 64)
    interval_hours = settings.device_refresh_interval_hours
    if interval_hours > 0:
        app.state.device_refresh_task = asyncio.create_task(_device_refresh_worker(interval_hours))
    app.state.backup_task = asyncio.create_task(_daily_backup_worker(3, 0))
    app.state.alerts_task = asyncio.create_task(_alerts_worker(5))
    perf_interval = settings.perf_collect_interval_minutes
    if perf_interval > 0:
        app.state.perf_task = asyncio.create_task(_perf_collect_worker(perf_interval))
    community_interval = settings.community_refresh_interval_hours
    if community_interval > 0:
        app.state.community_task = asyncio.create_task(
            _community_refresh_worker(community_interval)
        )
    sweep_stale_tasks()
    app.state.support_bundle_cleanup_task = asyncio.create_task(
        _support_bundle_cleanup_worker()
    )


@app.on_event("shutdown")
async def on_shutdown() -> None:
    logger.info("Device Manager shutting down")
    task = getattr(app.state, "device_refresh_task", None)
    if task:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
    backup_task = getattr(app.state, "backup_task", None)
    if backup_task:
        backup_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await backup_task
    alerts_task = getattr(app.state, "alerts_task", None)
    if alerts_task:
        alerts_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await alerts_task
    perf_task = getattr(app.state, "perf_task", None)
    if perf_task:
        perf_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await perf_task
    community_task = getattr(app.state, "community_task", None)
    if community_task:
        community_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await community_task
    support_bundle_cleanup_task = getattr(app.state, "support_bundle_cleanup_task", None)
    if support_bundle_cleanup_task:
        support_bundle_cleanup_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await support_bundle_cleanup_task


# Serve the built React app in production
_frontend_dist = Path(__file__).parent.parent / "frontend" / "dist"


class SpaStaticFiles(StaticFiles):
    """Static files with a single-page-app fallback.

    The UI uses client-side routing, so a URL like ``/devices/<id>`` exists only
    in the browser — there is no such file on disk. Plain ``StaticFiles`` answers
    404 for those paths, which is why reloading the page (or opening a
    bookmarked deep link) failed while in-app navigation worked. Unknown paths
    are therefore served ``index.html`` so the router can resolve them.

    Two kinds of path are deliberately excluded from the fallback, because for
    them a 404 is the correct and more debuggable answer:

    * ``/api/...`` — a mistyped or removed endpoint must stay a JSON 404 rather
      than silently returning an HTML page that the caller cannot parse.
    * ``/assets/...`` — a missing hashed bundle must not resolve to HTML, or the
      browser reports a confusing MIME-type error instead of a plain 404.
    """

    async def get_response(self, path: str, scope):
        served_index = path in ("", ".", "index.html")
        try:
            response = await super().get_response(path, scope)
        except StarletteHTTPException as exc:
            # Starlette signals a missing file by raising, not by returning 404.
            if exc.status_code != 404 or not self._should_fall_back(path):
                raise
            response = await super().get_response("index.html", scope)
            served_index = True
        else:
            if response.status_code == 404 and self._should_fall_back(path):
                response = await super().get_response("index.html", scope)
                served_index = True
        # The asset filenames are content-hashed, but index.html itself is not,
        # so it must never be cached or clients keep loading a stale bundle
        # after a deploy.
        if served_index and response.status_code == 200:
            response.headers["Cache-Control"] = "no-cache, must-revalidate"
        return response

    @staticmethod
    def _should_fall_back(path: str) -> bool:
        normalized = path.lstrip("/")
        return not (
            normalized.startswith("api/") or normalized.startswith("assets/")
        )


if _frontend_dist.exists():
    app.mount("/", SpaStaticFiles(directory=str(_frontend_dist), html=True), name="static")
